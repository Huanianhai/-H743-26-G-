# Context

Filename: `TASK_KEY2_ANTI_JAM_RELIABILITY.md`  
Created On: 2026-07-30  
Associated Protocol: RIPER-5 + STM32

# Task Description

修复直连 x1 软件抗干扰模式中，按下 KEY2 偶发进入 `BAD HARMONICS / IDENT` 的问题；保持 G 题每项完成时间小于 2 秒，并核对幅值误差及 1MHz 以上干扰的适用范围。

# Project Overview

- MCU: STM32H743，正点原子阿波罗开发板
- Firmware Library: STM32 HAL
- IDE/Toolchain: Keil MDK，ArmClang V6.21
- RTOS: None

# Hardware Configuration

- ADC input: PA5 / ADC1 channel 19，P10 跳帽拔下
- Signal path: `Ub + uJ -> 加法器 -> 1.65V 偏置 -> PA5`
- ADC sampling: 3.125MSPS / 8192 点抗干扰探测；2MSPS / 4096 点混叠辅助探测
- DMA: DMA2 Stream4，普通单帧模式，中断优先级 1
- Deadline: 固件总测量截止 1.5 秒，题目要求小于 2 秒

# Analysis

失败照片显示采样和分析已完成，约 403ms、8 帧后在确认阶段以 `IDENT` 退出，不是 ADC/DMA 超时。现有逻辑在任一确认帧的幅值或相位超过严格阈值时，清空已经正确锁定的谐波模型。成功页面证明同一硬件下可正确识别 H1/H3/H5，故问题属于确认状态机的偶发误拒绝。

成功页面中的 `Upp(total)=94.95mV` 是三个谐波按实际相位重建后的总峰峰值，不能与 H1 的 100mVpp 设置值直接比较。H1=95.69mVpp、H3=29.17mVpp、H5=28.44mVpp，指定频谱分量误差均小于 5mV；Urms=36.77mV 相对理论约 38.4mV 也满足要求，因此不依据该页面修改增益校准。

# Proposed Solution

保留当前 ADC、FFT、最小二乘干扰估计和相消算法。模型一旦由抗干扰发现阶段锁定，确认阶段只丢弃异常帧并继续采样，不再清空锁定模型。幅值和相位稳定性仍由三帧滑动窗口判断。最大尝试帧数从 8 增加到 20，同时保留 1.5 秒硬截止。

# Implementation Plan

1. 完整备份修复前工程。
2. 调整最大尝试帧数。
3. 将结构身份判断与三帧稳定判断解耦。
4. 锁定后异常帧只重采，不重新发现含干扰的原始信号。
5. 双向比较高、低采样率独有峰，必要时切回高速采样完成相消。
6. 检查 1MHz 至 10MHz 的双采样率混叠覆盖和物理盲点。
7. Keil 全量编译并检查 HEX。

# Current Execution Step

> Completed

# Task Progress

- 2026-07-30
  - Step: 修复前备份
  - Modifications: 创建完整工程备份 `20260730_26周期信号分析_直连x1_KEY2偶发BAD_HARMONICS_成功时幅值已达标_可靠性修复前`
  - Change Summary: 保存当前可复现偶发 IDENT 失败、成功时幅值达标的版本
  - Reason: 执行计划步骤 1
  - Blockers: None
  - Status: Completed

- 2026-07-30
  - Step: KEY2 锁定后确认帧处理
  - Modifications: `User/g_measure.c` 最大尝试帧数调整为 20；`GMeasure_SameLockedModel()`仅保留谐波阶次和频率；异常确认帧不再清空锁定模型；删除不再使用的`s_have_discovery`
  - Change Summary: 保持三帧稳定判据，改用锁定模型下的滑动重采
  - Reason: 执行计划步骤 2 至 4
  - Blockers: None
  - Status: Pending Verification

- 2026-07-30
  - Step: 高频干扰双采样率检测补全
  - Modifications: 高、低采样率独有峰改为双向检测；增加高速重放相消路径；搜索上限扩展到采样率的 0.489 倍
  - Change Summary: 覆盖干扰在低速采样时与 Ub 峰重合、但在高速采样时可分离的情形
  - Reason: 执行修订计划步骤 5
  - Blockers: 采样后与 Ub 同频的极窄频点仍属于单路 ADC 无法唯一分离的物理盲点
  - Status: Verified by alias mapping

- 2026-07-30
  - Step: 编译、时序和高频覆盖验证
  - Modifications: Keil ArmClang V6.21 全量编译；按 1kHz 步进枚举 1MHz 至 10MHz 混叠路径
  - Change Summary: 0 errors / 0 warnings；新 HEX 已生成；当前 100/300/500kHz Ub 组合下 9001 个枚举点中 8996 个可区分
  - Reason: 执行计划步骤 6 至 7
  - Blockers: 需要开发板实测确认模拟链路在高频下的带宽和ADC采样保持误差
  - Status: Completed

# Final Review

业务源码仅修改 `User/g_measure.c`。实现与最终计划一致：锁定后不因单帧幅值或相位波动清空模型；三帧稳定窗口仍保留；最大尝试帧数 20，固件总截止仍为 1500ms；双采样率采用低速独有峰和高速独有峰双向识别，并支持切回高速重放相消。

Keil 全量编译结果为 `0 Error(s), 0 Warning(s)`，程序大小为 Code=108406、RO-data=94306、RW-data=40、ZI-data=2287064。未新增静态采样缓冲区、动态内存、ISR处理或中断优先级变更。

按失败照片 8 帧约 403ms 估算，20 帧线性上界约 1008ms，低于 1500ms 固件截止和 2000ms 题目截止。最终仍需烧录后连续按 KEY2 实测，因为离线检查无法替代真实加法器、偏置电路和ADC采样保持带宽。

1MHz 至 10MHz 并非数学上无条件覆盖：当两个采样率的干扰别名都与 Ub 分量重合时，单路 ADC 无法唯一分离。当前 100/300/500kHz 测试组合的 1kHz 网格中，约 3.562–3.563MHz、6.125MHz、9.687–9.688MHz 为典型窄盲区，其他枚举点可进入高速、低速或高速重放路径。

Implementation perfectly matches the final plan.
