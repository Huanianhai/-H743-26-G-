/**
 ****************************************************************************************************
 * @file        g_interference.h
 * @brief       G题第三问单频干扰检测与时域相消
 ****************************************************************************************************
 */

#ifndef __G_INTERFERENCE_H
#define __G_INTERFERENCE_H

#include <stdint.h>

#define GINTERFERENCE_MAX_PEAKS  8U

typedef struct
{
    float frequency_hz;
    float magnitude;
    uint16_t bin;
} ginterference_peak_t;

typedef struct
{
    float frequency_hz;
    float amplitude_mv;
    float phase_degrees;
    float residual_amplitude_mv;
} ginterference_result_t;

uint8_t GInterference_FindStrongest(const float *spectrum,
                                    uint32_t fft_length,
                                    float sample_rate_hz,
                                    float minimum_frequency_hz,
                                    float maximum_frequency_hz,
                                    ginterference_peak_t *peak);
uint8_t GInterference_CollectPeaks(const float *spectrum,
                                  uint32_t fft_length,
                                  float sample_rate_hz,
                                  float minimum_frequency_hz,
                                  float maximum_frequency_hz,
                                  ginterference_peak_t *peaks,
                                  uint8_t capacity);
uint8_t GInterference_EstimateAndSubtract(float *data,
                                          uint32_t length,
                                          float sample_rate_hz,
                                          float frequency_hz,
                                          ginterference_result_t *result);

#endif
