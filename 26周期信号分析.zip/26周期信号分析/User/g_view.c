/**
 ****************************************************************************************************
 * @file        g_view.c
 * @brief       G题测量240x320冻结显示界面
 ****************************************************************************************************
 */

#include "g_view.h"
#include "./BSP/LCD/lcd.h"
#include <math.h>
#include <stdio.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846f
#endif

#define GVIEW_MODE_WAVE        0U
#define GVIEW_MODE_SPECTRUM    1U
#define GVIEW_PLOT_X0          5U
#define GVIEW_PLOT_X1          234U
#define GVIEW_PLOT_Y0          38U
#define GVIEW_PLOT_Y1          178U
#define GVIEW_PLOT_WIDTH       (GVIEW_PLOT_X1 - GVIEW_PLOT_X0 + 1U)

static uint8_t s_mode = GVIEW_MODE_WAVE;
static uint8_t s_periods = 1U;
static float s_wave_points[GVIEW_PLOT_WIDTH];

static void GView_Title(const char *status)
{
    lcd_fill(0U, 0U, 239U, 19U, BLUE);
    lcd_show_string(5U, 2U, 150U, 16U, 16U,
                    "G-SIGNAL H743", WHITE);
    lcd_show_string(158U, 4U, 78U, 12U, 12U,
                    (char *)status, WHITE);
}

static const char *GView_StatusText(gmeasure_status_t status)
{
    switch (status)
    {
        case GMEASURE_STATUS_NO_SIGNAL:
            return "NO SIGNAL";
        case GMEASURE_STATUS_CLIPPED:
            return "CLIPPED";
        case GMEASURE_STATUS_BAD_HARMONICS:
            return "BAD HARMONICS";
        case GMEASURE_STATUS_UNSTABLE:
            return "UNSTABLE";
        case GMEASURE_STATUS_TIMEOUT:
            return "TIMEOUT";
        case GMEASURE_STATUS_ADC_ERROR:
            return "ADC ERROR";
        case GMEASURE_STATUS_VREF_ERROR:
            return "VREF ERROR";
        case GMEASURE_STATUS_FIT_ERROR:
            return "FIT ERROR";
        case GMEASURE_STATUS_INTERFERENCE:
            return "JAM ERROR";
        default:
            return "OK";
    }
}

static const char *GView_DiagnosticStageText(gmeasure_diag_stage_t stage)
{
    switch (stage)
    {
        case GMEASURE_DIAG_STAGE_DISCOVERY:
            return "FIND";
        case GMEASURE_DIAG_STAGE_CONFIRMATION:
            return "CONF";
        default:
            return "NONE";
    }
}

static const char *GView_DiagnosticReasonText(gmeasure_diag_reason_t reason)
{
    switch (reason)
    {
        case GMEASURE_DIAG_REASON_CLIPPED:
            return "CLIP";
        case GMEASURE_DIAG_REASON_NO_SIGNAL:
            return "NOSIG";
        case GMEASURE_DIAG_REASON_BAD_MODEL:
            return "MODEL";
        case GMEASURE_DIAG_REASON_FIT_ERROR:
            return "FIT";
        case GMEASURE_DIAG_REASON_IDENTITY:
            return "IDENT";
        case GMEASURE_DIAG_REASON_UNSTABLE:
            return "STABLE";
        case GMEASURE_DIAG_REASON_DEADLINE:
            return "LIMIT";
        case GMEASURE_DIAG_REASON_JAM_UNRESOLVED:
            return "JAM";
        default:
            return "NONE";
    }
}

static void GView_DrawFrame(void)
{
    lcd_fill(GVIEW_PLOT_X0, GVIEW_PLOT_Y0,
             GVIEW_PLOT_X1, GVIEW_PLOT_Y1, WHITE);
    lcd_draw_rectangle(GVIEW_PLOT_X0, GVIEW_PLOT_Y0,
                       GVIEW_PLOT_X1, GVIEW_PLOT_Y1, BLACK);
}

static void GView_DrawWaveform(void)
{
    float minimum = 1.0e30f;
    float maximum = -1.0e30f;
    float center;
    float scale;
    float drawable_half =
        (float)(GVIEW_PLOT_Y1 - GVIEW_PLOT_Y0 - 12U) * 0.5f;
    int32_t center_y = (int32_t)(GVIEW_PLOT_Y0 + GVIEW_PLOT_Y1) / 2;
    uint16_t point;

    for (point = 0U; point < GVIEW_PLOT_WIDTH; point++)
    {
        float theta = 2.0f * (float)M_PI * (float)s_periods *
                      (float)point / (float)(GVIEW_PLOT_WIDTH - 1U);
        float voltage = 0.0f;
        uint8_t component;

        for (component = 0U;
             component < g_measure_result.component_count; component++)
        {
            float phase = g_measure_result.component[component].
                          relative_phase_degrees *
                          (float)M_PI / 180.0f;
            voltage += g_measure_result.component[component].amplitude_mv *
                       cosf((float)g_measure_result.component[component].
                                  harmonic_order * theta + phase);
        }
        s_wave_points[point] = voltage;
        if (voltage < minimum)
        {
            minimum = voltage;
        }
        if (voltage > maximum)
        {
            maximum = voltage;
        }
    }

    center = 0.5f * (maximum + minimum);
    scale = 0.5f * (maximum - minimum) / drawable_half;
    if (scale < 1.0e-6f)
    {
        scale = 1.0f;
    }
    {
        int32_t zero_y = center_y + (int32_t)(center / scale);
        if ((zero_y > (int32_t)GVIEW_PLOT_Y0) &&
            (zero_y < (int32_t)GVIEW_PLOT_Y1))
        {
            lcd_draw_line(GVIEW_PLOT_X0 + 1U, (uint16_t)zero_y,
                          GVIEW_PLOT_X1 - 1U, (uint16_t)zero_y, GRAY);
        }
    }
    for (point = 1U; point < s_periods; point++)
    {
        uint16_t x = GVIEW_PLOT_X0 + (uint16_t)(
            ((uint32_t)(GVIEW_PLOT_WIDTH - 1U) * point) / s_periods);
        uint16_t y;
        for (y = GVIEW_PLOT_Y0 + 2U; y < GVIEW_PLOT_Y1; y += 4U)
        {
            lcd_draw_point(x, y, LGRAY);
        }
    }
    for (point = 1U; point < GVIEW_PLOT_WIDTH; point++)
    {
        int32_t y0 = center_y -
            (int32_t)((s_wave_points[point - 1U] - center) / scale);
        int32_t y1 = center_y -
            (int32_t)((s_wave_points[point] - center) / scale);

        if (y0 < (int32_t)GVIEW_PLOT_Y0 + 1)
        {
            y0 = (int32_t)GVIEW_PLOT_Y0 + 1;
        }
        if (y0 > (int32_t)GVIEW_PLOT_Y1 - 1)
        {
            y0 = (int32_t)GVIEW_PLOT_Y1 - 1;
        }
        if (y1 < (int32_t)GVIEW_PLOT_Y0 + 1)
        {
            y1 = (int32_t)GVIEW_PLOT_Y0 + 1;
        }
        if (y1 > (int32_t)GVIEW_PLOT_Y1 - 1)
        {
            y1 = (int32_t)GVIEW_PLOT_Y1 - 1;
        }
        lcd_draw_line(GVIEW_PLOT_X0 + point - 1U, (uint16_t)y0,
                      GVIEW_PLOT_X0 + point, (uint16_t)y1, BLUE);
    }
}

static void GView_DrawSpectrum(void)
{
    uint16_t baseline = GVIEW_PLOT_Y1 - 18U;
    uint16_t top = GVIEW_PLOT_Y0 + 12U;
    const float minimum_frequency = 10000.0f;
    const float maximum_frequency = 500000.0f;
    float maximum_amplitude = 0.0f;
    char line[24];
    uint8_t component;

    for (component = 0U;
         component < g_measure_result.component_count; component++)
    {
        if (g_measure_result.component[component].amplitude_mv >
            maximum_amplitude)
        {
            maximum_amplitude =
                g_measure_result.component[component].amplitude_mv;
        }
    }
    if (maximum_amplitude < 1.0e-6f)
    {
        maximum_amplitude = 1.0f;
    }

    lcd_draw_line(GVIEW_PLOT_X0 + 1U, baseline,
                  GVIEW_PLOT_X1 - 1U, baseline, BLACK);
    for (component = 0U;
         component < g_measure_result.component_count; component++)
    {
        float normalized_frequency =
            (g_measure_result.component[component].frequency_hz -
             minimum_frequency) /
            (maximum_frequency - minimum_frequency);
        uint16_t x;
        uint16_t height = (uint16_t)((float)(baseline - top) *
            g_measure_result.component[component].amplitude_mv /
            maximum_amplitude);
        uint16_t label_x;
        uint16_t label_y = (uint16_t)(top + (component & 1U) * 12U);

        if (normalized_frequency < 0.0f)
        {
            normalized_frequency = 0.0f;
        }
        else if (normalized_frequency > 1.0f)
        {
            normalized_frequency = 1.0f;
        }
        x = GVIEW_PLOT_X0 + 2U + (uint16_t)(
            (float)(GVIEW_PLOT_WIDTH - 6U) * normalized_frequency);
        if (x > GVIEW_PLOT_X1 - 2U)
        {
            x = GVIEW_PLOT_X1 - 2U;
        }
        label_x = (x > GVIEW_PLOT_X1 - 22U) ?
                  (GVIEW_PLOT_X1 - 22U) : x;

        lcd_draw_line(x, baseline, x, baseline - height, RED);
        lcd_draw_line(x + 1U, baseline, x + 1U, baseline - height, RED);
        sprintf(line, "H%u", (unsigned int)
                g_measure_result.component[component].harmonic_order);
        lcd_show_string(label_x, label_y, 20U, 12U, 12U,
                        line, MAGENTA);
    }
    lcd_show_string(GVIEW_PLOT_X0 + 2U, baseline + 2U,
                    24U, 12U, 12U, "10k", GRAY);
    sprintf(line, "%.0fk", (double)(maximum_frequency / 1000.0f));
    lcd_show_string(GVIEW_PLOT_X1 - 46U, baseline + 2U,
                    45U, 12U, 12U, line, GRAY);
    lcd_show_string(GVIEW_PLOT_X0 + 2U, GVIEW_PLOT_Y0 + 2U,
                    42U, 12U, 12U, "mVpk", GRAY);
}

static void GView_DrawParameters(void)
{
    char line[40];
    uint8_t component;

    lcd_fill(0U, 182U, 239U, 298U, WHITE);
    sprintf(line, "Upp(total):%6.2f Urms:%6.2fmV",
            (double)g_measure_result.upp_mv,
            (double)g_measure_result.rms_mv);
    lcd_show_string(5U, 184U, 235U, 12U, 12U, line, BLUE);

    sprintf(line, "Bias:%7.3fV VDDA:%7.3fV",
            (double)(g_measure_result.bias_mv / 1000.0f),
            (double)(g_measure_result.vdda_mv / 1000.0f));
    lcd_show_string(5U, 198U, 235U, 12U, 12U, line, DARKBLUE);

    for (component = 0U; component < GMEAS_MAX_COMPONENTS; component++)
    {
        uint16_t y = 214U + (uint16_t)component * 20U;
        if (component < g_measure_result.component_count)
        {
            sprintf(line, "H%u %7.1fkHz %8.2fmVpk",
                    (unsigned int)g_measure_result.component[component].
                        harmonic_order,
                    (double)(roundf(
                        g_measure_result.component[component].frequency_hz /
                        GMEAS_FREQUENCY_GRID_HZ) *
                        GMEAS_FREQUENCY_GRID_HZ / 1000.0f),
                    (double)g_measure_result.component[component].
                        amplitude_mv);
            lcd_show_string(5U, y, 235U, 12U, 12U, line,
                            (component == 0U) ? BLUE : MAGENTA);
        }
    }
    sprintf(line, "ub only  AJ:removed");
    lcd_show_string(5U, 274U, 235U, 12U, 12U, line, RED);
    sprintf(line, "res:%.2fmV time:%lums %u/%u",
            (double)g_measure_result.fit_residual_mv,
            (unsigned long)g_measure_result.elapsed_ms,
            (unsigned int)g_measure_result.valid_frames,
            (unsigned int)g_measure_result.attempted_frames);
    lcd_show_string(5U, 288U, 235U, 12U, 12U, line, GRAY);
}

void GView_Init(void)
{
    s_mode = GVIEW_MODE_WAVE;
    s_periods = 1U;
    g_back_color = WHITE;
}

void GView_ShowIdle(void)
{
    char line[40];

    lcd_clear(WHITE);
    GView_Title("IDLE");
    lcd_show_string(28U, 68U, 190U, 24U, 24U,
                    "G SIGNAL METER", BLUE);
    lcd_show_string(42U, 118U, 170U, 16U, 16U,
                    "KEY0: START", RED);
    lcd_show_string(42U, 150U, 170U, 16U, 16U,
#if GMEAS_FRONTEND_X10_ENABLED
                    "KEY2: SOFTWARE AJ x1", MAGENTA);
#else
                    "INPUT: DIRECT x1", MAGENTA);
#endif
    lcd_show_string(25U, 190U, 200U, 12U, 12U,
                    "ADC: PA5   P10: OPEN", DARKBLUE);
    sprintf(line, "%s  input x%.0f",
            (GMeasure_GetInputMode() == GMEASURE_INPUT_DIRECT) ?
            "DIRECT" : "FRONTEND",
            (double)GMeasure_GetInputGain());
    lcd_show_string(25U, 210U, 200U, 12U, 12U,
                    line, DARKBLUE);
}

void GView_ShowMeasuring(void)
{
    char line[40];
    const char *stage;
    gmeasure_state_t state = GMeasure_GetState();

    if (state == GMEASURE_STATE_ACCUMULATING)
    {
        stage = "CONFIRMING";
    }
    else
    {
        stage = "FIND SIGNAL";
    }

    lcd_clear(WHITE);
    GView_Title("MEASURE");
    lcd_show_string(45U, 92U, 170U, 24U, 24U,
                    (char *)stage, BLUE);
    sprintf(line, "Progress: %u%%", (unsigned int)GMeasure_GetProgress());
    lcd_show_string(60U, 136U, 140U, 16U, 16U,
                    line, DARKBLUE);
    sprintf(line, "%s %s x%.0f",
            (GMeasure_GetRunMode() == GMEASURE_RUN_SOFT_AJ_X1) ?
            "SOFT-AJ" : "NORMAL",
            (GMeasure_GetInputMode() == GMEASURE_INPUT_DIRECT) ?
            "DIRECT" : "FRONTEND",
            (double)GMeasure_GetInputGain());
    lcd_show_string(65U, 168U, 150U, 12U, 12U,
                    line, MAGENTA);
    lcd_show_string(35U, 235U, 180U, 12U, 12U,
                    "Result freezes automatically", GRAY);
    lcd_show_string(5U, 304U, 235U, 12U, 12U,
                    "K0:Restart", GRAY);
}

void GView_ShowResult(void)
{
    char line[40];

    if ((g_measure_result.valid == 0U) ||
        (g_measure_result.component_count == 0U))
    {
        GView_ShowFailure(GMeasure_GetStatus(), GMeasure_GetError());
        return;
    }
    lcd_clear(WHITE);
    GView_Title("FROZEN");
    sprintf(line, "f1=%.1fHz N=%u %s %s x%.0f",
            (double)g_measure_result.fundamental_hz,
            (unsigned int)g_measure_result.component_count,
            (s_mode == GVIEW_MODE_WAVE) ?
            ((s_periods == 1U) ? "1T" : "3T") : "SPEC",
            (g_measure_result.run_mode == GMEASURE_RUN_SOFT_AJ_X1) ?
            "AJ" : "NORM",
            (double)GMeasure_GetInputGain());
    lcd_show_string(5U, 22U, 235U, 12U, 12U, line, BLUE);

    GView_DrawFrame();
    if (s_mode == GVIEW_MODE_WAVE)
    {
        GView_DrawWaveform();
    }
    else
    {
        GView_DrawSpectrum();
    }
    GView_DrawParameters();
    lcd_show_string(5U, 304U, 235U, 12U, 12U,
                    "K0:x1 K1:View K2:AJ WK:1/3T", GRAY);
}

void GView_ShowFailure(gmeasure_status_t status, uint32_t error_code)
{
    char line[40];

    lcd_clear(WHITE);
    GView_Title("STOPPED");
    lcd_show_string(30U, 92U, 205U, 24U, 24U,
                    (char *)GView_StatusText(status), RED);
    sprintf(line, "Code: 0x%08lX", (unsigned long)error_code);
    lcd_show_string(48U, 138U, 175U, 16U, 16U,
                    line, DARKBLUE);
    sprintf(line, "Elapsed:%lums Frames:%u",
            (unsigned long)g_measure_result.elapsed_ms,
            (unsigned int)g_measure_result.attempted_frames);
    lcd_show_string(32U, 168U, 190U, 12U, 12U,
                    line, DARKBLUE);
    sprintf(line, "Analysis CPU:%luus",
            (unsigned long)g_measure_result.analysis_time_us);
    lcd_show_string(32U, 186U, 190U, 12U, 12U,
                    line, DARKBLUE);
    sprintf(line, "ADC:%u..%u Mean:%u",
            (unsigned int)g_measure_result.adc_min_code,
            (unsigned int)g_measure_result.adc_max_code,
            (unsigned int)g_measure_result.adc_mean_code);
    lcd_show_string(20U, 208U, 215U, 12U, 12U, line, DARKBLUE);
    sprintf(line, "Clip:%u Stage:%s",
            (unsigned int)g_measure_result.adc_clipped_samples,
            GView_DiagnosticStageText(g_measure_result.diagnostic_stage));
    lcd_show_string(20U, 226U, 215U, 12U, 12U, line, DARKBLUE);
    sprintf(line, "Reason:%s",
            GView_DiagnosticReasonText(g_measure_result.diagnostic_reason));
    lcd_show_string(20U, 244U, 215U, 12U, 12U, line, DARKBLUE);
    lcd_show_string(32U, 270U, 190U, 12U, 12U,
                    "KEY0: Measure again", GRAY);
    lcd_show_string(5U, 304U, 235U, 12U, 12U,
                    "K0:x1 K2:SOFT-AJ x1", GRAY);
}

void GView_ToggleMode(void)
{
    if (GMeasure_GetState() != GMEASURE_STATE_READY)
    {
        return;
    }
    s_mode = (s_mode == GVIEW_MODE_WAVE) ?
             GVIEW_MODE_SPECTRUM : GVIEW_MODE_WAVE;
    GView_ShowResult();
}

void GView_TogglePeriods(void)
{
    if ((GMeasure_GetState() != GMEASURE_STATE_READY) ||
        (s_mode != GVIEW_MODE_WAVE))
    {
        return;
    }
    s_periods = (s_periods == 1U) ? 3U : 1U;
    GView_ShowResult();
}
