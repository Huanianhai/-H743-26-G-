/**
 ****************************************************************************************************
 * @file        g_measure.h
 * @brief       G题周期信号稳定测量核心
 ****************************************************************************************************
 */

#ifndef __G_MEASURE_H
#define __G_MEASURE_H

#include <stdint.h>

#define GMEAS_MAX_COMPONENTS          3U
#define GMEAS_FREQUENCY_GRID_HZ       500.0f

/* 当前用信号发生器直接向PA5输入0.5~2.5Vpp，模拟前端x10后的ADC电压。 */
#define GMEAS_FRONTEND_X10_ENABLED    0U

typedef enum
{
    GMEASURE_INPUT_DIRECT = 0,
    GMEASURE_INPUT_FRONTEND_X10
} gmeasure_input_mode_t;

typedef enum
{
    GMEASURE_RUN_NORMAL_X1 = 0,
    GMEASURE_RUN_SOFT_AJ_X1
} gmeasure_run_mode_t;

typedef enum
{
    GMEASURE_STATUS_OK = 0,
    GMEASURE_STATUS_NO_SIGNAL,
    GMEASURE_STATUS_CLIPPED,
    GMEASURE_STATUS_BAD_HARMONICS,
    GMEASURE_STATUS_UNSTABLE,
    GMEASURE_STATUS_TIMEOUT,
    GMEASURE_STATUS_ADC_ERROR,
    GMEASURE_STATUS_VREF_ERROR,
    GMEASURE_STATUS_FIT_ERROR,
    GMEASURE_STATUS_INTERFERENCE
} gmeasure_status_t;

typedef enum
{
    GMEASURE_STATE_IDLE = 0,
    GMEASURE_STATE_DISCOVERING,
    GMEASURE_STATE_ACCUMULATING,
    GMEASURE_STATE_READY,
    GMEASURE_STATE_FAILED
} gmeasure_state_t;

typedef enum
{
    GMEASURE_DIAG_STAGE_NONE = 0,
    GMEASURE_DIAG_STAGE_DISCOVERY,
    GMEASURE_DIAG_STAGE_CONFIRMATION
} gmeasure_diag_stage_t;

typedef enum
{
    GMEASURE_DIAG_REASON_NONE = 0,
    GMEASURE_DIAG_REASON_CLIPPED,
    GMEASURE_DIAG_REASON_NO_SIGNAL,
    GMEASURE_DIAG_REASON_BAD_MODEL,
    GMEASURE_DIAG_REASON_FIT_ERROR,
    GMEASURE_DIAG_REASON_IDENTITY,
    GMEASURE_DIAG_REASON_UNSTABLE,
    GMEASURE_DIAG_REASON_DEADLINE,
    GMEASURE_DIAG_REASON_JAM_UNRESOLVED
} gmeasure_diag_reason_t;

typedef struct
{
    float frequency_hz;
    float amplitude_mv;
    float phase_degrees;
    float relative_phase_degrees;
    uint16_t fft_bin;
    uint8_t harmonic_order;
} gmeasure_component_t;

typedef struct
{
    uint8_t valid;
    uint8_t frozen;
    uint8_t component_count;
    uint8_t valid_frames;
    uint8_t attempted_frames;
    uint8_t interference_detected;
    uint8_t interference_aliased;
    gmeasure_status_t status;
    gmeasure_run_mode_t run_mode;
    float fundamental_hz;
    float sample_rate_hz;
    float upp_mv;
    float rms_mv;
    float sample_rms_mv;
    float bias_mv;
    float vdda_mv;
    float fit_residual_mv;
    float interference_frequency_hz;
    float interference_amplitude_mv;
    float interference_residual_mv;
    uint32_t elapsed_ms;
    uint32_t analysis_time_us;
    uint16_t adc_min_code;
    uint16_t adc_max_code;
    uint16_t adc_mean_code;
    uint16_t adc_clipped_samples;
    gmeasure_diag_stage_t diagnostic_stage;
    gmeasure_diag_reason_t diagnostic_reason;
    gmeasure_component_t component[GMEAS_MAX_COMPONENTS];
} gmeasure_result_t;

extern gmeasure_result_t g_measure_result;

uint8_t GMeasure_Init(void);
uint8_t GMeasure_Begin(void);
uint8_t GMeasure_BeginMode(gmeasure_run_mode_t run_mode);
gmeasure_state_t GMeasure_Poll(void);
void GMeasure_Abort(void);
gmeasure_state_t GMeasure_GetState(void);
gmeasure_status_t GMeasure_GetStatus(void);
uint32_t GMeasure_GetError(void);
uint8_t GMeasure_GetProgress(void);
void GMeasure_ToggleInputMode(void);
gmeasure_input_mode_t GMeasure_GetInputMode(void);
float GMeasure_GetInputGain(void);
gmeasure_run_mode_t GMeasure_GetRunMode(void);
void GMeasure_Print(void);

#endif
