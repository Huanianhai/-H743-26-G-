/**
 ****************************************************************************************************
 * @file        g_interference.c
 * @brief       G题第三问单频干扰检测与时域相消
 ****************************************************************************************************
 */

#include "g_interference.h"
#include "g_signal.h"
#include <math.h>
#include <stddef.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846f
#endif

#define GINT_PEAK_MASK_BINS       8U
#define GINT_NOISE_MULTIPLIER     6.0f
#define GINT_RELATIVE_THRESHOLD   0.002f
#define GINT_ABSOLUTE_FLOOR       256.0f
#define GINT_SOLVER_EPSILON       1.0e-9

static uint8_t GInterference_Solve3(double matrix[3][4], double output[3])
{
    uint8_t pivot;

    for (pivot = 0U; pivot < 3U; pivot++)
    {
        uint8_t best = pivot;
        uint8_t row;
        uint8_t column;

        for (row = (uint8_t)(pivot + 1U); row < 3U; row++)
        {
            if (fabs(matrix[row][pivot]) > fabs(matrix[best][pivot]))
            {
                best = row;
            }
        }
        if (fabs(matrix[best][pivot]) < GINT_SOLVER_EPSILON)
        {
            return 0U;
        }
        if (best != pivot)
        {
            for (column = pivot; column < 4U; column++)
            {
                double temporary = matrix[pivot][column];
                matrix[pivot][column] = matrix[best][column];
                matrix[best][column] = temporary;
            }
        }
        {
            double divisor = matrix[pivot][pivot];
            for (column = pivot; column < 4U; column++)
            {
                matrix[pivot][column] /= divisor;
            }
        }
        for (row = 0U; row < 3U; row++)
        {
            if (row != pivot)
            {
                double factor = matrix[row][pivot];
                for (column = pivot; column < 4U; column++)
                {
                    matrix[row][column] -= factor * matrix[pivot][column];
                }
            }
        }
    }
    output[0] = matrix[0][3];
    output[1] = matrix[1][3];
    output[2] = matrix[2][3];
    return 1U;
}

static uint8_t GInterference_FitTone(const float *data,
                                     uint32_t length,
                                     float sample_rate_hz,
                                     float frequency_hz,
                                     double coefficients[3])
{
    double normal[3][4] = {{0.0}};
    double omega;
    double cosine_step;
    double sine_step;
    double cosine = 1.0;
    double sine = 0.0;
    uint32_t sample;

    if ((data == NULL) || (coefficients == NULL) || (length < 32U) ||
        (sample_rate_hz <= 0.0f) || (frequency_hz <= 0.0f) ||
        (frequency_hz >= 0.49f * sample_rate_hz))
    {
        return 0U;
    }
    omega = 2.0 * M_PI * (double)frequency_hz / (double)sample_rate_hz;
    cosine_step = cos(omega);
    sine_step = sin(omega);

    for (sample = 0U; sample < length; sample++)
    {
        double value = (double)data[sample];
        double next_cosine;
        double next_sine;

        normal[0][0] += 1.0;
        normal[0][1] += cosine;
        normal[0][2] += sine;
        normal[0][3] += value;
        normal[1][1] += cosine * cosine;
        normal[1][2] += cosine * sine;
        normal[1][3] += value * cosine;
        normal[2][2] += sine * sine;
        normal[2][3] += value * sine;

        next_cosine = cosine * cosine_step - sine * sine_step;
        next_sine = cosine * sine_step + sine * cosine_step;
        cosine = next_cosine;
        sine = next_sine;
        if ((sample & 0xFFU) == 0xFFU)
        {
            double magnitude = sqrt(cosine * cosine + sine * sine);
            if (magnitude > 1.0e-12)
            {
                cosine /= magnitude;
                sine /= magnitude;
            }
        }
    }
    normal[1][0] = normal[0][1];
    normal[2][0] = normal[0][2];
    normal[2][1] = normal[1][2];
    return GInterference_Solve3(normal, coefficients);
}

static void GInterference_SortPeaks(ginterference_peak_t *peaks,
                                    uint8_t count)
{
    uint8_t index;

    for (index = 1U; index < count; index++)
    {
        ginterference_peak_t value = peaks[index];
        uint8_t position = index;
        while ((position > 0U) &&
               (peaks[position - 1U].magnitude < value.magnitude))
        {
            peaks[position] = peaks[position - 1U];
            position--;
        }
        peaks[position] = value;
    }
}

uint8_t GInterference_CollectPeaks(const float *spectrum,
                                  uint32_t fft_length,
                                  float sample_rate_hz,
                                  float minimum_frequency_hz,
                                  float maximum_frequency_hz,
                                  ginterference_peak_t *peaks,
                                  uint8_t capacity)
{
    uint32_t mask_low[GINTERFERENCE_MAX_PEAKS];
    uint32_t mask_high[GINTERFERENCE_MAX_PEAKS];
    float bin_width;
    float maximum = 0.0f;
    float noise_mean = 0.0f;
    float threshold;
    uint32_t first_bin;
    uint32_t last_bin;
    uint32_t bin;
    uint8_t count = 0U;

    if ((spectrum == NULL) || (peaks == NULL) || (fft_length < 64U) ||
        (sample_rate_hz <= 0.0f) || (capacity == 0U))
    {
        return 0U;
    }
    if (capacity > GINTERFERENCE_MAX_PEAKS)
    {
        capacity = GINTERFERENCE_MAX_PEAKS;
    }
    bin_width = sample_rate_hz / (float)fft_length;
    first_bin = (uint32_t)ceilf(minimum_frequency_hz / bin_width);
    last_bin = (uint32_t)floorf(maximum_frequency_hz / bin_width);
    if (first_bin < 1U)
    {
        first_bin = 1U;
    }
    if (last_bin >= fft_length / 2U - 1U)
    {
        last_bin = fft_length / 2U - 2U;
    }
    if (first_bin > last_bin)
    {
        return 0U;
    }

    for (bin = first_bin; bin <= last_bin; bin++)
    {
        float value = spectrum[bin];
        noise_mean += value;
        if (value > maximum)
        {
            maximum = value;
        }
    }
    noise_mean /= (float)(last_bin - first_bin + 1U);
    threshold = maximum * GINT_RELATIVE_THRESHOLD;
    if (threshold < noise_mean * GINT_NOISE_MULTIPLIER)
    {
        threshold = noise_mean * GINT_NOISE_MULTIPLIER;
    }
    if (threshold < GINT_ABSOLUTE_FLOOR)
    {
        threshold = GINT_ABSOLUTE_FLOOR;
    }

    while (count < capacity)
    {
        float peak_value = 0.0f;
        uint32_t peak_bin = first_bin;

        for (bin = first_bin; bin <= last_bin; bin++)
        {
            uint8_t masked = 0U;
            uint8_t previous;

            for (previous = 0U; previous < count; previous++)
            {
                if ((bin >= mask_low[previous]) &&
                    (bin <= mask_high[previous]))
                {
                    masked = 1U;
                    break;
                }
            }
            if ((masked == 0U) && (spectrum[bin] > peak_value))
            {
                peak_value = spectrum[bin];
                peak_bin = bin;
            }
        }
        if (peak_value < threshold)
        {
            break;
        }
        peaks[count].bin = (uint16_t)peak_bin;
        peaks[count].magnitude = peak_value;
        peaks[count].frequency_hz = GSignal_ParabolicFrequency(
            spectrum, (uint16_t)peak_bin, sample_rate_hz, fft_length);
        mask_low[count] = (peak_bin > GINT_PEAK_MASK_BINS) ?
                          peak_bin - GINT_PEAK_MASK_BINS : first_bin;
        if (mask_low[count] < first_bin)
        {
            mask_low[count] = first_bin;
        }
        mask_high[count] = peak_bin + GINT_PEAK_MASK_BINS;
        if (mask_high[count] > last_bin)
        {
            mask_high[count] = last_bin;
        }
        count++;
    }
    GInterference_SortPeaks(peaks, count);
    return count;
}

uint8_t GInterference_FindStrongest(const float *spectrum,
                                    uint32_t fft_length,
                                    float sample_rate_hz,
                                    float minimum_frequency_hz,
                                    float maximum_frequency_hz,
                                    ginterference_peak_t *peak)
{
    return (GInterference_CollectPeaks(spectrum, fft_length,
            sample_rate_hz, minimum_frequency_hz, maximum_frequency_hz,
            peak, 1U) == 1U) ? 1U : 0U;
}

uint8_t GInterference_EstimateAndSubtract(float *data,
                                          uint32_t length,
                                          float sample_rate_hz,
                                          float frequency_hz,
                                          ginterference_result_t *result)
{
    double coefficients[3];
    double residual_coefficients[3];
    double omega;
    double cosine_step;
    double sine_step;
    double cosine = 1.0;
    double sine = 0.0;
    uint32_t sample;

    if ((data == NULL) || (result == NULL) ||
        (GInterference_FitTone(data, length, sample_rate_hz,
                               frequency_hz, coefficients) == 0U))
    {
        return 0U;
    }
    omega = 2.0 * M_PI * (double)frequency_hz / (double)sample_rate_hz;
    cosine_step = cos(omega);
    sine_step = sin(omega);
    for (sample = 0U; sample < length; sample++)
    {
        double next_cosine;
        double next_sine;

        data[sample] -= (float)(coefficients[1] * cosine +
                               coefficients[2] * sine);
        next_cosine = cosine * cosine_step - sine * sine_step;
        next_sine = cosine * sine_step + sine * cosine_step;
        cosine = next_cosine;
        sine = next_sine;
        if ((sample & 0xFFU) == 0xFFU)
        {
            double magnitude = sqrt(cosine * cosine + sine * sine);
            if (magnitude > 1.0e-12)
            {
                cosine /= magnitude;
                sine /= magnitude;
            }
        }
    }
    if (GInterference_FitTone(data, length, sample_rate_hz,
                              frequency_hz, residual_coefficients) == 0U)
    {
        return 0U;
    }
    result->frequency_hz = frequency_hz;
    result->amplitude_mv = (float)sqrt(coefficients[1] * coefficients[1] +
                                      coefficients[2] * coefficients[2]);
    result->phase_degrees = (float)(atan2(-coefficients[2], coefficients[1]) *
                                      180.0 / M_PI);
    result->residual_amplitude_mv = (float)sqrt(
        residual_coefficients[1] * residual_coefficients[1] +
        residual_coefficients[2] * residual_coefficients[2]);
    return 1U;
}
