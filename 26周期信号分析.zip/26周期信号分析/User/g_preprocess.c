/**
 ****************************************************************************************************
 * @file        g_preprocess.c
 * @brief       G题测量数据预处理
 ****************************************************************************************************
 */

#include "g_preprocess.h"
#include "./CMSIS/DSP/Include/arm_math.h"

#define GPRE_FFT_LENGTH_LOW   4096U
#define GPRE_FFT_LENGTH_HIGH  8192U

static float s_hann_low[GPRE_FFT_LENGTH_LOW];
static float s_hann_high[GPRE_FFT_LENGTH_HIGH];

static void GPreprocess_BuildHann(float *table, uint32_t length)
{
    uint32_t index;

    for (index = 0U; index < length; index++)
    {
        float angle = 2.0f * PI * (float)index / (float)(length - 1U);
        table[index] = 0.5f - 0.5f * arm_cos_f32(angle);
    }
}

void GPreprocess_Init(void)
{
    GPreprocess_BuildHann(s_hann_low, GPRE_FFT_LENGTH_LOW);
    GPreprocess_BuildHann(s_hann_high, GPRE_FFT_LENGTH_HIGH);
}

void GPreprocess_Convert(const uint16_t *adc_raw, float *output, uint32_t length)
{
    uint32_t index;

    for (index = 0U; index < length; index++)
    {
        output[index] = (float)adc_raw[index];
    }
}

float GPreprocess_RemoveDC(float *data, uint32_t length)
{
    float mean = 0.0f;
    uint32_t index;

    for (index = 0U; index < length; index++)
    {
        mean += data[index];
    }
    mean /= (float)length;

    for (index = 0U; index < length; index++)
    {
        data[index] -= mean;
    }
    return mean;
}

void GPreprocess_ApplyHann(float *data, uint32_t length)
{
    const float *window;
    uint32_t index;

    if (length == GPRE_FFT_LENGTH_LOW)
    {
        window = s_hann_low;
    }
    else if (length == GPRE_FFT_LENGTH_HIGH)
    {
        window = s_hann_high;
    }
    else
    {
        return;
    }
    for (index = 0U; index < length; index++)
    {
        data[index] *= window[index];
    }
}
