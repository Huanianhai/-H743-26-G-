/**
 ****************************************************************************************************
 * @file        g_calibration.h
 * @brief       PA5直连和x10前端的复数频率响应校准
 ****************************************************************************************************
 */

#ifndef __G_CALIBRATION_H
#define __G_CALIBRATION_H

#include <stdint.h>

#define GCAL_MODE_DIRECT          0U
#define GCAL_MODE_FRONTEND_X10    1U

uint8_t GCalibration_Apply(uint8_t input_mode, float frequency_hz,
                           float *cosine_mv, float *sine_mv);
float GCalibration_GetNominalGain(uint8_t input_mode);

#endif
