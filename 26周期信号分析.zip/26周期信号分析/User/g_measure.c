/**
 ****************************************************************************************************
 * @file        g_measure.c
 * @brief       G题周期信号稳定测量核心
 ****************************************************************************************************
 */

#include "g_measure.h"
#include "g_preprocess.h"
#include "g_fft.h"
#include "g_signal.h"
#include "g_harmonic_fit.h"
#include "g_calibration.h"
#include "g_interference.h"
#include "./BSP/ADC/g_measure_adc.h"
#include "./BSP/ADC/g_vref_adc.h"
#include <math.h>
#include <stdio.h>
#include <string.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846f
#endif

#define GMEAS_FFT_LENGTH_LOW             4096U
#define GMEAS_FFT_LENGTH_MAX             8192U
#define GMEAS_MAX_CANDIDATES             8U
#define GMEAS_STABLE_FRAMES              3U
#define GMEAS_MAX_ATTEMPTED_FRAMES       20U
#define GMEAS_WARMUP_FRAMES               1U
#define GMEAS_CLIPPED_FRAMES_TO_FAIL       2U
#define GMEAS_MIN_FREQUENCY_HZ           8000.0f
#define GMEAS_MAX_FREQUENCY_HZ           550000.0f
#define GMEAS_VALID_MIN_FREQUENCY_HZ     9000.0f
#define GMEAS_VALID_MAX_FREQUENCY_HZ     501000.0f
#define GMEAS_MAX_HARMONIC_ORDER         50U
#define GMEAS_PEAK_MASK_BINS             8U
#define GMEAS_PEAK_RELATIVE_THRESHOLD    0.0005f
#define GMEAS_PEAK_NOISE_MULTIPLIER      3.0f
#define GMEAS_PEAK_ABSOLUTE_FLOOR        80.0f
#define GMEAS_DIVIDED_RELATIVE_THRESHOLD 0.0005f
#define GMEAS_DIVIDED_NOISE_MULTIPLIER   3.0f
#define GMEAS_DIVIDED_ABSOLUTE_FLOOR     60.0f
#define GMEAS_DIVIDED_MAX_ORDER          8U
#define GMEAS_MIN_COMPONENT_MV           1.0f
#define GMEAS_NO_SIGNAL_AMPLITUDE_MV     3.0f
#define GMEAS_NO_SIGNAL_RMS_MV           1.5f
#define GMEAS_NO_SIGNAL_FRAMES           3U
#define GMEAS_HARMONIC_TOLERANCE_HZ      500.0f
#define GMEAS_DISCOVERY_IDENTITY_HZ      500.0f
#define GMEAS_STABLE_AMPLITUDE_MV        3.0f
#define GMEAS_STABLE_AMPLITUDE_RATIO     0.05f
#define GMEAS_STABLE_FREQUENCY_HZ        500.0f
#define GMEAS_STABLE_PHASE_DEGREES      10.0f
#define GMEAS_ADC_CLIP_LOW               2U
#define GMEAS_ADC_CLIP_HIGH              4093U
#define GMEAS_ADC_CLIP_SAMPLES           8U
#define GMEAS_ADC_FULL_SCALE_CODE        4095U
#define GMEAS_ADC_FULL_SCALE             4095.0f
#define GMEAS_CAPTURE_TIMEOUT_MS         20U
#define GMEAS_TOTAL_TIMEOUT_MS           1500U
#define GMEAS_UPP_GRID_POINTS            4096U
#define GMEAS_ERROR_START                0x20000000UL
#define GMEAS_ERROR_VREF                 0x10000000UL
#define GMEAS_ERROR_FIT                  0x08000000UL
#define GMEAS_ERROR_DEADLINE             0x04000000UL
#define GMEAS_ERROR_INTERFERENCE         0x02000000UL
#define GMEAS_JAM_SEARCH_MIN_HZ          550000.0f
#define GMEAS_JAM_SEARCH_MAX_HZ          1528000.0f
#define GMEAS_JAM_NYQUIST_FRACTION       0.489f
#define GMEAS_JAM_MATCH_TOLERANCE_HZ     1500.0f
#define GMEAS_JAM_MIN_AMPLITUDE_MV       5.0f
#define GMEAS_JAM_MAX_RESIDUAL_MV        2.0f
#define GMEAS_JAM_MAX_RESIDUAL_RATIO     0.05f

typedef struct
{
    float frequency_hz;
    float magnitude;
    uint16_t bin;
} gmeasure_candidate_t;

typedef struct
{
    float ac_rms_mv;
    uint16_t minimum_code;
    uint16_t maximum_code;
    uint16_t mean_code;
    uint16_t clipped_samples;
} gmeasure_frame_stats_t;

typedef enum
{
    GMEAS_FRAME_OK = 0,
    GMEAS_FRAME_NO_SIGNAL,
    GMEAS_FRAME_CLIPPED,
    GMEAS_FRAME_BAD_MODEL,
    GMEAS_FRAME_FIT_ERROR,
    GMEAS_FRAME_PROBE_MORE
} gmeasure_frame_code_t;

typedef enum
{
    GMEAS_AJ_STAGE_NONE = 0,
    GMEAS_AJ_STAGE_HIGH_PROBE,
    GMEAS_AJ_STAGE_LOW_PROBE,
    GMEAS_AJ_STAGE_LOCKED
} gmeasure_aj_stage_t;

gmeasure_result_t g_measure_result;

static float s_time_data[GMEAS_FFT_LENGTH_MAX];
static float s_fft_input[GMEAS_FFT_LENGTH_MAX];
static float s_fft_output[GMEAS_FFT_LENGTH_MAX];
static float s_spectrum[GMEAS_FFT_LENGTH_MAX / 2U];
static gmeasure_result_t s_discovery_first;
static gmeasure_result_t s_stable_frames[GMEAS_STABLE_FRAMES];
static gmeasure_state_t s_state = GMEASURE_STATE_IDLE;
static gmeasure_status_t s_status = GMEASURE_STATUS_OK;
static gmeasure_input_mode_t s_input_mode = GMEASURE_INPUT_DIRECT;
static gmeasure_run_mode_t s_run_mode = GMEASURE_RUN_NORMAL_X1;
static gadc_gear_t s_measure_gear = GADC_GEAR_LOW;
static uint32_t s_frame_length = GMEAS_FFT_LENGTH_LOW;
static gmeasure_aj_stage_t s_aj_stage = GMEAS_AJ_STAGE_NONE;
static ginterference_peak_t s_high_probe_peaks[GINTERFERENCE_MAX_PEAKS];
static uint8_t s_high_probe_peak_count;
static float s_jam_alias_frequency_hz;
static uint8_t s_jam_is_aliased;
static ginterference_result_t s_last_interference;
static uint8_t s_locked_order[GMEAS_MAX_COMPONENTS];
static uint8_t s_locked_count;
static uint8_t s_stable_count;
static uint8_t s_attempted_frames;
static uint8_t s_no_signal_frames;
static uint8_t s_warmup_frames_remaining;
static uint8_t s_consecutive_clipped_frames;
static float s_search_fundamental_hz;
static float s_vdda_mv = 3300.0f;
static uint32_t s_measurement_started_ms;
static uint32_t s_capture_started_ms;
static uint32_t s_error_code;
static uint64_t s_analysis_cycles;

static float GMeasure_Wrap180(float degrees)
{
    while (degrees > 180.0f)
    {
        degrees -= 360.0f;
    }
    while (degrees <= -180.0f)
    {
        degrees += 360.0f;
    }
    return degrees;
}

static void GMeasure_SortFloat(float *values, uint8_t count)
{
    uint8_t index;

    for (index = 1U; index < count; index++)
    {
        float value = values[index];
        uint8_t position = index;
        while ((position > 0U) && (values[position - 1U] > value))
        {
            values[position] = values[position - 1U];
            position--;
        }
        values[position] = value;
    }
}

static float GMeasure_Median(const float *values, uint8_t count)
{
    float sorted[GMEAS_STABLE_FRAMES];

    memcpy(sorted, values, count * sizeof(float));
    GMeasure_SortFloat(sorted, count);
    return sorted[count / 2U];
}

static float GMeasure_TrimmedMean(const float *values, uint8_t count)
{
    float sorted[GMEAS_STABLE_FRAMES];
    float sum = 0.0f;
    uint8_t first = 0U;
    uint8_t last = count;
    uint8_t index;

    memcpy(sorted, values, count * sizeof(float));
    GMeasure_SortFloat(sorted, count);
    if (count >= 5U)
    {
        first = 1U;
        last = count - 1U;
    }
    for (index = first; index < last; index++)
    {
        sum += sorted[index];
    }
    return sum / (float)(last - first);
}

static float GMeasure_CircularMean(const float *degrees, uint8_t count)
{
    float sine_sum = 0.0f;
    float cosine_sum = 0.0f;
    uint8_t index;

    for (index = 0U; index < count; index++)
    {
        float radians = degrees[index] * (float)M_PI / 180.0f;
        sine_sum += sinf(radians);
        cosine_sum += cosf(radians);
    }
    return atan2f(sine_sum, cosine_sum) * 180.0f / (float)M_PI;
}

static uint8_t GMeasure_IsActive(void)
{
    return ((s_state == GMEASURE_STATE_DISCOVERING) ||
            (s_state == GMEASURE_STATE_ACCUMULATING)) ? 1U : 0U;
}

static void GMeasure_Fail(gmeasure_status_t status, uint32_t error_code)
{
    GADC_Stop();
    s_status = status;
    s_error_code = error_code;
    s_state = GMEASURE_STATE_FAILED;
    g_measure_result.valid = 0U;
    g_measure_result.frozen = 1U;
    g_measure_result.status = status;
    g_measure_result.vdda_mv = s_vdda_mv;
    g_measure_result.attempted_frames = s_attempted_frames;
    g_measure_result.elapsed_ms = HAL_GetTick() - s_measurement_started_ms;
    if (SystemCoreClock >= 1000000UL)
    {
        g_measure_result.analysis_time_us = (uint32_t)(
            s_analysis_cycles / (uint64_t)(SystemCoreClock / 1000000UL));
    }
}

static uint8_t GMeasure_PrepareFrame(uint8_t calculate_fft,
                                     gmeasure_frame_stats_t *stats)
{
    const uint16_t *raw = GADC_GetBuffer();
    float sum = 0.0f;
    float ac_power = 0.0f;
    float mean;
    uint32_t raw_sum = 0U;
    float scale = s_vdda_mv / GMEAS_ADC_FULL_SCALE;
    uint32_t sample;

    stats->minimum_code = GMEAS_ADC_FULL_SCALE_CODE;
    stats->maximum_code = 0U;
    stats->mean_code = 0U;
    stats->clipped_samples = 0U;
    for (sample = 0U; sample < s_frame_length; sample++)
    {
        uint16_t code = raw[sample];

        float millivolts = (float)code * scale;

        raw_sum += code;
        s_time_data[sample] = millivolts;
        sum += millivolts;
        if (code < stats->minimum_code)
        {
            stats->minimum_code = code;
        }
        if (code > stats->maximum_code)
        {
            stats->maximum_code = code;
        }
        if ((code <= GMEAS_ADC_CLIP_LOW) ||
            (code >= GMEAS_ADC_CLIP_HIGH))
        {
            stats->clipped_samples++;
        }
    }

    mean = sum / (float)s_frame_length;
    for (sample = 0U; sample < s_frame_length; sample++)
    {
        float centered = s_time_data[sample] - mean;
        ac_power += centered * centered;
        if (calculate_fft != 0U)
        {
            s_fft_input[sample] = centered;
        }
    }
    stats->ac_rms_mv = sqrtf(ac_power / (float)s_frame_length);
    stats->mean_code = (uint16_t)((raw_sum +
        (s_frame_length / 2U)) / s_frame_length);
    g_measure_result.adc_min_code = stats->minimum_code;
    g_measure_result.adc_max_code = stats->maximum_code;
    g_measure_result.adc_mean_code = stats->mean_code;
    g_measure_result.adc_clipped_samples = stats->clipped_samples;

    if (calculate_fft != 0U)
    {
        GPreprocess_ApplyHann(s_fft_input, s_frame_length);
        GFFT_Process(s_fft_input, s_fft_output, s_spectrum);
    }
    return (stats->clipped_samples >= GMEAS_ADC_CLIP_SAMPLES) ? 0U : 1U;
}

static void GMeasure_RebuildFFT(void)
{
    float mean = 0.0f;
    uint32_t sample;

    for (sample = 0U; sample < s_frame_length; sample++)
    {
        mean += s_time_data[sample];
    }
    mean /= (float)s_frame_length;
    for (sample = 0U; sample < s_frame_length; sample++)
    {
        s_fft_input[sample] = s_time_data[sample] - mean;
    }
    GPreprocess_ApplyHann(s_fft_input, s_frame_length);
    GFFT_Process(s_fft_input, s_fft_output, s_spectrum);
}

static void GMeasure_RecalculateACRms(gmeasure_frame_stats_t *stats)
{
    float mean = 0.0f;
    float power = 0.0f;
    uint32_t sample;

    for (sample = 0U; sample < s_frame_length; sample++)
    {
        mean += s_time_data[sample];
    }
    mean /= (float)s_frame_length;
    for (sample = 0U; sample < s_frame_length; sample++)
    {
        float centered = s_time_data[sample] - mean;
        power += centered * centered;
    }
    stats->ac_rms_mv = sqrtf(power / (float)s_frame_length);
}

static uint8_t GMeasure_RemoveInterference(gmeasure_frame_stats_t *stats,
                                           uint8_t rebuild_fft)
{
    ginterference_result_t interference;

    memset(&interference, 0, sizeof(interference));
    if ((s_run_mode != GMEASURE_RUN_SOFT_AJ_X1) ||
        (s_jam_alias_frequency_hz <= 0.0f))
    {
        memset(&s_last_interference, 0, sizeof(s_last_interference));
        return 1U;
    }
    if (GInterference_EstimateAndSubtract(
            s_time_data, s_frame_length, (float)GADC_GetSampleRate(),
            s_jam_alias_frequency_hz, &interference) == 0U)
    {
        return 0U;
    }
    if ((interference.amplitude_mv < GMEAS_JAM_MIN_AMPLITUDE_MV) ||
        ((interference.residual_amplitude_mv > GMEAS_JAM_MAX_RESIDUAL_MV) &&
         (interference.residual_amplitude_mv >
          interference.amplitude_mv * GMEAS_JAM_MAX_RESIDUAL_RATIO)))
    {
        return 0U;
    }
    s_last_interference = interference;
    GMeasure_RecalculateACRms(stats);
    if (rebuild_fft != 0U)
    {
        GMeasure_RebuildFFT();
    }
    return 1U;
}

static uint8_t GMeasure_FindUnmatchedPeak(
                                      const ginterference_peak_t *peaks,
                                      uint8_t peak_count,
                                      const ginterference_peak_t *reference,
                                      uint8_t reference_count,
                                      ginterference_peak_t *selected)
{
    uint8_t index;
    uint8_t best = 0xFFU;
    float best_score = 0.0f;

    for (index = 0U; index < peak_count; index++)
    {
        uint8_t reference_index;
        uint8_t matched = 0U;
        float score = peaks[index].magnitude /
                      (float)((peaks[index].bin == 0U) ? 1U :
                              peaks[index].bin);
        for (reference_index = 0U; reference_index < reference_count;
             reference_index++)
        {
            if (fabsf(peaks[index].frequency_hz -
                      reference[reference_index].frequency_hz) <=
                GMEAS_JAM_MATCH_TOLERANCE_HZ)
            {
                matched = 1U;
                break;
            }
        }
        if ((matched == 0U) && (score > best_score))
        {
            best = index;
            best_score = score;
        }
    }
    if (best == 0xFFU)
    {
        return 0U;
    }
    *selected = peaks[best];
    return 1U;
}

static uint8_t GMeasure_StartCapture(gadc_gear_t gear,
                                     gmeasure_state_t next_state);

static gmeasure_frame_code_t GMeasure_DiscoverPreparedFrame(
                                      const gmeasure_frame_stats_t *stats,
                                      gmeasure_result_t *result);

static gmeasure_frame_code_t GMeasure_DiscoverAntiJamFrame(
                                      gmeasure_result_t *result)
{
    gmeasure_frame_stats_t stats;
    ginterference_peak_t peak;
    ginterference_peak_t high_peak;
    ginterference_peak_t low_peaks[GINTERFERENCE_MAX_PEAKS];
    uint8_t low_peak_count;
    float sample_rate_hz;

    if (GMeasure_PrepareFrame(1U, &stats) == 0U)
    {
        return GMEAS_FRAME_CLIPPED;
    }
    sample_rate_hz = (float)GADC_GetSampleRate();

    if (s_aj_stage == GMEAS_AJ_STAGE_HIGH_PROBE)
    {
        float maximum_frequency = fminf(GMEAS_JAM_SEARCH_MAX_HZ,
                                        GMEAS_JAM_NYQUIST_FRACTION *
                                        sample_rate_hz);
        if (GInterference_FindStrongest(
                s_spectrum, s_frame_length, sample_rate_hz,
                GMEAS_JAM_SEARCH_MIN_HZ, maximum_frequency, &peak) != 0U)
        {
            s_jam_alias_frequency_hz = peak.frequency_hz;
            s_jam_is_aliased = 0U;
            s_aj_stage = GMEAS_AJ_STAGE_LOCKED;
            if (GMeasure_RemoveInterference(&stats, 1U) == 0U)
            {
                return GMEAS_FRAME_BAD_MODEL;
            }
            return GMeasure_DiscoverPreparedFrame(&stats, result);
        }

        s_high_probe_peak_count = GInterference_CollectPeaks(
            s_spectrum, s_frame_length, sample_rate_hz,
            GMEAS_VALID_MIN_FREQUENCY_HZ, maximum_frequency,
            s_high_probe_peaks, GINTERFERENCE_MAX_PEAKS);
        s_aj_stage = GMEAS_AJ_STAGE_LOW_PROBE;
        (void)GMeasure_StartCapture(GADC_GEAR_LOW,
                                    GMEASURE_STATE_DISCOVERING);
        return GMEAS_FRAME_PROBE_MORE;
    }

    if (s_aj_stage == GMEAS_AJ_STAGE_LOW_PROBE)
    {
        low_peak_count = GInterference_CollectPeaks(
            s_spectrum, s_frame_length, sample_rate_hz,
            GMEAS_VALID_MIN_FREQUENCY_HZ,
            fminf(GMEAS_JAM_SEARCH_MAX_HZ,
                  GMEAS_JAM_NYQUIST_FRACTION * sample_rate_hz),
            low_peaks, GINTERFERENCE_MAX_PEAKS);
        if (GMeasure_FindUnmatchedPeak(low_peaks, low_peak_count,
                                       s_high_probe_peaks,
                                       s_high_probe_peak_count,
                                       &peak) != 0U)
        {
            s_jam_alias_frequency_hz = peak.frequency_hz;
            s_jam_is_aliased = 1U;
        }
        else if (GMeasure_FindUnmatchedPeak(
                     s_high_probe_peaks, s_high_probe_peak_count,
                     low_peaks, low_peak_count, &high_peak) != 0U)
        {
            s_jam_alias_frequency_hz = high_peak.frequency_hz;
            s_jam_is_aliased = 1U;
            s_aj_stage = GMEAS_AJ_STAGE_LOCKED;
            (void)GMeasure_StartCapture(GADC_GEAR_HIGH,
                                        GMEASURE_STATE_DISCOVERING);
            return GMEAS_FRAME_PROBE_MORE;
        }
        else
        {
            /* 干扰可能折叠到直流；此时去直流后不会污染交流测量。 */
            s_jam_alias_frequency_hz = 0.0f;
            s_jam_is_aliased = 1U;
            memset(&s_last_interference, 0, sizeof(s_last_interference));
        }
        s_aj_stage = GMEAS_AJ_STAGE_LOCKED;
        if (GMeasure_RemoveInterference(&stats, 1U) == 0U)
        {
            return GMEAS_FRAME_BAD_MODEL;
        }
        return GMeasure_DiscoverPreparedFrame(&stats, result);
    }

    if (s_aj_stage == GMEAS_AJ_STAGE_LOCKED)
    {
        if (GMeasure_RemoveInterference(&stats, 1U) == 0U)
        {
            return GMEAS_FRAME_BAD_MODEL;
        }
    }
    return GMeasure_DiscoverPreparedFrame(&stats, result);
}

static void GMeasure_SortCandidates(gmeasure_candidate_t *candidates,
                                    uint8_t count)
{
    uint8_t index;

    for (index = 1U; index < count; index++)
    {
        gmeasure_candidate_t value = candidates[index];
        uint8_t position = index;
        while ((position > 0U) &&
               (candidates[position - 1U].frequency_hz > value.frequency_hz))
        {
            candidates[position] = candidates[position - 1U];
            position--;
        }
        candidates[position] = value;
    }
}

static uint8_t GMeasure_FindCandidates(gmeasure_candidate_t *candidates,
                                       float sample_rate_hz)
{
    float bin_width = sample_rate_hz / (float)s_frame_length;
    uint32_t first_bin = (uint32_t)ceilf(GMEAS_MIN_FREQUENCY_HZ / bin_width);
    uint32_t last_bin = (uint32_t)(GMEAS_MAX_FREQUENCY_HZ / bin_width);
    uint32_t mask_low[GMEAS_MAX_CANDIDATES];
    uint32_t mask_high[GMEAS_MAX_CANDIDATES];
    float maximum = 0.0f;
    float noise_mean = 0.0f;
    float threshold;
    uint32_t bin;
    uint8_t count = 0U;

    if (last_bin >= (s_frame_length / 2U - 1U))
    {
        last_bin = s_frame_length / 2U - 2U;
    }
    for (bin = first_bin; bin <= last_bin; bin++)
    {
        float value = s_spectrum[bin];
        noise_mean += value;
        if (value > maximum)
        {
            maximum = value;
        }
    }
    noise_mean /= (float)(last_bin - first_bin + 1U);
    threshold = maximum * GMEAS_PEAK_RELATIVE_THRESHOLD;
    if (threshold < noise_mean * GMEAS_PEAK_NOISE_MULTIPLIER)
    {
        threshold = noise_mean * GMEAS_PEAK_NOISE_MULTIPLIER;
    }
    if (threshold < GMEAS_PEAK_ABSOLUTE_FLOOR)
    {
        threshold = GMEAS_PEAK_ABSOLUTE_FLOOR;
    }

    while (count < GMEAS_MAX_CANDIDATES)
    {
        float peak_value = 0.0f;
        uint32_t peak_bin = first_bin;

        for (bin = first_bin; bin <= last_bin; bin++)
        {
            uint8_t masked = 0U;
            uint8_t previous;

            for (previous = 0U; previous < count; previous++)
            {
                if ((bin >= mask_low[previous]) &&
                    (bin <= mask_high[previous]))
                {
                    masked = 1U;
                    break;
                }
            }
            if ((masked == 0U) && (s_spectrum[bin] > peak_value))
            {
                peak_value = s_spectrum[bin];
                peak_bin = bin;
            }
        }
        if (peak_value < threshold)
        {
            break;
        }

        candidates[count].bin = (uint16_t)peak_bin;
        candidates[count].magnitude = peak_value;
        candidates[count].frequency_hz = GSignal_ParabolicFrequency(
            s_spectrum, (uint16_t)peak_bin, sample_rate_hz,
            s_frame_length);
        mask_low[count] = (peak_bin > GMEAS_PEAK_MASK_BINS) ?
                          (peak_bin - GMEAS_PEAK_MASK_BINS) : first_bin;
        if (mask_low[count] < first_bin)
        {
            mask_low[count] = first_bin;
        }
        mask_high[count] = peak_bin + GMEAS_PEAK_MASK_BINS;
        if (mask_high[count] > last_bin)
        {
            mask_high[count] = last_bin;
        }
        count++;
    }

    GMeasure_SortCandidates(candidates, count);
    return count;
}

static void GMeasure_AddDividedFundamentals(
                                      gmeasure_candidate_t *candidates,
                                      uint8_t *candidate_count,
                                      float sample_rate_hz)
{
    float bin_width = sample_rate_hz / (float)s_frame_length;
    uint32_t first_bin = (uint32_t)ceilf(GMEAS_MIN_FREQUENCY_HZ / bin_width);
    uint32_t last_bin = (uint32_t)(GMEAS_MAX_FREQUENCY_HZ / bin_width);
    float noise_mean = 0.0f;
    uint8_t original_count = *candidate_count;
    uint32_t bin;
    uint8_t source;

    if (last_bin >= (s_frame_length / 2U - 1U))
    {
        last_bin = s_frame_length / 2U - 2U;
    }
    for (bin = first_bin; bin <= last_bin; bin++)
    {
        noise_mean += s_spectrum[bin];
    }
    noise_mean /= (float)(last_bin - first_bin + 1U);

    for (source = 0U;
         (source < original_count) &&
         (*candidate_count < GMEAS_MAX_CANDIDATES); source++)
    {
        uint8_t divisor;

        for (divisor = 2U;
             (divisor <= GMEAS_DIVIDED_MAX_ORDER) &&
             (*candidate_count < GMEAS_MAX_CANDIDATES); divisor++)
        {
            float expected_frequency = candidates[source].frequency_hz /
                                       (float)divisor;
            uint32_t expected_bin;
            uint32_t search_low;
            uint32_t search_high;
            uint32_t peak_bin;
            float peak_value = 0.0f;
            float threshold = candidates[source].magnitude *
                              GMEAS_DIVIDED_RELATIVE_THRESHOLD;
            uint8_t duplicate = 0U;
            uint8_t existing;

            if (expected_frequency < GMEAS_VALID_MIN_FREQUENCY_HZ)
            {
                break;
            }
            expected_bin = (uint32_t)roundf(expected_frequency / bin_width);
            search_low = (expected_bin > 2U) ? expected_bin - 2U : first_bin;
            if (search_low < first_bin)
            {
                search_low = first_bin;
            }
            search_high = expected_bin + 2U;
            if (search_high > last_bin)
            {
                search_high = last_bin;
            }
            peak_bin = search_low;
            for (bin = search_low; bin <= search_high; bin++)
            {
                if (s_spectrum[bin] > peak_value)
                {
                    peak_value = s_spectrum[bin];
                    peak_bin = bin;
                }
            }
            if (threshold < noise_mean * GMEAS_DIVIDED_NOISE_MULTIPLIER)
            {
                threshold = noise_mean * GMEAS_DIVIDED_NOISE_MULTIPLIER;
            }
            if (threshold < GMEAS_DIVIDED_ABSOLUTE_FLOOR)
            {
                threshold = GMEAS_DIVIDED_ABSOLUTE_FLOOR;
            }
            if (peak_value < threshold)
            {
                continue;
            }

            expected_frequency = GSignal_ParabolicFrequency(
                s_spectrum, (uint16_t)peak_bin, sample_rate_hz,
                s_frame_length);
            for (existing = 0U; existing < *candidate_count; existing++)
            {
                if (fabsf(candidates[existing].frequency_hz -
                          expected_frequency) <=
                    GMEAS_HARMONIC_TOLERANCE_HZ)
                {
                    duplicate = 1U;
                    break;
                }
            }
            if (duplicate == 0U)
            {
                uint8_t added = *candidate_count;
                candidates[added].bin = (uint16_t)peak_bin;
                candidates[added].magnitude = peak_value;
                candidates[added].frequency_hz = expected_frequency;
                *candidate_count = (uint8_t)(added + 1U);
            }
        }
    }
    GMeasure_SortCandidates(candidates, *candidate_count);
}

static uint8_t GMeasure_BuildFrameResult(const ghfit_result_t *fit,
                                         const gmeasure_frame_stats_t *stats,
                                         float sample_rate_hz,
                                         gmeasure_result_t *result)
{
    float model_power = 0.0f;
    float nominal_gain = GCalibration_GetNominalGain((uint8_t)s_input_mode);
    float amplitude_noise = fit->amplitude_noise_mv / nominal_gain;
    uint8_t kept = 0U;
    uint8_t component;

    memset(result, 0, sizeof(*result));
    result->valid = 1U;
    result->status = GMEASURE_STATUS_OK;
    result->run_mode = s_run_mode;
    result->interference_detected =
        (s_last_interference.amplitude_mv >= GMEAS_JAM_MIN_AMPLITUDE_MV) ?
        1U : 0U;
    result->interference_aliased = s_jam_is_aliased;
    result->interference_frequency_hz =
        s_last_interference.frequency_hz;
    result->interference_amplitude_mv =
        s_last_interference.amplitude_mv;
    result->interference_residual_mv =
        s_last_interference.residual_amplitude_mv;
    result->fundamental_hz = fit->fundamental_hz;
    result->sample_rate_hz = sample_rate_hz;
    result->bias_mv = fit->dc_mv;
    result->vdda_mv = s_vdda_mv;
    result->sample_rms_mv = stats->ac_rms_mv / nominal_gain;
    result->fit_residual_mv = fit->residual_rms_mv / nominal_gain;

    for (component = 0U; component < fit->component_count; component++)
    {
        float cosine = fit->cosine_mv[component];
        float sine = fit->sine_mv[component];
        float amplitude;
        float phase;
        float minimum_amplitude = 6.0f * amplitude_noise;
        float frequency = fit->fundamental_hz *
                          (float)fit->harmonic_order[component];

        if ((frequency < GMEAS_VALID_MIN_FREQUENCY_HZ) ||
            (frequency > GMEAS_VALID_MAX_FREQUENCY_HZ))
        {
            return 0U;
        }
        if (minimum_amplitude < GMEAS_MIN_COMPONENT_MV)
        {
            minimum_amplitude = GMEAS_MIN_COMPONENT_MV;
        }
        if (GCalibration_Apply((uint8_t)s_input_mode, frequency,
                               &cosine, &sine) == 0U)
        {
            return 0U;
        }
        amplitude = sqrtf(cosine * cosine + sine * sine);
        if ((component > 0U) && (amplitude < minimum_amplitude))
        {
            continue;
        }
        phase = atan2f(-sine, cosine) * 180.0f / (float)M_PI;
        result->component[kept].frequency_hz = frequency;
        result->component[kept].amplitude_mv = amplitude;
        result->component[kept].phase_degrees = phase;
        result->component[kept].harmonic_order =
            fit->harmonic_order[component];
        result->component[kept].fft_bin = (uint16_t)roundf(
            frequency * (float)s_frame_length / sample_rate_hz);
        model_power += 0.5f * amplitude * amplitude;
        kept++;
    }

    if ((kept == 0U) ||
        (result->component[0].amplitude_mv < GMEAS_NO_SIGNAL_AMPLITUDE_MV))
    {
        return 0U;
    }
    result->component_count = kept;
    result->rms_mv = sqrtf(model_power);
    for (component = 0U; component < result->component_count; component++)
    {
        float relative = result->component[component].phase_degrees -
                         (float)result->component[component].harmonic_order *
                         result->component[0].phase_degrees;
        result->component[component].relative_phase_degrees =
            (component == 0U) ? 0.0f : GMeasure_Wrap180(relative);
    }

    return 1U;
}

static uint8_t GMeasure_SelectHarmonicModel(
                              const gmeasure_candidate_t *candidates,
                              uint8_t candidate_count,
                              float *fundamental_hz,
                              uint8_t *harmonic_order)
{
    float best_score = -1.0f;
    uint8_t best_count = 0U;
    uint8_t base;

    for (base = 0U; base < candidate_count; base++)
    {
        uint8_t matched_index[GMEAS_MAX_CANDIDATES];
        uint8_t matched_order[GMEAS_MAX_CANDIDATES];
        uint8_t selected[GMEAS_MAX_COMPONENTS - 1U];
        uint8_t matched_count = 0U;
        uint8_t selected_count = 0U;
        float score = candidates[base].magnitude;
        uint8_t candidate;

        if ((candidates[base].frequency_hz <
             GMEAS_VALID_MIN_FREQUENCY_HZ) ||
            (candidates[base].frequency_hz >
             GMEAS_VALID_MAX_FREQUENCY_HZ))
        {
            continue;
        }

        for (candidate = 0U; candidate < candidate_count; candidate++)
        {
            int32_t order;
            float difference;
            uint8_t previous;
            uint8_t duplicate = 0U;

            if ((candidate == base) ||
                (candidates[candidate].frequency_hz <=
                 candidates[base].frequency_hz))
            {
                continue;
            }
            order = (int32_t)roundf(
                candidates[candidate].frequency_hz /
                candidates[base].frequency_hz);
            if ((order < 2) ||
                (order > (int32_t)GMEAS_MAX_HARMONIC_ORDER))
            {
                continue;
            }
            difference = fabsf(candidates[candidate].frequency_hz -
                (float)order * candidates[base].frequency_hz);
            if (difference > GMEAS_HARMONIC_TOLERANCE_HZ)
            {
                continue;
            }
            for (previous = 0U; previous < matched_count; previous++)
            {
                if (matched_order[previous] == (uint8_t)order)
                {
                    duplicate = 1U;
                    if (candidates[candidate].magnitude >
                        candidates[matched_index[previous]].magnitude)
                    {
                        matched_index[previous] = candidate;
                    }
                    break;
                }
            }
            if ((duplicate == 0U) &&
                (matched_count < GMEAS_MAX_CANDIDATES))
            {
                matched_index[matched_count] = candidate;
                matched_order[matched_count] = (uint8_t)order;
                matched_count++;
            }
        }

        while ((selected_count < (GMEAS_MAX_COMPONENTS - 1U)) &&
               (selected_count < matched_count))
        {
            float largest = -1.0f;
            uint8_t largest_index = 0U;
            uint8_t match;

            for (match = 0U; match < matched_count; match++)
            {
                uint8_t already_selected = 0U;
                uint8_t previous;

                for (previous = 0U; previous < selected_count; previous++)
                {
                    if (selected[previous] == match)
                    {
                        already_selected = 1U;
                        break;
                    }
                }
                if ((already_selected == 0U) &&
                    (candidates[matched_index[match]].magnitude > largest))
                {
                    largest = candidates[matched_index[match]].magnitude;
                    largest_index = match;
                }
            }
            selected[selected_count++] = largest_index;
            score += candidates[matched_index[largest_index]].magnitude;
        }

        if (score > best_score)
        {
            uint8_t count = (uint8_t)(1U + selected_count);
            uint8_t component;

            best_score = score;
            best_count = count;
            *fundamental_hz = candidates[base].frequency_hz;
            harmonic_order[0] = 1U;
            for (component = 0U; component < selected_count; component++)
            {
                harmonic_order[component + 1U] =
                    matched_order[selected[component]];
            }
            for (component = 2U; component < count; component++)
            {
                uint8_t value = harmonic_order[component];
                uint8_t position = component;
                while ((position > 1U) &&
                       (harmonic_order[position - 1U] > value))
                {
                    harmonic_order[position] =
                        harmonic_order[position - 1U];
                    position--;
                }
                harmonic_order[position] = value;
            }
        }
    }
    return best_count;
}

static gmeasure_frame_code_t GMeasure_DiscoverPreparedFrame(
                                      const gmeasure_frame_stats_t *stats,
                                      gmeasure_result_t *result)
{
    gmeasure_candidate_t candidates[GMEAS_MAX_CANDIDATES];
    float sample_rate_hz = (float)GADC_GetSampleRate();
    float nominal_gain = GCalibration_GetNominalGain((uint8_t)s_input_mode);
    float best_fundamental = 0.0f;
    uint8_t best_order[GMEAS_MAX_COMPONENTS] = {0U};
    uint8_t best_count = 0U;
    uint8_t candidate_count;

    if ((stats->ac_rms_mv / nominal_gain) < GMEAS_NO_SIGNAL_RMS_MV)
    {
        return GMEAS_FRAME_NO_SIGNAL;
    }
    candidate_count = GMeasure_FindCandidates(candidates, sample_rate_hz);
    if (candidate_count == 0U)
    {
        return GMEAS_FRAME_NO_SIGNAL;
    }
    GMeasure_AddDividedFundamentals(candidates, &candidate_count,
                                    sample_rate_hz);

    best_count = GMeasure_SelectHarmonicModel(candidates, candidate_count,
                                              &best_fundamental,
                                              best_order);

    if (best_count == 0U)
    {
        return GMEAS_FRAME_BAD_MODEL;
    }
    {
        ghfit_result_t fit;
        if ((GHFit_Evaluate(s_time_data, s_frame_length, sample_rate_hz,
                            best_fundamental, best_order, best_count, 0U,
                            &fit) == 0U) ||
            (GMeasure_BuildFrameResult(&fit, stats, sample_rate_hz,
                                       result) == 0U))
        {
            return GMEAS_FRAME_FIT_ERROR;
        }
    }
    if (result->component[0].amplitude_mv <
        GMEAS_NO_SIGNAL_AMPLITUDE_MV)
    {
        return GMEAS_FRAME_NO_SIGNAL;
    }
    return GMEAS_FRAME_OK;
}

static gmeasure_frame_code_t GMeasure_DiscoverFrame(
                                      gmeasure_result_t *result)
{
    gmeasure_frame_stats_t stats;

    if (GMeasure_PrepareFrame(1U, &stats) == 0U)
    {
        return GMEAS_FRAME_CLIPPED;
    }
    return GMeasure_DiscoverPreparedFrame(&stats, result);
}

static gmeasure_frame_code_t GMeasure_FitLockedFrame(
                                      gmeasure_result_t *result)
{
    gmeasure_frame_stats_t stats;
    ghfit_result_t fit;
    float sample_rate_hz = (float)GADC_GetSampleRate();

    if (GMeasure_PrepareFrame(0U, &stats) == 0U)
    {
        return GMEAS_FRAME_CLIPPED;
    }
    if ((s_run_mode == GMEASURE_RUN_SOFT_AJ_X1) &&
        (GMeasure_RemoveInterference(&stats, 0U) == 0U))
    {
        return GMEAS_FRAME_BAD_MODEL;
    }
    if (GHFit_Evaluate(s_time_data, s_frame_length, sample_rate_hz,
                       s_search_fundamental_hz, s_locked_order,
                       s_locked_count, 0U, &fit) == 0U)
    {
        return GMEAS_FRAME_FIT_ERROR;
    }
    if (GMeasure_BuildFrameResult(&fit, &stats, sample_rate_hz,
                                  result) == 0U)
    {
        return GMEAS_FRAME_BAD_MODEL;
    }
    s_search_fundamental_hz = result->fundamental_hz;
    return GMEAS_FRAME_OK;
}

static uint8_t GMeasure_SameLockedModel(const gmeasure_result_t *first,
                                        const gmeasure_result_t *second)
{
    uint8_t component;

    if (first->component_count != second->component_count)
    {
        return 0U;
    }
    for (component = 0U; component < first->component_count; component++)
    {
        if ((first->component[component].harmonic_order !=
             second->component[component].harmonic_order) ||
            (fabsf(first->component[component].frequency_hz -
                   second->component[component].frequency_hz) >
             GMEAS_DISCOVERY_IDENTITY_HZ))
        {
            return 0U;
        }
    }
    return 1U;
}

static void GMeasure_AddStableFrame(const gmeasure_result_t *frame)
{
    if (s_stable_count < GMEAS_STABLE_FRAMES)
    {
        s_stable_frames[s_stable_count++] = *frame;
    }
    else
    {
        memmove(&s_stable_frames[0], &s_stable_frames[1],
                (GMEAS_STABLE_FRAMES - 1U) * sizeof(gmeasure_result_t));
        s_stable_frames[GMEAS_STABLE_FRAMES - 1U] = *frame;
    }
}

static uint8_t GMeasure_FramesAreStable(void)
{
    float values[GMEAS_STABLE_FRAMES];
    float median;
    uint8_t frame;
    uint8_t component;

    if (s_stable_count < GMEAS_STABLE_FRAMES)
    {
        return 0U;
    }
    for (frame = 0U; frame < GMEAS_STABLE_FRAMES; frame++)
    {
        values[frame] = s_stable_frames[frame].fundamental_hz;
    }
    median = GMeasure_Median(values, GMEAS_STABLE_FRAMES);
    for (frame = 0U; frame < GMEAS_STABLE_FRAMES; frame++)
    {
        for (component = 0U; component < s_locked_count; component++)
        {
            if (fabsf(s_stable_frames[frame].fundamental_hz - median) *
                (float)s_locked_order[component] >
                GMEAS_STABLE_FREQUENCY_HZ)
            {
                return 0U;
            }
        }
    }

    for (component = 0U; component < s_locked_count; component++)
    {
        float tolerance;
        for (frame = 0U; frame < GMEAS_STABLE_FRAMES; frame++)
        {
            values[frame] =
                s_stable_frames[frame].component[component].amplitude_mv;
        }
        median = GMeasure_Median(values, GMEAS_STABLE_FRAMES);
        tolerance = GMEAS_STABLE_AMPLITUDE_RATIO * median;
        if (tolerance < GMEAS_STABLE_AMPLITUDE_MV)
        {
            tolerance = GMEAS_STABLE_AMPLITUDE_MV;
        }
        for (frame = 0U; frame < GMEAS_STABLE_FRAMES; frame++)
        {
            if (fabsf(values[frame] - median) > tolerance)
            {
                return 0U;
            }
            if ((component > 0U) &&
                (fabsf(GMeasure_Wrap180(
                    s_stable_frames[frame].component[component].
                        relative_phase_degrees -
                    s_stable_frames[0].component[component].
                        relative_phase_degrees)) >
                 GMEAS_STABLE_PHASE_DEGREES))
            {
                return 0U;
            }
        }
    }
    return 1U;
}

static void GMeasure_ComputeUpp(gmeasure_result_t *result)
{
    float minimum = 1.0e30f;
    float maximum = -1.0e30f;
    uint32_t point;

    for (point = 0U; point < GMEAS_UPP_GRID_POINTS; point++)
    {
        float theta = 2.0f * (float)M_PI * (float)point /
                      (float)GMEAS_UPP_GRID_POINTS;
        float voltage = 0.0f;
        uint8_t component;

        for (component = 0U; component < result->component_count; component++)
        {
            float phase = result->component[component].relative_phase_degrees *
                          (float)M_PI / 180.0f;
            voltage += result->component[component].amplitude_mv *
                       cosf((float)result->component[component].harmonic_order *
                            theta + phase);
        }
        if (voltage < minimum)
        {
            minimum = voltage;
        }
        if (voltage > maximum)
        {
            maximum = voltage;
        }
    }
    result->upp_mv = maximum - minimum;
}

static void GMeasure_Finalize(void)
{
    float values[GMEAS_STABLE_FRAMES];
    float jam_frequency_values[GMEAS_STABLE_FRAMES];
    float jam_amplitude_values[GMEAS_STABLE_FRAMES];
    float jam_residual_values[GMEAS_STABLE_FRAMES];
    float power = 0.0f;
    uint16_t adc_min_code = g_measure_result.adc_min_code;
    uint16_t adc_max_code = g_measure_result.adc_max_code;
    uint16_t adc_mean_code = g_measure_result.adc_mean_code;
    uint16_t adc_clipped_samples = g_measure_result.adc_clipped_samples;
    gmeasure_diag_stage_t diagnostic_stage =
        g_measure_result.diagnostic_stage;
    uint8_t frame;
    uint8_t component;

    memset(&g_measure_result, 0, sizeof(g_measure_result));
    g_measure_result.valid = 1U;
    g_measure_result.frozen = 1U;
    g_measure_result.status = GMEASURE_STATUS_OK;
    g_measure_result.run_mode = s_run_mode;
    g_measure_result.component_count = s_locked_count;
    g_measure_result.valid_frames = s_stable_count;
    g_measure_result.attempted_frames = s_attempted_frames;
    g_measure_result.sample_rate_hz = s_stable_frames[0].sample_rate_hz;
    g_measure_result.vdda_mv = s_vdda_mv;
    g_measure_result.adc_min_code = adc_min_code;
    g_measure_result.adc_max_code = adc_max_code;
    g_measure_result.adc_mean_code = adc_mean_code;
    g_measure_result.adc_clipped_samples = adc_clipped_samples;
    g_measure_result.diagnostic_stage = diagnostic_stage;
    g_measure_result.diagnostic_reason = GMEASURE_DIAG_REASON_NONE;
    g_measure_result.interference_aliased =
        s_stable_frames[0].interference_aliased;

    for (frame = 0U; frame < GMEAS_STABLE_FRAMES; frame++)
    {
        values[frame] = s_stable_frames[frame].fundamental_hz;
    }
    g_measure_result.fundamental_hz =
        GMeasure_TrimmedMean(values, GMEAS_STABLE_FRAMES);
    for (frame = 0U; frame < GMEAS_STABLE_FRAMES; frame++)
    {
        values[frame] = s_stable_frames[frame].bias_mv;
    }
    g_measure_result.bias_mv =
        GMeasure_TrimmedMean(values, GMEAS_STABLE_FRAMES);
    for (frame = 0U; frame < GMEAS_STABLE_FRAMES; frame++)
    {
        values[frame] = s_stable_frames[frame].sample_rms_mv;
    }
    g_measure_result.sample_rms_mv =
        GMeasure_TrimmedMean(values, GMEAS_STABLE_FRAMES);
    for (frame = 0U; frame < GMEAS_STABLE_FRAMES; frame++)
    {
        values[frame] = s_stable_frames[frame].fit_residual_mv;
    }
    g_measure_result.fit_residual_mv =
        GMeasure_TrimmedMean(values, GMEAS_STABLE_FRAMES);

    for (frame = 0U; frame < GMEAS_STABLE_FRAMES; frame++)
    {
        jam_frequency_values[frame] =
            s_stable_frames[frame].interference_frequency_hz;
        jam_amplitude_values[frame] =
            s_stable_frames[frame].interference_amplitude_mv;
        jam_residual_values[frame] =
            s_stable_frames[frame].interference_residual_mv;
    }
    g_measure_result.interference_frequency_hz =
        GMeasure_TrimmedMean(jam_frequency_values, GMEAS_STABLE_FRAMES);
    g_measure_result.interference_amplitude_mv =
        GMeasure_TrimmedMean(jam_amplitude_values, GMEAS_STABLE_FRAMES);
    g_measure_result.interference_residual_mv =
        GMeasure_TrimmedMean(jam_residual_values, GMEAS_STABLE_FRAMES);
    g_measure_result.interference_detected =
        (g_measure_result.interference_amplitude_mv >=
         GMEAS_JAM_MIN_AMPLITUDE_MV) ? 1U : 0U;

    for (component = 0U; component < s_locked_count; component++)
    {
        for (frame = 0U; frame < GMEAS_STABLE_FRAMES; frame++)
        {
            values[frame] =
                s_stable_frames[frame].component[component].amplitude_mv;
        }
        g_measure_result.component[component].amplitude_mv =
            GMeasure_TrimmedMean(values, GMEAS_STABLE_FRAMES);
        for (frame = 0U; frame < GMEAS_STABLE_FRAMES; frame++)
        {
            values[frame] = s_stable_frames[frame].component[component].
                            relative_phase_degrees;
        }
        g_measure_result.component[component].relative_phase_degrees =
            (component == 0U) ? 0.0f :
            GMeasure_CircularMean(values, GMEAS_STABLE_FRAMES);
        g_measure_result.component[component].phase_degrees =
            g_measure_result.component[component].relative_phase_degrees;
        g_measure_result.component[component].harmonic_order =
            s_locked_order[component];
        g_measure_result.component[component].frequency_hz =
            g_measure_result.fundamental_hz *
            (float)s_locked_order[component];
        g_measure_result.component[component].fft_bin = (uint16_t)roundf(
            g_measure_result.component[component].frequency_hz *
            (float)s_frame_length / (float)g_measure_result.sample_rate_hz);
        power += 0.5f *
                 g_measure_result.component[component].amplitude_mv *
                 g_measure_result.component[component].amplitude_mv;
    }
    g_measure_result.rms_mv = sqrtf(power);
    GMeasure_ComputeUpp(&g_measure_result);
    g_measure_result.elapsed_ms = HAL_GetTick() - s_measurement_started_ms;
    if (SystemCoreClock >= 1000000UL)
    {
        g_measure_result.analysis_time_us = (uint32_t)(
            s_analysis_cycles / (uint64_t)(SystemCoreClock / 1000000UL));
    }
    s_status = GMEASURE_STATUS_OK;
    s_state = GMEASURE_STATE_READY;
    GADC_Stop();
}

static uint8_t GMeasure_StartCapture(gadc_gear_t gear,
                                     gmeasure_state_t next_state)
{
    uint32_t frame_length = (gear == GADC_GEAR_HIGH) ?
                            GMEAS_FFT_LENGTH_MAX : GMEAS_FFT_LENGTH_LOW;

    if (GADC_Configure(gear) != HAL_OK)
    {
        GMeasure_Fail(GMEASURE_STATUS_ADC_ERROR, GMEAS_ERROR_START);
        return 0U;
    }
    if (GFFT_SetLength(frame_length) == 0U)
    {
        GMeasure_Fail(GMEASURE_STATUS_FIT_ERROR, GMEAS_ERROR_FIT);
        return 0U;
    }
    s_measure_gear = gear;
    s_frame_length = frame_length;
    GADC_ClearComplete();
    if (GADC_Start() != HAL_OK)
    {
        uint32_t error = GADC_GetError();
        GMeasure_Fail(GMEASURE_STATUS_ADC_ERROR,
                      (error != 0U) ? error : GMEAS_ERROR_START);
        return 0U;
    }
    s_capture_started_ms = HAL_GetTick();
    s_state = next_state;
    return 1U;
}

static void GMeasure_HandleClippedFrame(gmeasure_state_t retry_state)
{
    g_measure_result.diagnostic_reason = GMEASURE_DIAG_REASON_CLIPPED;
    s_consecutive_clipped_frames++;
    if (s_consecutive_clipped_frames >= GMEAS_CLIPPED_FRAMES_TO_FAIL)
    {
        GMeasure_Fail(GMEASURE_STATUS_CLIPPED, 0U);
    }
    else
    {
        (void)GMeasure_StartCapture(s_measure_gear, retry_state);
    }
}

static gmeasure_diag_reason_t GMeasure_FrameDiagnosticReason(
                                      gmeasure_frame_code_t frame_code)
{
    switch (frame_code)
    {
        case GMEAS_FRAME_NO_SIGNAL:
            return GMEASURE_DIAG_REASON_NO_SIGNAL;
        case GMEAS_FRAME_CLIPPED:
            return GMEASURE_DIAG_REASON_CLIPPED;
        case GMEAS_FRAME_BAD_MODEL:
            return GMEASURE_DIAG_REASON_BAD_MODEL;
        case GMEAS_FRAME_FIT_ERROR:
            return GMEASURE_DIAG_REASON_FIT_ERROR;
        default:
            return GMEASURE_DIAG_REASON_NONE;
    }
}

static void GMeasure_ResetSession(void)
{
    memset(&g_measure_result, 0, sizeof(g_measure_result));
    memset(&s_discovery_first, 0, sizeof(s_discovery_first));
    memset(s_stable_frames, 0, sizeof(s_stable_frames));
    memset(s_locked_order, 0, sizeof(s_locked_order));
    s_status = GMEASURE_STATUS_OK;
    s_error_code = 0U;
    s_analysis_cycles = 0U;
    s_locked_count = 0U;
    s_stable_count = 0U;
    s_attempted_frames = 0U;
    s_no_signal_frames = 0U;
    s_warmup_frames_remaining = 0U;
    s_consecutive_clipped_frames = 0U;
    s_search_fundamental_hz = 0.0f;
    s_measure_gear = GADC_GEAR_LOW;
    s_frame_length = GMEAS_FFT_LENGTH_LOW;
    s_aj_stage = GMEAS_AJ_STAGE_NONE;
    s_high_probe_peak_count = 0U;
    s_jam_alias_frequency_hz = 0.0f;
    s_jam_is_aliased = 0U;
    memset(s_high_probe_peaks, 0, sizeof(s_high_probe_peaks));
    memset(&s_last_interference, 0, sizeof(s_last_interference));
}

uint8_t GMeasure_Init(void)
{
    GMeasure_ResetSession();
    s_state = GMEASURE_STATE_IDLE;
    /* 默认保持前两问：PA5接收模拟x10后的电压，结果还原到BNC输入值。 */
    s_input_mode = GMEASURE_INPUT_DIRECT;
    s_run_mode = GMEASURE_RUN_NORMAL_X1;
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    DWT->CYCCNT = 0U;
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
    GPreprocess_Init();
    if ((GFFT_Init() == 0U) ||
        (GFFT_SetLength(GMEAS_FFT_LENGTH_LOW) == 0U))
    {
        s_status = GMEASURE_STATUS_FIT_ERROR;
        s_error_code = GMEAS_ERROR_FIT;
        return 0U;
    }
    if (GADC_Init() != HAL_OK)
    {
        s_status = GMEASURE_STATUS_ADC_ERROR;
        s_error_code = GADC_GetError();
        if (s_error_code == 0U)
        {
            s_error_code = GMEAS_ERROR_START;
        }
        return 0U;
    }
    if (GVREF_Init() != HAL_OK)
    {
        s_status = GMEASURE_STATUS_VREF_ERROR;
        s_error_code = GMEAS_ERROR_VREF | GVREF_GetError();
        return 0U;
    }
    return 1U;
}

uint8_t GMeasure_Begin(void)
{
    return GMeasure_BeginMode(GMEASURE_RUN_NORMAL_X1);
}

uint8_t GMeasure_BeginMode(gmeasure_run_mode_t run_mode)
{
    GADC_Stop();
    GMeasure_ResetSession();
    s_run_mode = run_mode;
    if (run_mode == GMEASURE_RUN_SOFT_AJ_X1)
    {
        s_input_mode = GMEASURE_INPUT_DIRECT;
        s_aj_stage = GMEAS_AJ_STAGE_HIGH_PROBE;
    }
    else
    {
        s_input_mode = GMEASURE_INPUT_DIRECT;
        s_aj_stage = GMEAS_AJ_STAGE_NONE;
    }
    if (GVREF_ReadVddaMv(&s_vdda_mv) != HAL_OK)
    {
        s_measurement_started_ms = HAL_GetTick();
        GMeasure_Fail(GMEASURE_STATUS_VREF_ERROR,
                      GMEAS_ERROR_VREF | GVREF_GetError());
        return 0U;
    }
    s_measurement_started_ms = HAL_GetTick();
    s_warmup_frames_remaining = GMEAS_WARMUP_FRAMES;
    return GMeasure_StartCapture((run_mode == GMEASURE_RUN_SOFT_AJ_X1) ?
                                 GADC_GEAR_HIGH : GADC_GEAR_LOW,
                                 GMEASURE_STATE_DISCOVERING);
}

gmeasure_state_t GMeasure_Poll(void)
{
    gmeasure_result_t frame;
    gmeasure_frame_code_t frame_code;

    if (GMeasure_IsActive() == 0U)
    {
        return s_state;
    }
    if ((HAL_GetTick() - s_measurement_started_ms) >
        GMEAS_TOTAL_TIMEOUT_MS)
    {
        if (g_measure_result.diagnostic_reason == GMEASURE_DIAG_REASON_NONE)
        {
            g_measure_result.diagnostic_reason = GMEASURE_DIAG_REASON_DEADLINE;
        }
        GMeasure_Fail(GMEASURE_STATUS_TIMEOUT, GMEAS_ERROR_DEADLINE);
        return s_state;
    }
    if (GADC_GetError() != HAL_ADC_ERROR_NONE)
    {
        GMeasure_Fail(GMEASURE_STATUS_ADC_ERROR, GADC_GetError());
        return s_state;
    }
    if (GADC_IsComplete() == 0U)
    {
        if ((HAL_GetTick() - s_capture_started_ms) >
            GMEAS_CAPTURE_TIMEOUT_MS)
        {
            GADC_SetTimeoutError();
            GMeasure_Fail(GMEASURE_STATUS_TIMEOUT, GADC_GetError());
        }
        return s_state;
    }

    GADC_Stop();
    GADC_ClearComplete();
    if (s_warmup_frames_remaining > 0U)
    {
        gmeasure_state_t retry_state = s_state;
        s_warmup_frames_remaining--;
        (void)GMeasure_StartCapture(s_measure_gear, retry_state);
        return s_state;
    }
    s_attempted_frames++;

    if (s_state == GMEASURE_STATE_DISCOVERING)
    {
        uint32_t cycle_started = DWT->CYCCNT;
        g_measure_result.diagnostic_stage = GMEASURE_DIAG_STAGE_DISCOVERY;
        if (s_run_mode == GMEASURE_RUN_SOFT_AJ_X1)
        {
            frame_code = GMeasure_DiscoverAntiJamFrame(&frame);
        }
        else
        {
            frame_code = GMeasure_DiscoverFrame(&frame);
        }
        s_analysis_cycles += (uint32_t)(DWT->CYCCNT - cycle_started);
        if (frame_code == GMEAS_FRAME_PROBE_MORE)
        {
            return s_state;
        }
        if (frame_code == GMEAS_FRAME_CLIPPED)
        {
            GMeasure_HandleClippedFrame(GMEASURE_STATE_DISCOVERING);
            return s_state;
        }
        s_consecutive_clipped_frames = 0U;
        if (frame_code == GMEAS_FRAME_NO_SIGNAL)
        {
            g_measure_result.diagnostic_reason =
                GMEASURE_DIAG_REASON_NO_SIGNAL;
            s_no_signal_frames++;
            if (s_no_signal_frames >= GMEAS_NO_SIGNAL_FRAMES)
            {
                GMeasure_Fail(GMEASURE_STATUS_NO_SIGNAL, 0U);
                return s_state;
            }
            (void)GMeasure_StartCapture(s_measure_gear,
                                        GMEASURE_STATE_DISCOVERING);
            return s_state;
        }
        if (frame_code != GMEAS_FRAME_OK)
        {
            g_measure_result.diagnostic_reason =
                GMeasure_FrameDiagnosticReason(frame_code);
            if (s_attempted_frames >= GMEAS_MAX_ATTEMPTED_FRAMES)
            {
                GMeasure_Fail(GMEASURE_STATUS_BAD_HARMONICS,
                              GMEAS_ERROR_FIT);
            }
            else
            {
                (void)GMeasure_StartCapture(s_measure_gear,
                                            GMEASURE_STATE_DISCOVERING);
            }
            return s_state;
        }

        s_no_signal_frames = 0U;
        g_measure_result.diagnostic_reason = GMEASURE_DIAG_REASON_NONE;
        s_discovery_first = frame;
        s_locked_count = frame.component_count;
        s_search_fundamental_hz = frame.fundamental_hz;
        {
            uint8_t component;
            for (component = 0U; component < s_locked_count; component++)
            {
                s_locked_order[component] =
                    frame.component[component].harmonic_order;
            }
        }
        GMeasure_AddStableFrame(&s_discovery_first);
        (void)GMeasure_StartCapture(s_measure_gear,
                                    GMEASURE_STATE_ACCUMULATING);
        return s_state;
    }

    {
        uint32_t cycle_started = DWT->CYCCNT;
        g_measure_result.diagnostic_stage =
            GMEASURE_DIAG_STAGE_CONFIRMATION;
        frame_code = GMeasure_FitLockedFrame(&frame);
        s_analysis_cycles += (uint32_t)(DWT->CYCCNT - cycle_started);
    }
    if (frame_code == GMEAS_FRAME_CLIPPED)
    {
        GMeasure_HandleClippedFrame(GMEASURE_STATE_ACCUMULATING);
        return s_state;
    }
    s_consecutive_clipped_frames = 0U;
    if ((frame_code == GMEAS_FRAME_OK) &&
        (GMeasure_SameLockedModel(&s_discovery_first, &frame) != 0U))
    {
        g_measure_result.diagnostic_reason = GMEASURE_DIAG_REASON_NONE;
        GMeasure_AddStableFrame(&frame);
        if ((s_stable_count >= GMEAS_STABLE_FRAMES) &&
            (GMeasure_FramesAreStable() != 0U))
        {
            GMeasure_Finalize();
            return s_state;
        }
        if (s_stable_count >= GMEAS_STABLE_FRAMES)
        {
            g_measure_result.diagnostic_reason =
                GMEASURE_DIAG_REASON_UNSTABLE;
        }
    }
    else
    {
        g_measure_result.diagnostic_reason =
            (frame_code == GMEAS_FRAME_OK) ?
            GMEASURE_DIAG_REASON_IDENTITY :
            GMeasure_FrameDiagnosticReason(frame_code);
    }
    if (s_attempted_frames >= GMEAS_MAX_ATTEMPTED_FRAMES)
    {
        GMeasure_Fail((s_stable_count >= GMEAS_STABLE_FRAMES) ?
                      GMEASURE_STATUS_UNSTABLE :
                      GMEASURE_STATUS_BAD_HARMONICS,
                      GMEAS_ERROR_FIT);
        return s_state;
    }
    (void)GMeasure_StartCapture(s_measure_gear,
                                GMEASURE_STATE_ACCUMULATING);
    return s_state;
}

void GMeasure_Abort(void)
{
    GADC_Stop();
    GMeasure_ResetSession();
    s_state = GMEASURE_STATE_IDLE;
}

gmeasure_state_t GMeasure_GetState(void)
{
    return s_state;
}

gmeasure_status_t GMeasure_GetStatus(void)
{
    return s_status;
}

uint32_t GMeasure_GetError(void)
{
    return s_error_code;
}

uint8_t GMeasure_GetProgress(void)
{
    if (s_state == GMEASURE_STATE_DISCOVERING)
    {
        return 10U;
    }
    if (s_state == GMEASURE_STATE_ACCUMULATING)
    {
        return (uint8_t)(10U +
            (90U * s_stable_count) / GMEAS_STABLE_FRAMES);
    }
    if ((s_state == GMEASURE_STATE_READY) ||
        (s_state == GMEASURE_STATE_FAILED))
    {
        return 100U;
    }
    return 0U;
}

void GMeasure_ToggleInputMode(void)
{
#if GMEAS_FRONTEND_X10_ENABLED
    if (GMeasure_IsActive() != 0U)
    {
        return;
    }
    s_input_mode = (s_input_mode == GMEASURE_INPUT_DIRECT) ?
                   GMEASURE_INPUT_FRONTEND_X10 :
                   GMEASURE_INPUT_DIRECT;
    GMeasure_ResetSession();
    s_state = GMEASURE_STATE_IDLE;
#else
    s_input_mode = GMEASURE_INPUT_DIRECT;
#endif
}

gmeasure_input_mode_t GMeasure_GetInputMode(void)
{
    return s_input_mode;
}

float GMeasure_GetInputGain(void)
{
    return GCalibration_GetNominalGain((uint8_t)s_input_mode);
}

gmeasure_run_mode_t GMeasure_GetRunMode(void)
{
    return s_run_mode;
}

void GMeasure_Print(void)
{
    uint8_t component;

    if ((g_measure_result.valid == 0U) ||
        (g_measure_result.component_count == 0U))
    {
        printf("测量未得到有效冻结结果，状态=%u，错误=0x%08lX，耗时=%lums，帧=%u，CPU=%luus\r\n",
               (unsigned int)s_status, (unsigned long)s_error_code,
               (unsigned long)g_measure_result.elapsed_ms,
               (unsigned int)g_measure_result.attempted_frames,
               (unsigned long)g_measure_result.analysis_time_us);
        return;
    }
    printf("\r\n--- H743 G题冻结结果，耗时%lums，VDDA=%.1fmV，x%.0f ---\r\n",
           (unsigned long)g_measure_result.elapsed_ms,
           (double)g_measure_result.vdda_mv,
           (double)GMeasure_GetInputGain());
    for (component = 0U;
         component < g_measure_result.component_count; component++)
    {
        printf("H%u  f=%9.1fHz  Amp=%8.3fmVpk  dPhi=%+7.2fdeg\r\n",
               (unsigned int)g_measure_result.component[component].harmonic_order,
               (double)g_measure_result.component[component].frequency_hz,
               (double)g_measure_result.component[component].amplitude_mv,
               (double)g_measure_result.component[component].relative_phase_degrees);
    }
    printf("Upp=%.3fmV  Urms=%.3fmV  Bias(PA5)=%.3fmV  residual=%.3fmV  frames=%u/%u  CPU=%luus\r\n",
           (double)g_measure_result.upp_mv,
           (double)g_measure_result.rms_mv,
           (double)g_measure_result.bias_mv,
           (double)g_measure_result.fit_residual_mv,
           (unsigned int)g_measure_result.valid_frames,
           (unsigned int)g_measure_result.attempted_frames,
           (unsigned long)g_measure_result.analysis_time_us);
}
