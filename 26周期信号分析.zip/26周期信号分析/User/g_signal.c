/**
 ****************************************************************************************************
 * @file        g_signal.c
 * @brief       G题频率、幅值和相位精化工具
 ****************************************************************************************************
 */

#include "g_signal.h"
#include <math.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846f
#endif

void GSignal_Goertzel(const float *data, uint32_t length, float sample_rate,
                      float target_frequency, float *amplitude, float *phase_degrees)
{
    float omega = 2.0f * (float)M_PI * target_frequency / sample_rate;
    float cosine_step = cosf(omega);
    float sine_step = sinf(omega);
    float cosine_n = 1.0f;
    float sine_n = 0.0f;
    float real = 0.0f;
    float imag = 0.0f;
    uint32_t index;

    for (index = 0U; index < length; index++)
    {
        float next_cosine;
        float next_sine;

        real += data[index] * cosine_n;
        imag -= data[index] * sine_n;
        next_cosine = cosine_n * cosine_step - sine_n * sine_step;
        next_sine = cosine_n * sine_step + sine_n * cosine_step;
        cosine_n = next_cosine;
        sine_n = next_sine;
    }

    *amplitude = 2.0f * sqrtf(real * real + imag * imag) / (float)length;
    *phase_degrees = atan2f(imag, real) * 180.0f / (float)M_PI;
}

float GSignal_ParabolicFrequency(const float *spectrum, uint16_t peak_bin,
                                 float sample_rate, uint32_t fft_length)
{
    float bin_width = sample_rate / (float)fft_length;
    float left;
    float center;
    float right;
    float denominator;
    float offset;

    if ((peak_bin == 0U) || ((uint32_t)peak_bin >= (fft_length / 2U - 1U)))
    {
        return (float)peak_bin * bin_width;
    }

    left = logf(fmaxf(spectrum[peak_bin - 1U], 1.0e-20f));
    center = logf(fmaxf(spectrum[peak_bin], 1.0e-20f));
    right = logf(fmaxf(spectrum[peak_bin + 1U], 1.0e-20f));
    denominator = left - 2.0f * center + right;
    if (fabsf(denominator) < 1.0e-9f)
    {
        return (float)peak_bin * bin_width;
    }

    offset = 0.5f * (left - right) / denominator;
    if (offset > 1.0f)
    {
        offset = 1.0f;
    }
    else if (offset < -1.0f)
    {
        offset = -1.0f;
    }
    return ((float)peak_bin + offset) * bin_width;
}
