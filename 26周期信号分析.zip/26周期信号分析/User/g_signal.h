/**
 ****************************************************************************************************
 * @file        g_signal.h
 * @brief       G题频率、幅值和相位精化工具
 ****************************************************************************************************
 */

#ifndef __G_SIGNAL_H
#define __G_SIGNAL_H

#include <stdint.h>

void GSignal_Goertzel(const float *data, uint32_t length, float sample_rate,
                      float target_frequency, float *amplitude, float *phase_degrees);
float GSignal_ParabolicFrequency(const float *spectrum, uint16_t peak_bin,
                                 float sample_rate, uint32_t fft_length);

#endif
