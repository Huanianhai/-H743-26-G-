/**
 ****************************************************************************************************
 * @file        g_harmonic_fit.h
 * @brief       整数谐波联合最小二乘拟合
 ****************************************************************************************************
 */

#ifndef __G_HARMONIC_FIT_H
#define __G_HARMONIC_FIT_H

#include <stdint.h>

#define GHFIT_MAX_COMPONENTS       3U

typedef struct
{
    uint8_t component_count;
    uint8_t harmonic_order[GHFIT_MAX_COMPONENTS];
    float fundamental_hz;
    float dc_mv;
    float cosine_mv[GHFIT_MAX_COMPONENTS];
    float sine_mv[GHFIT_MAX_COMPONENTS];
    float amplitude_mv[GHFIT_MAX_COMPONENTS];
    float phase_degrees[GHFIT_MAX_COMPONENTS];
    float signal_rms_mv;
    float residual_rms_mv;
    float amplitude_noise_mv;
    float r_squared;
} ghfit_result_t;

uint8_t GHFit_Evaluate(const float *data, uint32_t length,
                       float sample_rate_hz, float fundamental_hz,
                       const uint8_t *harmonic_order,
                       uint8_t component_count, uint8_t robust,
                       ghfit_result_t *result);
uint8_t GHFit_Search(const float *data, uint32_t length, float sample_rate_hz,
                     float seed_fundamental_hz, const uint8_t *harmonic_order,
                     uint8_t component_count, uint8_t robust,
                     ghfit_result_t *result);

#endif
