/**
 ****************************************************************************************************
 * @file        g_harmonic_fit.c
 * @brief       整数谐波联合最小二乘拟合
 ****************************************************************************************************
 */

#include "g_harmonic_fit.h"
#include <math.h>
#include <string.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846f
#endif

#define GHFIT_MAX_COLUMNS          (1U + 2U * GHFIT_MAX_COMPONENTS)
#define GHFIT_MEDIAN_SAMPLES       1024U
#define GHFIT_GOLDEN_ITERATIONS    8U
#define GHFIT_MIN_FUNDAMENTAL_HZ   8000.0f
#define GHFIT_MAX_COMPONENT_HZ     550000.0f
#define GHFIT_MIN_HUBER_MV         0.25f
#define GHFIT_PIVOT_EPSILON        1.0e-6f

static float s_normal[GHFIT_MAX_COLUMNS][GHFIT_MAX_COLUMNS];
static float s_rhs[GHFIT_MAX_COLUMNS];
static float s_augmented[GHFIT_MAX_COLUMNS][GHFIT_MAX_COLUMNS + 1U];
static float s_coefficients[GHFIT_MAX_COLUMNS];
static float s_abs_residual[GHFIT_MEDIAN_SAMPLES];

static void GHFit_OscillatorInit(float fundamental_hz, float sample_rate_hz,
                                 const uint8_t *order, uint8_t count,
                                 float *cosine, float *sine,
                                 float *cosine_step, float *sine_step)
{
    uint8_t component;

    for (component = 0U; component < count; component++)
    {
        float angle = 2.0f * (float)M_PI * fundamental_hz *
                      (float)order[component] / sample_rate_hz;
        cosine[component] = 1.0f;
        sine[component] = 0.0f;
        cosine_step[component] = cosf(angle);
        sine_step[component] = sinf(angle);
    }
}

static void GHFit_OscillatorAdvance(float *cosine, float *sine,
                                    const float *cosine_step,
                                    const float *sine_step, uint8_t count,
                                    uint32_t sample)
{
    uint8_t component;

    for (component = 0U; component < count; component++)
    {
        float next_cosine = cosine[component] * cosine_step[component] -
                            sine[component] * sine_step[component];
        float next_sine = cosine[component] * sine_step[component] +
                          sine[component] * cosine_step[component];

        cosine[component] = next_cosine;
        sine[component] = next_sine;
        if ((sample & 0xFFU) == 0xFFU)
        {
            float magnitude = sqrtf(next_cosine * next_cosine +
                                    next_sine * next_sine);
            if (magnitude > 1.0e-12f)
            {
                cosine[component] /= magnitude;
                sine[component] /= magnitude;
            }
        }
    }
}

static uint8_t GHFit_Solve(uint8_t columns)
{
    uint8_t row;
    uint8_t column;

    for (row = 0U; row < columns; row++)
    {
        for (column = 0U; column < columns; column++)
        {
            s_augmented[row][column] = s_normal[row][column];
        }
        s_augmented[row][columns] = s_rhs[row];
    }

    for (column = 0U; column < columns; column++)
    {
        uint8_t pivot_row = column;
        float pivot_value = fabsf(s_augmented[column][column]);

        for (row = (uint8_t)(column + 1U); row < columns; row++)
        {
            float candidate = fabsf(s_augmented[row][column]);
            if (candidate > pivot_value)
            {
                pivot_value = candidate;
                pivot_row = row;
            }
        }
        if (pivot_value < GHFIT_PIVOT_EPSILON)
        {
            return 0U;
        }
        if (pivot_row != column)
        {
            for (row = column; row <= columns; row++)
            {
                float temporary = s_augmented[column][row];
                s_augmented[column][row] = s_augmented[pivot_row][row];
                s_augmented[pivot_row][row] = temporary;
            }
        }

        {
            float pivot = s_augmented[column][column];
            uint8_t target_row;

            for (row = column; row <= columns; row++)
            {
                s_augmented[column][row] /= pivot;
            }
            for (target_row = 0U; target_row < columns; target_row++)
            {
                float factor;
                if (target_row == column)
                {
                    continue;
                }
                factor = s_augmented[target_row][column];
                for (row = column; row <= columns; row++)
                {
                    s_augmented[target_row][row] -=
                        factor * s_augmented[column][row];
                }
            }
        }
    }

    for (row = 0U; row < columns; row++)
    {
        s_coefficients[row] = s_augmented[row][columns];
    }
    return 1U;
}

static uint8_t GHFit_AccumulateAndSolve(const float *data, uint32_t length,
                                        float sample_rate_hz,
                                        float fundamental_hz,
                                        const uint8_t *order, uint8_t count,
                                        const float *reference,
                                        float huber_threshold)
{
    float cosine[GHFIT_MAX_COMPONENTS];
    float sine[GHFIT_MAX_COMPONENTS];
    float cosine_step[GHFIT_MAX_COMPONENTS];
    float sine_step[GHFIT_MAX_COMPONENTS];
    float basis[GHFIT_MAX_COLUMNS];
    uint8_t columns = (uint8_t)(1U + 2U * count);
    uint32_t sample;
    uint8_t row;
    uint8_t column;

    memset(s_normal, 0, sizeof(s_normal));
    memset(s_rhs, 0, sizeof(s_rhs));
    GHFit_OscillatorInit(fundamental_hz, sample_rate_hz, order, count,
                         cosine, sine, cosine_step, sine_step);

    for (sample = 0U; sample < length; sample++)
    {
        float weight = 1.0f;
        uint8_t component;

        basis[0] = 1.0f;
        for (component = 0U; component < count; component++)
        {
            basis[1U + 2U * component] = cosine[component];
            basis[2U + 2U * component] = sine[component];
        }
        if (reference != NULL)
        {
            float predicted = 0.0f;
            float residual;
            for (column = 0U; column < columns; column++)
            {
                predicted += reference[column] * basis[column];
            }
            residual = data[sample] - predicted;
            if (fabsf(residual) > huber_threshold)
            {
                weight = huber_threshold / fabsf(residual);
            }
        }

        for (row = 0U; row < columns; row++)
        {
            float weighted_basis = weight * basis[row];
            s_rhs[row] += weighted_basis * data[sample];
            for (column = 0U; column <= row; column++)
            {
                s_normal[row][column] +=
                    weighted_basis * basis[column];
            }
        }
        GHFit_OscillatorAdvance(cosine, sine, cosine_step, sine_step,
                                count, sample);
    }

    for (row = 0U; row < columns; row++)
    {
        for (column = 0U; column < row; column++)
        {
            s_normal[column][row] = s_normal[row][column];
        }
    }
    return GHFit_Solve(columns);
}

static float GHFit_CalculateResidual(const float *data, uint32_t length,
                                     float sample_rate_hz,
                                     float fundamental_hz,
                                     const uint8_t *order, uint8_t count,
                                     uint8_t collect_median,
                                     float clip_threshold,
                                     float *total_variance)
{
    float cosine[GHFIT_MAX_COMPONENTS];
    float sine[GHFIT_MAX_COMPONENTS];
    float cosine_step[GHFIT_MAX_COMPONENTS];
    float sine_step[GHFIT_MAX_COMPONENTS];
    float residual_power = 0.0f;
    float variance = 0.0f;
    float mean = s_coefficients[0];
    uint32_t median_index = 0U;
    uint32_t sample;
    uint8_t component;

    GHFit_OscillatorInit(fundamental_hz, sample_rate_hz, order, count,
                         cosine, sine, cosine_step, sine_step);
    for (sample = 0U; sample < length; sample++)
    {
        float predicted = s_coefficients[0];
        float residual;
        float centered = data[sample] - mean;

        for (component = 0U; component < count; component++)
        {
            predicted += s_coefficients[1U + 2U * component] *
                         cosine[component];
            predicted += s_coefficients[2U + 2U * component] *
                         sine[component];
        }
        residual = data[sample] - predicted;
        if ((clip_threshold > 0.0f) &&
            (fabsf(residual) > clip_threshold))
        {
            residual = (residual < 0.0) ?
                       -clip_threshold : clip_threshold;
        }
        residual_power += residual * residual;
        variance += centered * centered;
        if ((collect_median != 0U) &&
            ((sample & 0x07U) == 0U) &&
            (median_index < GHFIT_MEDIAN_SAMPLES))
        {
            s_abs_residual[median_index++] = fabsf(residual);
        }
        GHFit_OscillatorAdvance(cosine, sine, cosine_step, sine_step,
                                count, sample);
    }
    if (total_variance != NULL)
    {
        *total_variance = (float)variance;
    }
    return sqrtf(residual_power / (float)length);
}

static float GHFit_Median(uint32_t count)
{
    uint32_t gap;
    uint32_t index;

    for (gap = count / 2U; gap > 0U; gap /= 2U)
    {
        for (index = gap; index < count; index++)
        {
            float value = s_abs_residual[index];
            uint32_t position = index;
            while ((position >= gap) &&
                   (s_abs_residual[position - gap] > value))
            {
                s_abs_residual[position] = s_abs_residual[position - gap];
                position -= gap;
            }
            s_abs_residual[position] = value;
        }
    }
    return s_abs_residual[count / 2U];
}

static uint8_t GHFit_FitAtFrequency(const float *data, uint32_t length,
                                    float sample_rate_hz,
                                    float fundamental_hz,
                                    const uint8_t *order, uint8_t count,
                                    uint8_t robust, ghfit_result_t *result)
{
    float initial_coefficients[GHFIT_MAX_COLUMNS];
    float residual_rms;
    float total_variance;
    float model_power = 0.0f;
    float robust_threshold = 0.0f;
    uint8_t columns = (uint8_t)(1U + 2U * count);
    uint8_t component;

    if (GHFit_AccumulateAndSolve(data, length, sample_rate_hz,
                                 fundamental_hz, order, count,
                                 NULL, 0.0f) == 0U)
    {
        return 0U;
    }

    if (robust != 0U)
    {
        float sigma;
        float threshold;
        uint8_t column;

        (void)GHFit_CalculateResidual(data, length, sample_rate_hz,
                                      fundamental_hz, order, count,
                                      1U, 0.0f, NULL);
        sigma = 1.4826f * GHFit_Median(
                    (length / 8U < GHFIT_MEDIAN_SAMPLES) ?
                    (length / 8U) : GHFIT_MEDIAN_SAMPLES);
        threshold = 3.0f * sigma;
        if (threshold < GHFIT_MIN_HUBER_MV)
        {
            threshold = GHFIT_MIN_HUBER_MV;
        }
        robust_threshold = threshold;
        for (column = 0U; column < columns; column++)
        {
            initial_coefficients[column] = s_coefficients[column];
        }
        if (GHFit_AccumulateAndSolve(data, length, sample_rate_hz,
                                     fundamental_hz, order, count,
                                     initial_coefficients, threshold) == 0U)
        {
            return 0U;
        }
    }

    residual_rms = GHFit_CalculateResidual(data, length, sample_rate_hz,
                                           fundamental_hz, order, count,
                                           0U, robust_threshold,
                                           &total_variance);
    memset(result, 0, sizeof(*result));
    result->component_count = count;
    result->fundamental_hz = fundamental_hz;
    result->dc_mv = (float)s_coefficients[0];
    result->residual_rms_mv = residual_rms;
    result->amplitude_noise_mv = residual_rms *
                                 sqrtf(2.0f / (float)length);

    for (component = 0U; component < count; component++)
    {
        float cosine = (float)s_coefficients[1U + 2U * component];
        float sine = (float)s_coefficients[2U + 2U * component];
        float amplitude = sqrtf(cosine * cosine + sine * sine);

        result->harmonic_order[component] = order[component];
        result->cosine_mv[component] = cosine;
        result->sine_mv[component] = sine;
        result->amplitude_mv[component] = amplitude;
        result->phase_degrees[component] =
            atan2f(-sine, cosine) * 180.0f / (float)M_PI;
        model_power += 0.5f * amplitude * amplitude;
    }
    result->signal_rms_mv = sqrtf(model_power);
    if (total_variance > 1.0e-12f)
    {
        float residual_power = residual_rms * residual_rms * (float)length;
        result->r_squared = 1.0f - residual_power / total_variance;
    }
    return 1U;
}

uint8_t GHFit_Evaluate(const float *data, uint32_t length,
                       float sample_rate_hz, float fundamental_hz,
                       const uint8_t *harmonic_order,
                       uint8_t component_count, uint8_t robust,
                       ghfit_result_t *result)
{
    uint8_t maximum_order;
    uint8_t component;

    if ((data == NULL) || (harmonic_order == NULL) || (result == NULL) ||
        (length < 32U) || (sample_rate_hz <= 0.0f) ||
        (component_count == 0U) ||
        (component_count > GHFIT_MAX_COMPONENTS))
    {
        return 0U;
    }

    maximum_order = harmonic_order[0];
    for (component = 0U; component < component_count; component++)
    {
        if ((harmonic_order[component] == 0U) ||
            ((component > 0U) &&
             (harmonic_order[component] <= harmonic_order[component - 1U])))
        {
            return 0U;
        }
        if (harmonic_order[component] > maximum_order)
        {
            maximum_order = harmonic_order[component];
        }
    }
    if ((fundamental_hz < GHFIT_MIN_FUNDAMENTAL_HZ) ||
        (fundamental_hz * (float)maximum_order >
         GHFIT_MAX_COMPONENT_HZ) ||
        (fundamental_hz * (float)maximum_order >=
         0.48f * sample_rate_hz))
    {
        return 0U;
    }

    return GHFit_FitAtFrequency(data, length, sample_rate_hz,
                                fundamental_hz, harmonic_order,
                                component_count, robust, result);
}

uint8_t GHFit_Search(const float *data, uint32_t length, float sample_rate_hz,
                     float seed_fundamental_hz, const uint8_t *harmonic_order,
                     uint8_t component_count, uint8_t robust,
                     ghfit_result_t *result)
{
    const float golden_ratio = 0.61803398875f;
    ghfit_result_t temporary;
    float maximum_fundamental;
    float half_width;
    float lower;
    float upper;
    float left;
    float right;
    float left_score;
    float right_score;
    float best_frequency;
    uint8_t maximum_order;
    uint8_t iteration;
    uint8_t component;

    if ((data == NULL) || (harmonic_order == NULL) || (result == NULL) ||
        (length < 32U) || (sample_rate_hz <= 0.0f) ||
        (component_count == 0U) ||
        (component_count > GHFIT_MAX_COMPONENTS))
    {
        return 0U;
    }

    maximum_order = harmonic_order[0];
    for (component = 0U; component < component_count; component++)
    {
        if ((harmonic_order[component] == 0U) ||
            ((component > 0U) &&
             (harmonic_order[component] <= harmonic_order[component - 1U])))
        {
            return 0U;
        }
        if (harmonic_order[component] > maximum_order)
        {
            maximum_order = harmonic_order[component];
        }
    }

    maximum_fundamental = GHFIT_MAX_COMPONENT_HZ / (float)maximum_order;
    if ((0.48f * sample_rate_hz / (float)maximum_order) <
        maximum_fundamental)
    {
        maximum_fundamental = 0.48f * sample_rate_hz /
                              (float)maximum_order;
    }
    half_width = 2.0f * sample_rate_hz /
                 ((float)length * (float)maximum_order);
    lower = seed_fundamental_hz - half_width;
    upper = seed_fundamental_hz + half_width;
    if (lower < GHFIT_MIN_FUNDAMENTAL_HZ)
    {
        lower = GHFIT_MIN_FUNDAMENTAL_HZ;
    }
    if (upper > maximum_fundamental)
    {
        upper = maximum_fundamental;
    }
    if (upper <= lower)
    {
        return 0U;
    }

    left = upper - golden_ratio * (upper - lower);
    right = lower + golden_ratio * (upper - lower);
    if (GHFit_FitAtFrequency(data, length, sample_rate_hz, left,
                             harmonic_order, component_count, 0U,
                             &temporary) == 0U)
    {
        return 0U;
    }
    left_score = temporary.residual_rms_mv;
    if (GHFit_FitAtFrequency(data, length, sample_rate_hz, right,
                             harmonic_order, component_count, 0U,
                             &temporary) == 0U)
    {
        return 0U;
    }
    right_score = temporary.residual_rms_mv;

    for (iteration = 0U; iteration < GHFIT_GOLDEN_ITERATIONS; iteration++)
    {
        if (left_score <= right_score)
        {
            upper = right;
            right = left;
            right_score = left_score;
            left = upper - golden_ratio * (upper - lower);
            if (GHFit_FitAtFrequency(data, length, sample_rate_hz, left,
                                     harmonic_order, component_count, 0U,
                                     &temporary) == 0U)
            {
                return 0U;
            }
            left_score = temporary.residual_rms_mv;
        }
        else
        {
            lower = left;
            left = right;
            left_score = right_score;
            right = lower + golden_ratio * (upper - lower);
            if (GHFit_FitAtFrequency(data, length, sample_rate_hz, right,
                                     harmonic_order, component_count, 0U,
                                     &temporary) == 0U)
            {
                return 0U;
            }
            right_score = temporary.residual_rms_mv;
        }
    }

    best_frequency = (left_score <= right_score) ? left : right;
    return GHFit_FitAtFrequency(data, length, sample_rate_hz,
                                best_frequency, harmonic_order,
                                component_count, robust, result);
}
