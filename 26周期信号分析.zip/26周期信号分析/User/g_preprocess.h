/**
 ****************************************************************************************************
 * @file        g_preprocess.h
 * @brief       G题测量数据预处理
 ****************************************************************************************************
 */

#ifndef __G_PREPROCESS_H
#define __G_PREPROCESS_H

#include <stdint.h>

void GPreprocess_Init(void);
void GPreprocess_Convert(const uint16_t *adc_raw, float *output, uint32_t length);
float GPreprocess_RemoveDC(float *data, uint32_t length);
void GPreprocess_ApplyHann(float *data, uint32_t length);

#endif
