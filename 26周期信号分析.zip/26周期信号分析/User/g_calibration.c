/**
 ****************************************************************************************************
 * @file        g_calibration.c
 * @brief       PA5直连和x10前端的复数频率响应校准
 ****************************************************************************************************
 */

#include "g_calibration.h"

typedef struct
{
    float frequency_hz;
    float direct_real;
    float direct_imag;
    float frontend_real;
    float frontend_imag;
} gcal_point_t;

/* 前端完成后用扫频实测值替换x10列，直连列通常保持1+j0。 */
static const gcal_point_t s_response[] =
{
    {  10000.0f, 1.0f, 0.0f, 10.0f, 0.0f},
    {  50000.0f, 1.0f, 0.0f, 10.0f, 0.0f},
    { 100000.0f, 1.0f, 0.0f, 10.0f, 0.0f},
    { 200000.0f, 1.0f, 0.0f, 10.0f, 0.0f},
    { 300000.0f, 1.0f, 0.0f, 10.0f, 0.0f},
    { 400000.0f, 1.0f, 0.0f, 10.0f, 0.0f},
    { 500000.0f, 1.0f, 0.0f, 10.0f, 0.0f}
};

#define GCAL_POINT_COUNT (sizeof(s_response) / sizeof(s_response[0]))

static void GCalibration_Interpolate(uint8_t input_mode, float frequency_hz,
                                     float *real, float *imag)
{
    uint32_t lower = 0U;
    uint32_t upper = 0U;

    if (frequency_hz <= s_response[0].frequency_hz)
    {
        lower = 0U;
        upper = 0U;
    }
    else if (frequency_hz >= s_response[GCAL_POINT_COUNT - 1U].frequency_hz)
    {
        lower = GCAL_POINT_COUNT - 1U;
        upper = lower;
    }
    else
    {
        for (upper = 1U; upper < GCAL_POINT_COUNT; upper++)
        {
            if (frequency_hz <= s_response[upper].frequency_hz)
            {
                lower = upper - 1U;
                break;
            }
        }
    }

    {
        float lower_real = (input_mode == GCAL_MODE_FRONTEND_X10) ?
                           s_response[lower].frontend_real :
                           s_response[lower].direct_real;
        float lower_imag = (input_mode == GCAL_MODE_FRONTEND_X10) ?
                           s_response[lower].frontend_imag :
                           s_response[lower].direct_imag;

        if (lower == upper)
        {
            *real = lower_real;
            *imag = lower_imag;
        }
        else
        {
            float upper_real = (input_mode == GCAL_MODE_FRONTEND_X10) ?
                               s_response[upper].frontend_real :
                               s_response[upper].direct_real;
            float upper_imag = (input_mode == GCAL_MODE_FRONTEND_X10) ?
                               s_response[upper].frontend_imag :
                               s_response[upper].direct_imag;
            float ratio = (frequency_hz - s_response[lower].frequency_hz) /
                          (s_response[upper].frequency_hz -
                           s_response[lower].frequency_hz);

            *real = lower_real + ratio * (upper_real - lower_real);
            *imag = lower_imag + ratio * (upper_imag - lower_imag);
        }
    }
}

uint8_t GCalibration_Apply(uint8_t input_mode, float frequency_hz,
                           float *cosine_mv, float *sine_mv)
{
    float transfer_real;
    float transfer_imag;
    float denominator;
    float measured_real;
    float measured_imag;
    float corrected_real;
    float corrected_imag;

    if ((cosine_mv == 0) || (sine_mv == 0))
    {
        return 0U;
    }
    GCalibration_Interpolate(input_mode, frequency_hz,
                             &transfer_real, &transfer_imag);
    denominator = transfer_real * transfer_real +
                  transfer_imag * transfer_imag;
    if (denominator < 1.0e-12f)
    {
        return 0U;
    }

    measured_real = *cosine_mv;
    measured_imag = -*sine_mv;
    corrected_real = (measured_real * transfer_real +
                      measured_imag * transfer_imag) / denominator;
    corrected_imag = (measured_imag * transfer_real -
                      measured_real * transfer_imag) / denominator;
    *cosine_mv = corrected_real;
    *sine_mv = -corrected_imag;
    return 1U;
}

float GCalibration_GetNominalGain(uint8_t input_mode)
{
    return (input_mode == GCAL_MODE_FRONTEND_X10) ? 10.0f : 1.0f;
}
