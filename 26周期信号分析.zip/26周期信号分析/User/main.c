/**
 ****************************************************************************************************
 * @file        main.c
 * @brief       STM32H743阿波罗开发板G题周期信号测量装置
 ****************************************************************************************************
 */

#include "./SYSTEM/sys/sys.h"
#include "./SYSTEM/usart/usart.h"
#include "./SYSTEM/delay/delay.h"
#include "./BSP/LED/led.h"
#include "./BSP/KEY/key.h"
#include "./BSP/LCD/lcd.h"
#include "./BSP/MPU/mpu.h"
#include "g_measure.h"
#include "g_view.h"
#include <stdio.h>

static uint8_t App_MeasurementActive(gmeasure_state_t state)
{
    return ((state == GMEASURE_STATE_DISCOVERING) ||
            (state == GMEASURE_STATE_ACCUMULATING)) ? 1U : 0U;
}

static void App_FatalError(gmeasure_status_t status, uint32_t error_code) 
{
    GView_ShowFailure(status, error_code);
    printf("致命错误：0x%08lX\r\n", (unsigned long)error_code);
    while (1)
    {
        LED0_TOGGLE();
        delay_ms(250U);
    }
}

static uint8_t App_StartMeasurement(gmeasure_run_mode_t run_mode)
{
    GMeasure_Abort();
    if (GMeasure_BeginMode(run_mode) == 0U)
    {
        GView_ShowFailure(GMeasure_GetStatus(), GMeasure_GetError());
        printf("测量启动失败：0x%08lX\r\n",
               (unsigned long)GMeasure_GetError());
        return 0U;
    }
    GView_ShowMeasuring();
    printf("开始测量：PA5，输入x%.0f\r\n",
           (double)GMeasure_GetInputGain());
    return 1U;
}

int main(void)
{
    uint32_t led_tick;
    gmeasure_state_t displayed_state = GMEASURE_STATE_IDLE;
    uint8_t displayed_progress = 0U;

    sys_cache_enable();
    HAL_Init();
    sys_stm32_clock_init(160U, 5U, 2U, 4U);
    delay_init(400U);
    usart_init(115200U);
    mpu_memory_protection();
    led_init();
    key_init();
    lcd_init();
    lcd_display_dir(0U);

    GView_Init();
    if (GMeasure_Init() == 0U)
    {
        App_FatalError(GMeasure_GetStatus(), GMeasure_GetError());
    }
    if (App_StartMeasurement(GMEASURE_RUN_NORMAL_X1) == 0U)
    {
        displayed_state = GMEASURE_STATE_FAILED;
        displayed_progress = 100U;
    }
    else
    {
        displayed_state = GMeasure_GetState();
        displayed_progress = GMeasure_GetProgress();
    }
    printf("\r\nH743 G题测量装置已启动：ADC=PA5，P10必须断开\r\n");
    led_tick = HAL_GetTick();

    while (1)
    {
        uint8_t key = key_scan(0U);
        gmeasure_state_t state = GMeasure_GetState();

        if (key == KEY0_PRES)
        {
            if (App_StartMeasurement(GMEASURE_RUN_NORMAL_X1) != 0U)
            {
                displayed_state = GMeasure_GetState();
                displayed_progress = GMeasure_GetProgress();
            }
            else
            {
                displayed_state = GMEASURE_STATE_FAILED;
                displayed_progress = 100U;
            }
        }
        else if ((key == KEY2_PRES) &&
                 (App_MeasurementActive(state) == 0U))
        {
            if (App_StartMeasurement(GMEASURE_RUN_SOFT_AJ_X1) != 0U)
            {
                displayed_state = GMeasure_GetState();
                displayed_progress = GMeasure_GetProgress();
            }
            else
            {
                displayed_state = GMEASURE_STATE_FAILED;
                displayed_progress = 100U;
            }
        }
        else if ((key == KEY1_PRES) &&
                 (state == GMEASURE_STATE_READY))
        {
            GView_ToggleMode();
        }
        else if ((key == WKUP_PRES) &&
                 (state == GMEASURE_STATE_READY))
        {
            GView_TogglePeriods();
        }

        state = GMeasure_GetState();
        if (App_MeasurementActive(state) != 0U)
        {
            uint8_t progress;

            state = GMeasure_Poll();
            progress = GMeasure_GetProgress();
            if ((App_MeasurementActive(state) != 0U) &&
                ((state != displayed_state) ||
                 (progress != displayed_progress)))
            {
                GView_ShowMeasuring();
                displayed_state = state;
                displayed_progress = progress;
            }
        }

        if ((state == GMEASURE_STATE_READY) &&
            (displayed_state != GMEASURE_STATE_READY))
        {
            GView_ShowResult();
            GMeasure_Print();
            displayed_state = GMEASURE_STATE_READY;
            displayed_progress = 100U;
        }
        else if ((state == GMEASURE_STATE_FAILED) &&
                 (displayed_state != GMEASURE_STATE_FAILED))
        {
            GView_ShowFailure(GMeasure_GetStatus(), GMeasure_GetError());
            GMeasure_Print();
            displayed_state = GMEASURE_STATE_FAILED;
            displayed_progress = 100U;
        }

        if ((HAL_GetTick() - led_tick) >= 500U)
        {
            led_tick = HAL_GetTick();
            LED0_TOGGLE();
        }
        delay_ms(1U);
    }
}
