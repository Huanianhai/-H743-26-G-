/**
 ****************************************************************************************************
 * @file        g_fft.c
 * @brief       4096 点 CMSIS RFFT 与 8192 点偶奇拆分实数 FFT
 ****************************************************************************************************
 */

#include "g_fft.h"
#include "./CMSIS/DSP/Include/arm_math.h"
#include <math.h>

#define GFFT_LEN_LOW       4096U
#define GFFT_LEN_HIGH      8192U

static arm_rfft_fast_instance_f32 s_rfft;
static uint32_t s_fft_length = GFFT_LEN_LOW;
static float s_even_input[GFFT_LEN_LOW];
static float s_odd_input[GFFT_LEN_LOW];
static float s_twiddle_cosine[GFFT_LEN_LOW];
static float s_twiddle_sine[GFFT_LEN_LOW];

uint8_t GFFT_Init(void)
{
    uint32_t index;

    s_fft_length = GFFT_LEN_LOW;
    for (index = 0U; index < GFFT_LEN_LOW; index++)
    {
        float angle = 2.0f * PI * (float)index / (float)GFFT_LEN_HIGH;
        s_twiddle_cosine[index] = arm_cos_f32(angle);
        s_twiddle_sine[index] = arm_sin_f32(angle);
    }
    return (arm_rfft_fast_init_f32(&s_rfft, GFFT_LEN_LOW) == ARM_MATH_SUCCESS) ? 1U : 0U;
}

uint8_t GFFT_SetLength(uint32_t length)
{
    if ((length != GFFT_LEN_LOW) && (length != GFFT_LEN_HIGH))
    {
        return 0U;
    }
    s_fft_length = length;
    return (arm_rfft_fast_init_f32(&s_rfft, GFFT_LEN_LOW) == ARM_MATH_SUCCESS) ? 1U : 0U;
}

uint32_t GFFT_GetLength(void)
{
    return s_fft_length;
}

void GFFT_Process(float *input, float *output, float *spectrum)
{
    uint32_t index;
    float real;
    float imag;

    if (s_fft_length == GFFT_LEN_LOW)
    {
        arm_rfft_fast_f32(&s_rfft, input, output, 0U);
        spectrum[0] = fabsf(output[0]);
        for (index = 1U; index < (GFFT_LEN_LOW / 2U); index++)
        {
            real = output[2U * index];
            imag = output[2U * index + 1U];
            spectrum[index] = sqrtf(real * real + imag * imag);
        }
        return;
    }

    {
        float *even_output = output;
        float *odd_output = s_even_input;
        float even_nyquist;
        float odd_nyquist;
        uint32_t mirror;

        for (index = 0U; index < GFFT_LEN_LOW; index++)
        {
            s_even_input[index] = input[2U * index];
            s_odd_input[index] = input[2U * index + 1U];
        }

        arm_rfft_fast_f32(&s_rfft, s_even_input, even_output, 0U);
        arm_rfft_fast_f32(&s_rfft, s_odd_input, odd_output, 0U);
        even_nyquist = even_output[1];
        odd_nyquist = odd_output[1];

        output[0] = even_output[0] + odd_output[0];
        output[1] = even_output[0] - odd_output[0];
        spectrum[0] = fabsf(output[0]);

        for (index = 1U; index < GFFT_LEN_LOW; index++)
        {
            float even_real;
            float even_imag;
            float odd_real;
            float odd_imag;
            float twiddle_real;
            float twiddle_imag;
            float cosine;
            float sine;

            if (index < (GFFT_LEN_LOW / 2U))
            {
                even_real = even_output[2U * index];
                even_imag = even_output[2U * index + 1U];
                odd_real = odd_output[2U * index];
                odd_imag = odd_output[2U * index + 1U];
            }
            else if (index == (GFFT_LEN_LOW / 2U))
            {
                even_real = even_nyquist;
                even_imag = 0.0f;
                odd_real = odd_nyquist;
                odd_imag = 0.0f;
            }
            else
            {
                mirror = GFFT_LEN_LOW - index;
                even_real = even_output[2U * mirror];
                even_imag = -even_output[2U * mirror + 1U];
                odd_real = odd_output[2U * mirror];
                odd_imag = -odd_output[2U * mirror + 1U];
            }

            cosine = s_twiddle_cosine[index];
            sine = s_twiddle_sine[index];
            twiddle_real = odd_real * cosine + odd_imag * sine;
            twiddle_imag = odd_imag * cosine - odd_real * sine;
            real = even_real + twiddle_real;
            imag = even_imag + twiddle_imag;
            spectrum[index] = sqrtf(real * real + imag * imag);
        }
    }
}
