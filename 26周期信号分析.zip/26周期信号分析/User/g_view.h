/**
 ****************************************************************************************************
 * @file        g_view.h
 * @brief       G题测量240x320冻结显示界面
 ****************************************************************************************************
 */

#ifndef __G_VIEW_H
#define __G_VIEW_H

#include "g_measure.h"

void GView_Init(void);
void GView_ShowIdle(void);
void GView_ShowMeasuring(void);
void GView_ShowResult(void);
void GView_ShowFailure(gmeasure_status_t status, uint32_t error_code);
void GView_ToggleMode(void);
void GView_TogglePeriods(void);

#endif
