/**
 ****************************************************************************************************
 * @file        g_fft.h
 * @brief       4096/8192 点实数 FFT 封装
 ****************************************************************************************************
 */

#ifndef __G_FFT_H
#define __G_FFT_H

#include <stdint.h>

uint8_t GFFT_Init(void);
uint8_t GFFT_SetLength(uint32_t length);
void GFFT_Process(float *input, float *output, float *spectrum);
uint32_t GFFT_GetLength(void);

#endif
