/**
 ****************************************************************************************************
 * @file        g_measure_adc.c
 * @brief       G题测量专用 ADC1 + TIM6 TRGO + DMA 单帧采样驱动
 ****************************************************************************************************
 */

#include "./BSP/ADC/g_measure_adc.h"

ADC_HandleTypeDef g_gadc_handle;
DMA_HandleTypeDef g_gadc_dma_handle;
TIM_HandleTypeDef g_gadc_tim_handle;

static volatile uint8_t s_frame_complete;
static volatile uint32_t s_error_code;
static uint32_t s_frame_length = GADC_FRAME_LEN_LOW;
static uint32_t s_sample_rate = GADC_SAMPLE_RATE_LOW_HZ;
static gadc_gear_t s_gear = GADC_GEAR_LOW;

static HAL_StatusTypeDef GADC_ConfigChannel(uint32_t sampling_time)
{
    ADC_ChannelConfTypeDef channel = {0};

    channel.Channel = ADC_CHANNEL_19;
    channel.Rank = ADC_REGULAR_RANK_1;
    channel.SamplingTime = sampling_time;
    channel.SingleDiff = ADC_SINGLE_ENDED;
    channel.OffsetNumber = ADC_OFFSET_NONE;
    channel.Offset = 0;
    channel.OffsetRightShift = DISABLE;
    channel.OffsetSignedSaturation = DISABLE;
    return HAL_ADC_ConfigChannel(&g_gadc_handle, &channel);
}

static HAL_StatusTypeDef GADC_TimerInit(void)
{
    TIM_MasterConfigTypeDef master = {0};

    __HAL_RCC_TIM6_CLK_ENABLE();

    g_gadc_tim_handle.Instance = TIM6;
    g_gadc_tim_handle.Init.Prescaler = 0U;
    g_gadc_tim_handle.Init.CounterMode = TIM_COUNTERMODE_UP;
    g_gadc_tim_handle.Init.Period = GADC_TIM6_DIV_LOW - 1U;
    g_gadc_tim_handle.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
    g_gadc_tim_handle.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
    if (HAL_TIM_Base_Init(&g_gadc_tim_handle) != HAL_OK)
    {
        return HAL_ERROR;
    }

    master.MasterOutputTrigger = TIM_TRGO_UPDATE;
    master.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
    return HAL_TIMEx_MasterConfigSynchronization(&g_gadc_tim_handle, &master);
}

static HAL_StatusTypeDef GADC_DmaInit(void)
{
    __HAL_RCC_DMA2_CLK_ENABLE();

    g_gadc_dma_handle.Instance = DMA2_Stream4;
    g_gadc_dma_handle.Init.Request = DMA_REQUEST_ADC1;
    g_gadc_dma_handle.Init.Direction = DMA_PERIPH_TO_MEMORY;
    g_gadc_dma_handle.Init.PeriphInc = DMA_PINC_DISABLE;
    g_gadc_dma_handle.Init.MemInc = DMA_MINC_ENABLE;
    g_gadc_dma_handle.Init.PeriphDataAlignment = DMA_PDATAALIGN_HALFWORD;
    g_gadc_dma_handle.Init.MemDataAlignment = DMA_MDATAALIGN_HALFWORD;
    g_gadc_dma_handle.Init.Mode = DMA_NORMAL;
    g_gadc_dma_handle.Init.Priority = DMA_PRIORITY_VERY_HIGH;
    g_gadc_dma_handle.Init.FIFOMode = DMA_FIFOMODE_DISABLE;
    g_gadc_dma_handle.Init.FIFOThreshold = DMA_FIFO_THRESHOLD_FULL;
    g_gadc_dma_handle.Init.MemBurst = DMA_MBURST_SINGLE;
    g_gadc_dma_handle.Init.PeriphBurst = DMA_PBURST_SINGLE;

    if (HAL_DMA_Init(&g_gadc_dma_handle) != HAL_OK)
    {
        return HAL_ERROR;
    }

    __HAL_LINKDMA(&g_gadc_handle, DMA_Handle, g_gadc_dma_handle);
    HAL_NVIC_SetPriority(DMA2_Stream4_IRQn, 1U, 0U);
    HAL_NVIC_EnableIRQ(DMA2_Stream4_IRQn);
    return HAL_OK;
}

static HAL_StatusTypeDef GADC_AdcInit(void)
{
    GPIO_InitTypeDef gpio = {0};

    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_ADC12_CLK_ENABLE();

    /* PA5 为阿波罗板 STM_ADC 输入，使用时必须拔下 P10 跳帽。 */
    gpio.Pin = GPIO_PIN_5;
    gpio.Mode = GPIO_MODE_ANALOG;
    gpio.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOA, &gpio);

    g_gadc_handle.Instance = ADC1;
    /* HCLK=200MHz。Rev.V 内部固定二分频后有效 ADC 时钟为 50MHz。 */
    g_gadc_handle.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV2;
    g_gadc_handle.Init.Resolution = ADC_RESOLUTION_12B;
    g_gadc_handle.Init.ScanConvMode = ADC_SCAN_DISABLE;
    g_gadc_handle.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
    g_gadc_handle.Init.LowPowerAutoWait = DISABLE;
    g_gadc_handle.Init.ContinuousConvMode = DISABLE;
    g_gadc_handle.Init.NbrOfConversion = 1U;
    g_gadc_handle.Init.DiscontinuousConvMode = DISABLE;
    g_gadc_handle.Init.NbrOfDiscConversion = 1U;
    g_gadc_handle.Init.ExternalTrigConv = ADC_EXTERNALTRIG_T6_TRGO;
    g_gadc_handle.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_RISING;
    g_gadc_handle.Init.ConversionDataManagement = ADC_CONVERSIONDATA_DMA_ONESHOT;
    g_gadc_handle.Init.Overrun = ADC_OVR_DATA_OVERWRITTEN;
    g_gadc_handle.Init.LeftBitShift = ADC_LEFTBITSHIFT_NONE;
    g_gadc_handle.Init.OversamplingMode = DISABLE;

    if (HAL_ADC_Init(&g_gadc_handle) != HAL_OK)
    {
        return HAL_ERROR;
    }

    /* 2MSPS下每次触发有25个ADC周期预算，8.5周期采样兼顾稳定性。 */
    if (GADC_ConfigChannel(ADC_SAMPLETIME_8CYCLES_5) != HAL_OK)
    {
        return HAL_ERROR;
    }

    return HAL_ADCEx_Calibration_Start(&g_gadc_handle,
                                       ADC_CALIB_OFFSET,
                                       ADC_SINGLE_ENDED);
}

HAL_StatusTypeDef GADC_Init(void)
{
    s_frame_complete = 0U;
    s_error_code = HAL_ADC_ERROR_NONE;

    /* Rev.Y 没有内部固定二分频，不能使用本工程的 50MHz 配置。 */
    if (HAL_GetREVID() <= REV_ID_Y)
    {
        s_error_code = GADC_ERROR_UNSUPPORTED_REV;
        return HAL_ERROR;
    }

    if (GADC_TimerInit() != HAL_OK)
    {
        return HAL_ERROR;
    }
    if (GADC_DmaInit() != HAL_OK)
    {
        return HAL_ERROR;
    }
    if (GADC_AdcInit() != HAL_OK)
    {
        return HAL_ERROR;
    }
    return GADC_Configure(GADC_GEAR_LOW);
}

HAL_StatusTypeDef GADC_Configure(gadc_gear_t gear)
{
    uint32_t divider;
    uint32_t sampling_time;

    if ((g_gadc_tim_handle.State == HAL_TIM_STATE_BUSY) ||
        ((g_gadc_handle.State & HAL_ADC_STATE_REG_BUSY) != 0U))
    {
        return HAL_BUSY;
    }

    if (gear == GADC_GEAR_HIGH)
    {
        divider = GADC_TIM6_DIV_HIGH;
        sampling_time = ADC_SAMPLETIME_2CYCLES_5;
        s_frame_length = GADC_FRAME_LEN_HIGH;
        s_sample_rate = GADC_SAMPLE_RATE_HIGH_HZ;
        s_gear = GADC_GEAR_HIGH;
    }
    else
    {
        divider = GADC_TIM6_DIV_LOW;
        sampling_time = ADC_SAMPLETIME_8CYCLES_5;
        s_frame_length = GADC_FRAME_LEN_LOW;
        s_sample_rate = GADC_SAMPLE_RATE_LOW_HZ;
        s_gear = GADC_GEAR_LOW;
    }

    __HAL_TIM_SET_AUTORELOAD(&g_gadc_tim_handle, divider - 1U);
    __HAL_TIM_SET_COUNTER(&g_gadc_tim_handle, 0U);
    g_gadc_tim_handle.Instance->EGR = TIM_EGR_UG;
    return GADC_ConfigChannel(sampling_time);
}

HAL_StatusTypeDef GADC_Start(void)
{
    s_frame_complete = 0U;
    s_error_code = HAL_ADC_ERROR_NONE;
    __HAL_TIM_SET_COUNTER(&g_gadc_tim_handle, 0U);

    if (HAL_ADC_Start_DMA(&g_gadc_handle, (uint32_t *)GADC_DMA_BUFFER,
                          s_frame_length) != HAL_OK)
    {
        return HAL_ERROR;
    }

    if (HAL_TIM_Base_Start(&g_gadc_tim_handle) != HAL_OK)
    {
        (void)HAL_ADC_Stop_DMA(&g_gadc_handle);
        return HAL_ERROR;
    }
    return HAL_OK;
}

void GADC_Stop(void)
{
    (void)HAL_TIM_Base_Stop(&g_gadc_tim_handle);
    (void)HAL_ADC_Stop_DMA(&g_gadc_handle);
}

uint8_t GADC_IsComplete(void)
{
    return s_frame_complete;
}

void GADC_ClearComplete(void)
{
    s_frame_complete = 0U;
}

uint32_t GADC_GetError(void)
{
    return s_error_code;
}

void GADC_SetTimeoutError(void)
{
    s_error_code |= GADC_ERROR_TIMEOUT;
}

uint16_t *GADC_GetBuffer(void)
{
    return GADC_DMA_BUFFER;
}

uint32_t GADC_GetFrameLength(void)
{
    return s_frame_length;
}

uint32_t GADC_GetSampleRate(void)
{
    return s_sample_rate;
}

gadc_gear_t GADC_GetGear(void)
{
    return s_gear;
}

void DMA2_Stream4_IRQHandler(void)
{
    HAL_DMA_IRQHandler(&g_gadc_dma_handle);
}

void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc)
{
    if (hadc->Instance == ADC1)
    {
        (void)HAL_TIM_Base_Stop(&g_gadc_tim_handle);
        __DMB();
        s_frame_complete = 1U;
    }
}

void HAL_ADC_ErrorCallback(ADC_HandleTypeDef *hadc)
{
    if (hadc->Instance == ADC1)
    {
        (void)HAL_TIM_Base_Stop(&g_gadc_tim_handle);
        s_error_code = HAL_ADC_GetError(hadc);
    }
}
