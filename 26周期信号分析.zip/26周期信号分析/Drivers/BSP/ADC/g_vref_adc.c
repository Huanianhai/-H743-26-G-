/**
 ****************************************************************************************************
 * @file        g_vref_adc.c
 * @brief       使用ADC3内部VREFINT测量模拟参考电压
 ****************************************************************************************************
 */

#include "./BSP/ADC/g_vref_adc.h"

#define GVREF_SAMPLE_COUNT        32U
#define GVREF_DISCARD_COUNT       4U
#define GVREF_POLL_TIMEOUT_MS     5U
#define GVREF_MIN_VALID_MV        2700.0f
#define GVREF_MAX_VALID_MV        3600.0f

static ADC_HandleTypeDef s_vref_adc_handle;
static uint32_t s_vref_error;

HAL_StatusTypeDef GVREF_Init(void)
{
    ADC_ChannelConfTypeDef channel = {0};

    s_vref_error = 0U;
    __HAL_RCC_ADC3_CLK_ENABLE();

    s_vref_adc_handle.Instance = ADC3;
    s_vref_adc_handle.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV2;
    s_vref_adc_handle.Init.Resolution = ADC_RESOLUTION_16B;
    s_vref_adc_handle.Init.ScanConvMode = ADC_SCAN_DISABLE;
    s_vref_adc_handle.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
    s_vref_adc_handle.Init.LowPowerAutoWait = DISABLE;
    s_vref_adc_handle.Init.ContinuousConvMode = DISABLE;
    s_vref_adc_handle.Init.NbrOfConversion = 1U;
    s_vref_adc_handle.Init.DiscontinuousConvMode = DISABLE;
    s_vref_adc_handle.Init.NbrOfDiscConversion = 1U;
    s_vref_adc_handle.Init.ExternalTrigConv = ADC_SOFTWARE_START;
    s_vref_adc_handle.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
    s_vref_adc_handle.Init.ConversionDataManagement = ADC_CONVERSIONDATA_DR;
    s_vref_adc_handle.Init.Overrun = ADC_OVR_DATA_OVERWRITTEN;
    s_vref_adc_handle.Init.LeftBitShift = ADC_LEFTBITSHIFT_NONE;
    s_vref_adc_handle.Init.OversamplingMode = DISABLE;

    if (HAL_ADC_Init(&s_vref_adc_handle) != HAL_OK)
    {
        s_vref_error = GVREF_ERROR_INIT;
        return HAL_ERROR;
    }
    if (HAL_ADCEx_Calibration_Start(&s_vref_adc_handle,
                                    ADC_CALIB_OFFSET_LINEARITY,
                                    ADC_SINGLE_ENDED) != HAL_OK)
    {
        s_vref_error = GVREF_ERROR_CALIBRATION;
        return HAL_ERROR;
    }

    channel.Channel = ADC_CHANNEL_VREFINT;
    channel.Rank = ADC_REGULAR_RANK_1;
    channel.SamplingTime = ADC_SAMPLETIME_810CYCLES_5;
    channel.SingleDiff = ADC_SINGLE_ENDED;
    channel.OffsetNumber = ADC_OFFSET_NONE;
    channel.Offset = 0U;
    channel.OffsetRightShift = DISABLE;
    channel.OffsetSignedSaturation = DISABLE;
    if (HAL_ADC_ConfigChannel(&s_vref_adc_handle, &channel) != HAL_OK)
    {
        s_vref_error = GVREF_ERROR_INIT;
        return HAL_ERROR;
    }

    HAL_Delay(1U);
    return HAL_OK;
}

HAL_StatusTypeDef GVREF_ReadVddaMv(float *vdda_mv)
{
    uint64_t sum = 0U;
    uint32_t sample;
    uint32_t average;
    uint32_t calculated_mv;

    if (vdda_mv == NULL)
    {
        s_vref_error = GVREF_ERROR_CONVERSION;
        return HAL_ERROR;
    }

    for (sample = 0U; sample < (GVREF_SAMPLE_COUNT + GVREF_DISCARD_COUNT); sample++)
    {
        if ((HAL_ADC_Start(&s_vref_adc_handle) != HAL_OK) ||
            (HAL_ADC_PollForConversion(&s_vref_adc_handle,
                                       GVREF_POLL_TIMEOUT_MS) != HAL_OK))
        {
            (void)HAL_ADC_Stop(&s_vref_adc_handle);
            s_vref_error = GVREF_ERROR_CONVERSION;
            return HAL_ERROR;
        }
        if (sample >= GVREF_DISCARD_COUNT)
        {
            sum += HAL_ADC_GetValue(&s_vref_adc_handle);
        }
        (void)HAL_ADC_Stop(&s_vref_adc_handle);
    }

    average = (uint32_t)((sum + GVREF_SAMPLE_COUNT / 2U) /
                         GVREF_SAMPLE_COUNT);
    if (average == 0U)
    {
        s_vref_error = GVREF_ERROR_CONVERSION;
        return HAL_ERROR;
    }
    calculated_mv = __HAL_ADC_CALC_VREFANALOG_VOLTAGE(average,
                                                       ADC_RESOLUTION_16B);
    *vdda_mv = (float)calculated_mv;
    if ((*vdda_mv < GVREF_MIN_VALID_MV) ||
        (*vdda_mv > GVREF_MAX_VALID_MV))
    {
        s_vref_error = GVREF_ERROR_RANGE;
        return HAL_ERROR;
    }

    s_vref_error = 0U;
    return HAL_OK;
}

uint32_t GVREF_GetError(void)
{
    return s_vref_error;
}
