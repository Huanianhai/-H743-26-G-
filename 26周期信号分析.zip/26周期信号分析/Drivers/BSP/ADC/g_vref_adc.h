/**
 ****************************************************************************************************
 * @file        g_vref_adc.h
 * @brief       使用ADC3内部VREFINT测量模拟参考电压
 ****************************************************************************************************
 */

#ifndef __G_VREF_ADC_H
#define __G_VREF_ADC_H

#include "./SYSTEM/sys/sys.h"

#define GVREF_ERROR_INIT          0x00000001UL
#define GVREF_ERROR_CALIBRATION   0x00000002UL
#define GVREF_ERROR_CONVERSION    0x00000004UL
#define GVREF_ERROR_RANGE         0x00000008UL

HAL_StatusTypeDef GVREF_Init(void);
HAL_StatusTypeDef GVREF_ReadVddaMv(float *vdda_mv);
uint32_t GVREF_GetError(void);

#endif
