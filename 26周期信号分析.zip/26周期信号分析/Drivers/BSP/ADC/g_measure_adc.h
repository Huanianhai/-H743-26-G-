/**
 ****************************************************************************************************
 * @file        g_measure_adc.h
 * @brief       G题测量专用 ADC1 + TIM6 TRGO + DMA 单帧采样驱动
 ****************************************************************************************************
 */

#ifndef __G_MEASURE_ADC_H
#define __G_MEASURE_ADC_H

#include "./SYSTEM/sys/sys.h"

#define GADC_FRAME_LEN_LOW             4096U
#define GADC_FRAME_LEN_HIGH            8192U
#define GADC_DMA_BUFFER_ADDRESS        0x30000000UL
#define GADC_DMA_BUFFER                ((uint16_t *)GADC_DMA_BUFFER_ADDRESS)

#define GADC_TIM6_CLOCK_HZ             200000000UL
#define GADC_SAMPLE_RATE_LOW_HZ        2000000UL
#define GADC_SAMPLE_RATE_HIGH_HZ       3125000UL
#define GADC_TIM6_DIV_LOW              (GADC_TIM6_CLOCK_HZ / GADC_SAMPLE_RATE_LOW_HZ)
#define GADC_TIM6_DIV_HIGH             (GADC_TIM6_CLOCK_HZ / GADC_SAMPLE_RATE_HIGH_HZ)

#define GADC_ERROR_UNSUPPORTED_REV     0x80000000UL
#define GADC_ERROR_TIMEOUT             0x40000000UL

typedef enum
{
    GADC_GEAR_LOW = 0,
    GADC_GEAR_HIGH = 1
} gadc_gear_t;

extern ADC_HandleTypeDef g_gadc_handle;
extern DMA_HandleTypeDef g_gadc_dma_handle;
extern TIM_HandleTypeDef g_gadc_tim_handle;

HAL_StatusTypeDef GADC_Init(void);
HAL_StatusTypeDef GADC_Configure(gadc_gear_t gear);
HAL_StatusTypeDef GADC_Start(void);
void GADC_Stop(void);
uint8_t GADC_IsComplete(void);
void GADC_ClearComplete(void);
uint32_t GADC_GetError(void);
void GADC_SetTimeoutError(void);
uint16_t *GADC_GetBuffer(void);
uint32_t GADC_GetFrameLength(void);
uint32_t GADC_GetSampleRate(void);
gadc_gear_t GADC_GetGear(void);

#endif
