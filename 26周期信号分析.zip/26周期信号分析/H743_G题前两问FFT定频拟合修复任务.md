# Context
Filename: H743_G题前两问FFT定频拟合修复任务.md
Created On: 2026-07-30
Created By: Codex
Associated Protocol: RIPER-5 + Multidimensional + Agent Protocol for STM32

# Task Description
在PA5直连、High-Z、信号源提供1.65V偏置、P10断开的接线条件下，修复联合模型搜索导致的约2.2秒超时，并提高Vpp、Urms、基频和各频谱分量幅值的稳定性。当前只处理用户确认的前两种输入条件，第三问干扰视为已由硬件滤除。

# STM32 Environment
- MCU: STM32H743IIT6 Rev.V
- Firmware Library: STM32H7 HAL + CMSIS-DSP
- IDE/Toolchain: Keil MDK ARMCLANG 6.21，-O2
- RTOS: None

# Hardware Configuration
- Clock: SYSCLK 400MHz，TIM6 200MHz，ADC有效时钟50MHz
- Peripherals Used: ADC1_INP19/PA5，ADC3/VREFINT，TIM6 TRGO，DMA2 Stream4，FMC LCD
- Memory Constraints: ADC DMA缓冲固定在D2 SRAM 0x30000000；分析数组位于512KiB AXI SRAM
- Critical Timing Requirements: 每项完成时间不超过2秒，软件全局截止时间1500ms

# Analysis
实板失败页已证明ADC能够取得约1.65V中心的有效波形，故障发生在DISCOVERY/FIT阶段。旧路径对多个候选和候选组合重复执行黄金分割联合拟合，H743实测CPU分析约2.2秒。改为一次平顶窗FFT和固定频率拟合后能够消除主要超时，但平顶窗线性抛物线频率估计在100kHz附近仍有约62Hz误差，使H3幅值误差最差接近5mV。

# Proposed Solution
发现帧仅执行一次4096点Hann窗FFT，使用对数三点抛物线插值得到高精度频率；以谱峰整数倍关系选择H1和最多两个谐波，再对未加窗原始电压执行一次固定频率联合拟合。后续两帧只执行固定频率拟合，三帧一致后平均并冻结。该方案保留频率与分量识别能力，同时把运行量限制为一次FFT加三次拟合。

# Implementation Plan
Implementation Checklist:
1. 创建带故障和功能说明的完整备份。
2. 将发现频谱改为4096点Hann窗和对数三点插值。
3. 删除测量模块内不再调用的候选组合拟合代码。
4. 保持12位ADC、2MSPS、4096点、x1直连和三帧冻结逻辑。
5. 同步测试模型并验证频率、分量幅值、总Vpp和Urms。
6. 执行Keil全量构建并核对RAM、DMA缓冲、HEX和运行路径。
7. 更新文档并进行最终审查。

# Current Execution Step
> Completed

# Task Progress
* 2026-07-30
  * Step: 1，完整备份
  * Modifications: 备份到`C:\Users\花\Desktop\Codexproject\备份\新建文件夹_12位ADC采样正常_问题联合拟合FIND阶段约2点2秒超时_改为FFT测频加定频拟合前_20260730_005927`
  * Change Summary: 保留12位ADC可采样但分析超时的完整基线
  * Reason: 支持恢复和版本辨识
  * Blockers: None
  * Status: Completed
* 2026-07-30
  * Step: 2-4，轻量频率发现和固定频率拟合
  * Modifications: `g_measure.c`改为一次FFT选择谐波模型和固定频率拟合；`g_preprocess.c/.h`改用4096点Hann窗；`g_signal.c`改用对数三点插值；删除旧候选组合拟合函数
  * Change Summary: 运行路径不再调用`GHFit_Search`，全局截止时间为1500ms
  * Reason: 消除约2.2秒CPU超时并提高频率种子精度
  * Blockers: None
  * Status: Completed
* 2026-07-30
  * Step: 5，主机数值回归
  * Modifications: 测试同步12位量化、Hann FFT、对数插值、固定频率拟合，并加入Vpp/Urms和62组扫频随机相位检查
  * Change Summary: 全部测试通过；62组扫频最差频率误差7.8309Hz、最差分量幅值误差0.0737mV；用户100kHz实测配置模拟分量误差0.0740mV、Vpp误差0.2216mV
  * Reason: 验证题目误差指标及边界行为
  * Blockers: None
  * Status: Completed
* 2026-07-30
  * Step: 6，Keil构建和链接核对
  * Modifications: ARMCLANG 6.21全量编译，检查MAP、HEX哈希、AXI SRAM和D2 DMA地址
  * Change Summary: 0 Error、0 Warning；Code=99078，RO-data=93850，ZI-data=2196748；AXI SRAM使用0x24530字节；HEX SHA-256为`2896CE37AD7906E80A17A6B5B6D90FD42B610AEC609FE311BB0D01F68CA80678`
  * Reason: 验证工程可构建及资源布局
  * Blockers: None
  * Status: Completed

# Final Review
实现与计划一致。ADC1仍为12位、2MSPS、4096点，DMA2 Stream4缓冲地址仍为0x30000000；DMA中断仅停止TIM6并设置完成标志，FFT、拟合和LCD均在主循环执行。发现阶段只执行一次Hann FFT和一次固定频率拟合，确认阶段再执行两次固定频率拟合；链接MAP明确将`GHFit_Search`从最终固件移除。没有动态内存、ISR阻塞、采样期间并发读取或x1/x10口径混用。

主机测试覆盖题目要求的基频、频谱分量幅值、总Vpp和交流Urms，并包含500kHz边界、小谐波、ADC量化、削顶和稳定状态。Keil全量构建0错误0警告。Hann表仅占16KiB，移除旧8192点窗表后ZI相对中间版本减少32KiB。

真实板上的ADC增益误差、VDDA读数和实际分析耗时仍必须通过重新烧录后的屏幕数据确认。成功页应在1500ms内冻结；若失败，LCD的ADC最小/最大/平均码、Stage、Reason和CPU时间可直接用于下一轮定位。

Implementation perfectly matches the final plan.
