# Context
Filename: H743_G_PORT_TASK.md
Created On: 2026-07-29
Created By: Codex
Associated Protocol: RIPER-5 + Multidimensional + Agent Protocol for STM32

# Task Description
将 `C:\Users\花\Desktop\STM32H7` 中基于正点原子 H750 开发板实现的 G题周期信号测量功能移植到正点原子阿波罗 STM32H743 开发板。

# Project Overview
仅移植 G题测量链路。原 H750 工程中的信号分离、双 DAC 回放、F103/AD9959 通信、实时数字滤波、旧 THD 和扫频模块不属于目标功能。`C:\Users\花\Desktop\Codexproject\H743实现THD测量` 仅作为 H743 板级工程和 2.8 寸 LCD 驱动参考，不沿用其中的 THD 算法和 ADC 采样架构。

# STM32 Environment
- MCU: STM32H743IIT6 Rev.V
- Firmware Library: STM32H7 HAL/CMSIS
- IDE/Toolchain: Keil MDK-ARM, Arm Compiler 6.21
- RTOS: None

# Hardware Configuration
- Clock: CPU 400 MHz，HCLK/TIM6 200 MHz
- Peripherals Used: ADC1、TIM6 TRGO、DMA2 Stream4、FMC LCD、GPIO keys、USART1
- Analog Input: 外部 BNC、50 ohm 终端、10 倍增益、1.65 V 偏置、限幅和低通滤波已具备
- ADC Pin: PA5 / ADC1_INP19，使用时拔掉 P10 跳帽
- Display: 2.8 寸、240 x 320 竖屏，FMC NE1+A18、16 位数据、PB5 背光
- Waveform Display: KEY0启动有限帧测量，连续多帧确认后自动停止采样并冻结；波形重建为稳定的完整1个或3个基波周期
- Keys: KEY0=PH3，KEY1=PH2，KEY2=PC13，WKUP=PA0
- Critical Timing Requirements: 启动测量后 2 秒内完成；覆盖 10 kHz 至 500 kHz 分量；频率分辨率 500 Hz

---
*The following sections are maintained by the AI during protocol execution*
---

# Analysis
原 H750 G题主链路为：ADC1 由 TIM6 TRGO 触发，经 DMA 获取采样块，去除直流后进行 Flattop 窗 FFT 和峰值检测，再用 500 Hz 网格及 Goertzel 精化参数，最后计算并显示频率、幅值、相位、Upp、Urms、DC 和原始 Vpp。

原工程默认采样配置为 2.0 MSPS / 4096 点，并具有 3.2 MSPS / 8192 点高速档；最多识别基波及两个谐波。H750 的 PC0 ADC 输入在阿波罗 H743 板上被 SDRAM 占用且未引出，因此目标输入迁移至 PA5。H750 的 240 MHz 定时器参数不适用于 H743 的 200 MHz TIM6 时钟。

STM32H7 的 DMA 与 D-Cache 一致性是关键约束。目标 H743 工程的 MPU 已将 D2 SRAM 配置为不可缓存，适合放置一次性 DMA 缓冲。原 H750 波形页使用测量分量参数重建；目标工程进一步在测量后停止 ADC/TIM6，只响应视图和周期按键静态重画。

题目第 3 项的 1 MHz 以上干扰抑制主要依赖已具备的外部低通滤波。软件峰值候选范围限制在 8 kHz 至 550 kHz，避免把残余高频干扰误判为待测分量。

# Proposed Solution
采用昨晚 H743 工程作为板级底座，保留 400 MHz 时钟、MPU、PA5、按键、LCD 和 USART；使用 H750 工程作为唯一 G题算法来源。DMA 使用 D2 SRAM 不可缓存固定地址，避免缓存维护竞争。低档保持 2.000 MSPS，高档按 H743 TIM6 整数分频调整为 3.125 MSPS，并将高档相干窗改为 6250 点。测量流程为低档单帧分析，发现 400 kHz 以上有效分量时高档重采一次，随后冻结结果。

# Implementation Plan
1. 建立 H743 板级工程底座。
2. 实现 PA5、ADC1、TIM6、DMA2 Stream4 一次性采样驱动。
3. 移植双长度 Flattop 预处理。
4. 移植 4096/8192 点 FFT。
5. 移植 Goertzel 和抛物线插值。
6. 移植 G题测量核心并加入带宽限制、自动换档和一次性状态机。
7. 实现 240x320 静态 1T/3T 波形、频谱和参数显示。
8. 实现按键、串口和错误处理主循环。
9. 建立仅包含 G题模块的 Keil AC6.21 工程。
10. 完成 README 和任务记录。
11. 全量编译并检查内存布局。
12. 对照计划完成最终代码审查。

# Current Execution Step
> Completed: 实时测量稳定性修正、全量构建与最终复核

# Task Progress
*   2026-07-29
    *   Step: 1. 建立 H743 板级工程底座
    *   Modifications: 复制 Drivers、Middlewares、系统配置和中断文件；移除目标副本的旧 THD ADC 文件
    *   Change Summary: 目标目录具备已验证的 H743 板级基础且不含旧 THD 算法
    *   Reason: Executing plan step 1
    *   Blockers: None
    *   Status: Completed

*   2026-07-29
    *   Step: 2-6. 采样与测量算法
    *   Modifications: 新增 g_measure_adc、g_preprocess、g_fft、g_signal、g_measure
    *   Change Summary: 完成单帧 DMA、双采样档、FFT、峰值检测、500 Hz 精化和全部派生参数
    *   Reason: Executing plan steps 2-6
    *   Blockers: None
    *   Status: Completed

*   2026-07-29
    *   Step: 7-8. 静态显示与应用控制
    *   Modifications: 新增 g_view 和 main；实现冻结结果、1T/3T、频谱、按键及串口
    *   Change Summary: 测量与显示解耦，不再实时滚动或连续刷新
    *   Reason: Executing plan steps 7-8
    *   Blockers: None
    *   Status: Completed

*   2026-07-29
    *   Step: 9. Keil 工程
    *   Modifications: 新增 G_MEASURE_H743.uvprojx，仅引用 G题源码
    *   Change Summary: 保留 AC6.21、H743、CMSIS-DSP 和原板级内存配置
    *   Reason: Executing plan step 9
    *   Blockers: None
    *   Status: Completed

*   2026-07-29
    *   Step: 10. 文档
    *   Modifications: 新增 README，更新任务记录
    *   Change Summary: 记录接线、操作、采样、内存、标定、构建和上板验证步骤
    *   Reason: Executing plan step 10
    *   Blockers: None
    *   Status: Completed

*   2026-07-29
    *   Step: 11. 全量编译与内存检查
    *   Modifications: AC6.21 全量重建；检查 scatter/map；修正启动失败状态
    *   Change Summary: 0 errors、0 warnings；AXI SRAM 约 196.2 KiB，外部 SDRAM LCD 帧缓冲约 1.953 MiB，ROM 约 187.3 KiB
    *   Reason: Executing plan step 11
    *   Blockers: None
    *   Status: Completed

*   2026-07-29
    *   Step: 12. 最终计划复核
    *   Modifications: 核对外设、状态机、FFT/Goertzel、1T/3T、内存域、ISR 和工程依赖
    *   Change Summary: 未发现未报告的功能偏差；清理 MPU 注释中的旧 THD 名称
    *   Reason: Executing plan step 12
    *   Blockers: 实板精度和抗干扰能力无法在无硬件连接条件下验证
    *   Status: Completed

*   2026-07-29
    *   Step: 实板反馈后的实时测量与稳定性修正
    *   Modifications: 修改 g_measure、g_measure_adc、g_view、main、README；增加 x1/x10 输入模式、ADC 稳健限幅、连续帧确认和平滑、连续采集及 10 Hz LCD 刷新
    *   Change Summary: 修正直连信号被固定除以十、孤立毛刺影响全部参数、KEY0 每次仅截取单帧的问题
    *   Reason: 用户实测 30 kHz/100 mVpp 时 Upp 约 8 mV 且重复 KEY0 后幅值、DC、谐波和相位变化
    *   Blockers: 实板复测尚待用户下载新固件后完成
    *   Status: Completed

# Final Review

修正范围：根据实板现象，默认输入换算改为 PA5 直连 x1；KEY2 可切换完整模拟前端 x10。KEY0 启动后持续运行，KEY0 再次按下才停止。LCD 约每 100 ms 刷新，USART1 约每 500 ms 输出一次。

采样与并发：DMA2 Stream4 仍使用 D2 SRAM 固定缓冲区。每帧完成后 TIM6 在 ISR 中停止，主循环停止 DMA、分析当前缓冲，并在发布结果前启动下一帧；CPU 分析与下一次 DMA 写入不重叠。ISR 只设置 volatile 状态，不执行 FFT、LCD 或阻塞操作。

稳定性修正：ADC 原始数据先取 0.5%/99.5% 分位边界并限幅，孤立毛刺不再直接进入 DC、FFT、Goertzel 和 raw Vpp。相同分量的幅值、DC、频率及相对相位使用 alpha=0.25 平滑；分量变化连续两帧确认，无信号连续三帧确认。

数值换算：x1 模式按 PA5 实际电压换算，适用于当前 30 kHz、100 mVpp、1.65 V 偏置的直连测试；x10 模式才除以前端十倍增益。DC 显示的是相对 1.65 V 偏置的输入端直流偏差。

验证：50 组随机采样相位、每帧 8 个大幅 ADC 毛刺的主机仿真中，x1 纯正弦始终得到 30000 Hz，基波幅值 49.806~50.003 mVpk，稳健 raw Vpp 100.733~101.538 mV，DC -0.348~0.333 mV；加入三次谐波后分量数稳定为 2，相对相位 33.877~35.867 度。x10 模式换算结果同样回到约 100 mVpp。

构建与内存：Keil Arm Compiler 6.21 全量构建为 0 errors、0 warnings。ROM 为 189.83 KiB，AXI SRAM 执行区大小为 0x33188/0x80000，外部 SDRAM LCD 帧缓冲不变；D2 0x30000000 DMA 固定区未与链接对象重叠。

备份：修改前工程已完整复制到 `C:\Users\花\Desktop\Codexproject\新建文件夹_修改前备份_20260729_1715`。源与备份均为 428 个文件、24,886,188 字节，逐文件 SHA-256 差异为 0。

残余验证：软件构建和算法仿真已通过，但真实 PA5 电压、VDDA、P10 状态、模拟前端增益、ADC 硬件噪声及 LCD 实际观感仍必须在 H743 实板复测。直接测试时必须使用 x1；接入实际十倍前端后切换 x10。

Implementation perfectly matches the revised plan.
