# STM32H743 G题周期信号测量装置

本工程面向正点原子阿波罗STM32H743IIT6开发板，实现PA5周期信号采集、基频和整数谐波识别、Upp/Urms计算、频谱数值显示以及稳定波形重建。工程使用STM32H7 HAL、CMSIS-DSP和Keil ARMCLANG 6.21，无RTOS。

## 工程入口

- Keil工程：`Projects/MDK-ARM/G_MEASURE_H743.uvprojx`
- 主程序：`User/main.c`
- 测量状态机：`User/g_measure.c`
- 联合谐波拟合：`User/g_harmonic_fit.c`
- 复数频响校准：`User/g_calibration.c`
- ADC1 DMA采样：`Drivers/BSP/ADC/g_measure_adc.c`
- ADC3 VDDA测量：`Drivers/BSP/ADC/g_vref_adc.c`
- LCD界面：`User/g_view.c`

## 接线

信号连接PA5/ADC1_INP19，信号地连接开发板GND，P10跳帽必须拔下。当前固件支持两条路径：KEY0为前两问的前端x10测量，KEY2为信号源直接叠加`ub+uJ`时的软件抗干扰直连x1测量。通过50Ω终端、x10增益、1.65V偏置、限幅和低通前端完成后，将`User/g_measure.h`中的`GMEAS_FRONTEND_X10_ENABLED`改为1，并完成扫频校准后才能使用x10。

直接连接高阻PA5时，信号发生器负载设置为HighZ，并由发生器提供1.65V偏置。正式50Ω前端接入后，发生器负载设置为50Ω，发生器偏置设置为0V，由前端产生1.65V偏置。仅把发生器菜单改成50Ω不能代替实际50Ω同轴电缆和接收端50Ω终端。

## 测量流程

上电后固件自动开始一次普通x10测量；测试直接叠加`ub+uJ`时应按KEY2进入软件抗干扰x1路径，KEY0用于重新开始普通x10测量。固件先读取ADC3/VREFINT得到实际VDDA，ADC1使用12位分辨率，以2MSPS采集并丢弃1个4096点启动过渡帧，再采集候选帧。原始ADC数据同时用于削顶诊断和电压换算；单帧异常削顶会自动重采，连续两帧确认才报告CLIPPED。测量不再裁剪正弦波峰值，去直流后的数据仅在频率发现时加Hann窗，未加窗数据用于DC、RMS和联合拟合。

发现帧只执行一次4096点FFT。Hann频谱经对数三点抛物线插值得到基频种子，并在强谐波的整数分频位置补充搜索弱基波候选；软件按整数倍关系选取H1及最多两个谐波，然后在该固定基频上执行一次联合最小二乘拟合。该路径不再执行多候选黄金分割搜索，避免H743实板分析超过2秒。

候选帧建立模型后直接成为第1个有效帧，后续2帧不再重复FFT或频率搜索，只在锁定频率做普通联合拟合。帧特征一致就累计；特征变化或模型失效则丢弃本轮累计并返回候选发现。连续获得3个一致有效帧后，固件停止ADC、TIM6和DMA并冻结结果。测量全局截止时间为1500ms，为题目每项2秒限制保留显示刷新余量。

## 按键

- KEY0：开始或重新开始普通x10测量。
- KEY1：冻结后切换波形和频谱。
- KEY2：开始软件抗干扰直连x1测量；先用3.125MSPS/8192点探测干扰，必要时用2MSPS/4096点判别混叠。
- WKUP：冻结波形页面切换1个或3个完整周期。

## 显示数值

频谱表格显示Hn、频率和mVpp。100mVpp纯正弦的H1应约为100mVpp。Upp(total)是所有分量叠加后总波形的峰峰值，Urms是去除1.65V偏置后的交流真有效值；Bias是PA5绝对平均电压，正常接近1.65V。频谱横轴固定为10到500kHz，同时覆盖题目u_a和u_b。

错误状态包括NO SIGNAL、CLIPPED、BAD HARMONICS、UNSTABLE、TIMEOUT、ADC ERROR、VREF ERROR和FIT ERROR。TIMEOUT代码`0x40000000`表示单帧ADC/DMA采集超过20ms，`0x04000000`表示整套测量超过1500ms；失败页同时显示总耗时、已尝试帧数、CPU分析时间、最后一帧ADC最小/最大/平均码、削顶样本数、处理阶段及最近一次拒绝原因。

## 编译与验证

打开Keil工程后全量构建，输出位于`Output/G_MEASURE_H743.hex`。工程使用ARMCLANG `-O2`。串口为USART1、115200 baud，在冻结或失败时输出VDDA、Hn幅值、Upp、Urms、Bias、残差、帧数和DWT分析耗时。

主机数值参考测试位于`Tests/verify_harmonic_fit.py`，覆盖12位量化与削顶、u_a、u_b、500kHz边界、微小谐波、离群点、三帧稳定逻辑、总Vpp/Urms，以及62组10.2kHz到490kHz扫频与随机相位组合。第三问软件抗干扰回归测试位于`Tests/verify_interference.py`，覆盖1.2MHz直接干扰和2.7MHz双采样率折叠判别。详细接线、数值含义和x10扫频校准步骤见`MEASUREMENT_AND_CALIBRATION.md`。

当前2.8寸LCD可完成开发验证，但不满足题目要求的6寸及以上显示器。正式前端完成并填入实测复数频响表之前，不能宣称全频段幅值绝对误差已经达到5mV。
