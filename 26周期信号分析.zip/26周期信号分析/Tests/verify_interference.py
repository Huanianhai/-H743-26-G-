"""Host-side regression checks for the software anti-interference path.

The script mirrors the numerical operations used by g_interference.c. It is
intended to validate frequency selection and tone subtraction before hardware
testing; it is not a replacement for ADC/DMA verification on the H743.
"""

from __future__ import annotations

import math

import numpy as np


def fit_tone(data: np.ndarray, sample_rate: float, frequency: float):
    n = data.size
    samples = np.arange(n, dtype=np.float64)
    angle = 2.0 * np.pi * frequency * samples / sample_rate
    matrix = np.column_stack((np.ones(n), np.cos(angle), np.sin(angle)))
    coefficients, *_ = np.linalg.lstsq(matrix, data, rcond=None)
    return coefficients, matrix


def subtract_tone(data: np.ndarray, sample_rate: float, frequency: float):
    coefficients, matrix = fit_tone(data, sample_rate, frequency)
    return data - matrix[:, 1:] @ coefficients[1:], coefficients


def strongest_in_band(data: np.ndarray, sample_rate: float,
                      minimum: float, maximum: float):
    n = data.size
    frequencies = np.fft.rfftfreq(n, 1.0 / sample_rate)
    spectrum = np.abs(np.fft.rfft((data - data.mean()) * np.hanning(n)))
    band = (frequencies >= minimum) & (frequencies <= maximum)
    if not np.any(band):
        return 0.0, 0.0
    index = np.flatnonzero(band)[np.argmax(spectrum[band])]
    return float(frequencies[index]), float(spectrum[index])


def check_direct_jam():
    sample_rate = 3_125_000.0
    count = 8192
    time = np.arange(count, dtype=np.float64) / sample_rate
    signal = (
        1650.0
        + 100.0 * np.sin(2.0 * np.pi * 100_000.0 * time)
        + 20.0 * np.sin(2.0 * np.pi * 200_000.0 * time + 0.4)
        + 100.0 * np.sin(2.0 * np.pi * 1_200_000.0 * time + 0.9)
    )
    detected, magnitude = strongest_in_band(
        signal, sample_rate, 550_000.0, 1_500_000.0
    )
    assert abs(detected - 1_200_000.0) < sample_rate / count * 2.0
    assert magnitude > 1.0e4
    clean, coefficients = subtract_tone(signal, sample_rate, detected)
    clean_fit, _ = fit_tone(clean, sample_rate, 100_000.0)
    assert abs(math.hypot(clean_fit[1], clean_fit[2]) - 100.0) < 0.5
    assert abs(coefficients[0] - 1650.0) < 0.5


def check_alias_disambiguation():
    high_rate = 3_125_000.0
    low_rate = 2_000_000.0
    high_count = 8192
    low_count = 4096
    jam_frequency = 2_700_000.0

    high_time = np.arange(high_count, dtype=np.float64) / high_rate
    high_signal = (
        1650.0
        + 100.0 * np.sin(2.0 * np.pi * 100_000.0 * high_time)
        + 100.0 * np.sin(2.0 * np.pi * jam_frequency * high_time)
    )
    high_alias, high_magnitude = strongest_in_band(
        high_signal, high_rate, 550_000.0, 1_500_000.0
    )
    assert high_magnitude < 1.0e3

    low_time = np.arange(low_count, dtype=np.float64) / low_rate
    low_signal = (
        1650.0
        + 100.0 * np.sin(2.0 * np.pi * 100_000.0 * low_time)
        + 100.0 * np.sin(2.0 * np.pi * jam_frequency * low_time)
    )
    low_alias, magnitude = strongest_in_band(
        low_signal, low_rate, 550_000.0, 980_000.0
    )
    assert abs(low_alias - 700_000.0) < low_rate / low_count * 2.0
    assert magnitude > 1.0e4
    clean, _ = subtract_tone(low_signal, low_rate, low_alias)
    clean_fit, _ = fit_tone(clean, low_rate, 100_000.0)
    assert abs(math.hypot(clean_fit[1], clean_fit[2]) - 100.0) < 0.5


if __name__ == "__main__":
    check_direct_jam()
    print("PASS direct_jam")
    check_alias_disambiguation()
    print("PASS alias_disambiguation")
