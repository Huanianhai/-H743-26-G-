"""Reference tests for the H743 joint harmonic fitting model."""

from __future__ import annotations

import math
import numpy as np


FS = 2_000_000.0
N = 4096
MAX_CANDIDATES = 8
ADC_FULL_SCALE = 4095.0
VDDA_MV = 3300.0


def design_matrix(fundamental_hz: float, orders: tuple[int, ...]) -> np.ndarray:
    samples = np.arange(N, dtype=np.float64)
    columns = [np.ones(N)]
    for order in orders:
        angle = 2.0 * np.pi * order * fundamental_hz * samples / FS
        columns.extend((np.cos(angle), np.sin(angle)))
    return np.column_stack(columns)


def fit_at_frequency(
    data: np.ndarray,
    fundamental_hz: float,
    orders: tuple[int, ...],
    robust: bool,
) -> tuple[np.ndarray, float]:
    matrix = design_matrix(fundamental_hz, orders)
    coefficients = np.linalg.lstsq(matrix, data, rcond=None)[0]
    threshold = 0.0
    if robust:
        residual = data - matrix @ coefficients
        sigma = 1.4826 * np.median(np.abs(residual))
        threshold = max(3.0 * sigma, 0.25)
        weights = np.minimum(1.0, threshold / np.maximum(np.abs(residual), 1e-12))
        weighted_matrix = matrix * np.sqrt(weights[:, None])
        weighted_data = data * np.sqrt(weights)
        coefficients = np.linalg.lstsq(weighted_matrix, weighted_data, rcond=None)[0]
    residual = data - matrix @ coefficients
    if threshold > 0.0:
        residual = np.clip(residual, -threshold, threshold)
    residual_rms = float(np.sqrt(np.mean(residual**2)))
    return coefficients, residual_rms


def firmware_fit_f32(
    data: np.ndarray,
    fundamental_hz: float,
    orders: tuple[int, ...],
) -> tuple[np.ndarray, float]:
    """Mirror the firmware's single-precision normal-equation fit."""
    matrix = design_matrix(fundamental_hz, orders).astype(np.float32)
    samples = data.astype(np.float32)
    normal = matrix.T @ matrix
    rhs = matrix.T @ samples
    coefficients = np.linalg.solve(normal, rhs).astype(np.float32)
    residual = samples - matrix @ coefficients
    return coefficients, float(np.sqrt(np.mean(residual * residual)))


def search(
    data: np.ndarray,
    seed_hz: float,
    orders: tuple[int, ...],
) -> tuple[float, np.ndarray, float]:
    golden = 0.61803398875
    maximum_order = max(orders)
    half_width = 2.0 * FS / (N * maximum_order)
    lower = max(8000.0, seed_hz - half_width)
    upper = min(550000.0 / maximum_order, seed_hz + half_width)
    left = upper - golden * (upper - lower)
    right = lower + golden * (upper - lower)
    _, left_score = fit_at_frequency(data, left, orders, False)
    _, right_score = fit_at_frequency(data, right, orders, False)
    for _ in range(8):
        if left_score <= right_score:
            upper, right, right_score = right, left, left_score
            left = upper - golden * (upper - lower)
            _, left_score = fit_at_frequency(data, left, orders, False)
        else:
            lower, left, left_score = left, right, right_score
            right = lower + golden * (upper - lower)
            _, right_score = fit_at_frequency(data, right, orders, False)
    frequency = left if left_score <= right_score else right
    coefficients, residual = fit_at_frequency(data, frequency, orders, True)
    return frequency, coefficients, residual


def fft_candidates(data: np.ndarray) -> list[tuple[float, float]]:
    window = np.hanning(N)
    spectrum = np.abs(np.fft.rfft((data - np.mean(data)) * window))
    bin_width = FS / N
    first_bin = math.ceil(8_000.0 / bin_width)
    last_bin = int(550_000.0 / bin_width)
    search_band = spectrum[first_bin : last_bin + 1]
    threshold = max(
        float(np.max(search_band)) * 0.0005,
        float(np.mean(search_band)) * 3.0,
        80.0,
    )
    masked_ranges: list[tuple[int, int]] = []
    candidates: list[tuple[float, float]] = []

    while len(candidates) < MAX_CANDIDATES:
        best_bin = first_bin
        best_magnitude = 0.0
        for bin_index in range(first_bin, last_bin + 1):
            if any(low <= bin_index <= high for low, high in masked_ranges):
                continue
            if spectrum[bin_index] > best_magnitude:
                best_bin = bin_index
                best_magnitude = float(spectrum[bin_index])
        if best_magnitude < threshold:
            break

        left, center, right = np.log(np.maximum(
            spectrum[best_bin - 1 : best_bin + 2], 1.0e-20
        ))
        denominator = left - 2.0 * center + right
        offset = 0.0 if abs(denominator) < 1e-9 else 0.5 * (left - right) / denominator
        offset = float(np.clip(offset, -1.0, 1.0))
        candidates.append(((best_bin + offset) * bin_width, best_magnitude))
        masked_ranges.append((max(first_bin, best_bin - 8), min(last_bin, best_bin + 8)))

    original_candidates = list(candidates)
    noise_mean = float(np.mean(search_band))
    for source_frequency, source_magnitude in original_candidates:
        for divisor in range(2, 9):
            if len(candidates) >= MAX_CANDIDATES:
                break
            expected_frequency = source_frequency / divisor
            if expected_frequency < 9_000.0:
                break
            expected_bin = round(expected_frequency / bin_width)
            search_low = max(first_bin, expected_bin - 2)
            search_high = min(last_bin, expected_bin + 2)
            local = spectrum[search_low : search_high + 1]
            peak_bin = search_low + int(np.argmax(local))
            peak_magnitude = float(spectrum[peak_bin])
            divided_threshold = max(
                source_magnitude * 0.0005,
                noise_mean * 3.0,
                60.0,
            )
            if peak_magnitude < divided_threshold:
                continue
            left, center, right = np.log(np.maximum(
                spectrum[peak_bin - 1 : peak_bin + 2], 1.0e-20
            ))
            denominator = left - 2.0 * center + right
            offset = (0.0 if abs(denominator) < 1e-9
                      else 0.5 * (left - right) / denominator)
            offset = float(np.clip(offset, -1.0, 1.0))
            frequency = (peak_bin + offset) * bin_width
            if any(abs(existing[0] - frequency) <= 500.0 for existing in candidates):
                continue
            candidates.append((frequency, peak_magnitude))

    return sorted(candidates)


def try_base_models(
    data: np.ndarray,
    candidates: list[tuple[float, float]],
    base_index: int,
) -> tuple[float, tuple[int, ...]]:
    best_score = math.inf
    best_orders: tuple[int, ...] = ()
    base_frequency = candidates[base_index][0]

    matched_by_order: dict[int, int] = {}
    for candidate_index, (frequency, magnitude) in enumerate(candidates):
        if candidate_index == base_index or frequency <= base_frequency:
            continue
        order = round(frequency / base_frequency)
        if order < 2 or order > 50:
            continue
        if abs(frequency - order * base_frequency) > 500.0:
            continue
        previous = matched_by_order.get(order)
        if previous is None or magnitude > candidates[previous][1]:
            matched_by_order[order] = candidate_index

    matched = list(matched_by_order.values())
    combinations: list[tuple[int, ...]] = [()]
    combinations.extend((item,) for item in matched)
    combinations.extend(
        (matched[first], matched[second])
        for first in range(len(matched))
        for second in range(first + 1, len(matched))
    )
    for extras in combinations:
        orders = [1]
        for candidate_index in extras:
            frequency = candidates[candidate_index][0]
            orders.append(round(frequency / base_frequency))
        ordered = tuple(sorted(orders))
        if len(set(ordered)) != len(ordered):
            continue
        coefficients, residual = fit_at_frequency(
            data, base_frequency, ordered, False
        )
        fitted_amplitudes = [
            math.hypot(
                coefficients[1 + 2 * component],
                coefficients[2 + 2 * component],
            )
            for component in range(len(ordered))
        ]
        if any(amplitude < 1.0 for amplitude in fitted_amplitudes):
            continue
        score = N * math.log(residual * residual + 1e-9) + (
            2 * len(ordered) + 2
        ) * math.log(N)
        if score < best_score:
            best_score = score
            best_orders = ordered

    return best_score, best_orders


def select_harmonic_model(
    candidates: list[tuple[float, float]],
) -> tuple[float, tuple[int, ...]]:
    best_score = -1.0
    best_fundamental = 0.0
    best_orders: tuple[int, ...] = ()

    for base_frequency, base_magnitude in candidates:
        if not 9_000.0 <= base_frequency <= 501_000.0:
            continue
        matched: dict[int, tuple[float, float]] = {}
        for frequency, magnitude in candidates:
            if frequency <= base_frequency:
                continue
            order = round(frequency / base_frequency)
            if not 2 <= order <= 50:
                continue
            if abs(frequency - order * base_frequency) > 500.0:
                continue
            previous = matched.get(order)
            if previous is None or magnitude > previous[1]:
                matched[order] = (frequency, magnitude)

        selected = sorted(
            matched.items(), key=lambda item: item[1][1], reverse=True
        )[:2]
        score = base_magnitude + sum(item[1][1] for item in selected)
        if score > best_score:
            best_score = score
            best_fundamental = base_frequency
            best_orders = tuple(sorted((1, *(item[0] for item in selected))))

    return best_fundamental, best_orders


def discover_model(data: np.ndarray) -> tuple[float, tuple[int, ...]]:
    candidates = fft_candidates(data)
    return select_harmonic_model(candidates)


def synthesize(
    fundamental_hz: float,
    orders: tuple[int, ...],
    amplitudes_mv: tuple[float, ...],
    phases_deg: tuple[float, ...],
    noise_rms_mv: float = 0.0,
    spikes: bool = False,
    common_phase_deg: float = 0.0,
) -> np.ndarray:
    rng = np.random.default_rng(20260729)
    samples = np.arange(N, dtype=np.float64)
    signal = np.full(N, 1650.0)
    for order, amplitude, phase in zip(orders, amplitudes_mv, phases_deg):
        angle = 2.0 * np.pi * order * fundamental_hz * samples / FS
        signal += amplitude * np.cos(
            angle + np.deg2rad(phase + order * common_phase_deg)
        )
    signal += rng.normal(0.0, noise_rms_mv, N)
    if spikes:
        locations = np.arange(127, N, 503)
        signal[locations] += np.where(np.arange(len(locations)) % 2, -80.0, 80.0)
    return signal


def firmware_adc12(data_mv: np.ndarray) -> np.ndarray:
    """Mirror the firmware's 12-bit ADC conversion without peak trimming."""
    codes = np.rint(data_mv * ADC_FULL_SCALE / VDDA_MV)
    codes = np.clip(codes, 0.0, ADC_FULL_SCALE).astype(np.uint16)
    return codes.astype(np.float64) * VDDA_MV / ADC_FULL_SCALE


def check_preprocess() -> None:
    clean = synthesize(30_000.0, (1,), (50.0,), (0.0,), 0.15)
    filtered = firmware_adc12(clean)
    ac_rms = float(np.std(filtered))
    assert abs(float(np.mean(filtered)) - 1650.0) <= 0.5
    assert abs(ac_rms - 50.0 / math.sqrt(2.0)) <= 0.5
    assert abs(float(np.ptp(filtered)) - 100.0) <= 2.0
    print(
        f"PASS adc12_quantize: bias={float(np.mean(filtered)):.4f}mV "
        f"rms={ac_rms:.4f}mV upp={float(np.ptp(filtered)):.4f}mV"
    )


def check_stability_flow() -> None:
    def publish_index(frames: tuple[float, ...]) -> int | None:
        candidate: float | None = None
        stable_count = 0
        for index, amplitude in enumerate(frames):
            if candidate is None:
                candidate = amplitude
                stable_count = 1
            elif abs(amplitude - candidate) <= max(3.0, 0.05 * candidate):
                stable_count += 1
            else:
                candidate = None
                stable_count = 0
            if stable_count == 3:
                return index
        return None

    assert publish_index((50.0, 50.2, 49.9)) == 2
    assert publish_index((50.0, 50.1, 80.0, 80.0, 80.2,
                          79.9)) == 5
    assert publish_index((50.0, 50.2, 80.0, 50.0, 80.0)) is None
    print("PASS three_frame_state: stable publish and change reset")


def check_single_precision_fit() -> None:
    cases = (
        (10_200.0, (1, 2, 4), (90.0, 30.0, 15.0),
         (25.0, -70.0, 130.0)),
        (66_500.0, (1, 2, 3), (125.0, 20.0, 5.0),
         (-20.0, 85.0, 150.0)),
        (247_350.0, (1, 2), (70.0, 18.0), (-15.0, 95.0)),
    )
    maximum_error = 0.0
    for fundamental_hz, orders, amplitudes, phases in cases:
        data = synthesize(
            fundamental_hz, orders, amplitudes, phases, noise_rms_mv=0.2
        )
        coefficients, residual = firmware_fit_f32(
            data, fundamental_hz, orders
        )
        measured = np.asarray(
            [
                math.hypot(
                    coefficients[1 + 2 * component],
                    coefficients[2 + 2 * component],
                )
                for component in range(len(orders))
            ]
        )
        error = float(np.max(np.abs(measured - amplitudes)))
        maximum_error = max(maximum_error, error)
        assert error <= 0.5, (fundamental_hz, error)
        assert residual <= 0.5, (fundamental_hz, residual)
    print(f"PASS float32_normal_fit: max_dA={maximum_error:.4f}mV")


def check_capture_guards() -> None:
    def evaluate(frames: tuple[str, ...]) -> tuple[int, bool]:
        warmup_remaining = 1
        consecutive_clipped = 0
        attempted = 0
        failed = False
        for frame in frames:
            if warmup_remaining:
                warmup_remaining -= 1
                continue
            attempted += 1
            if frame == "clip":
                consecutive_clipped += 1
                if consecutive_clipped >= 2:
                    failed = True
                    break
            else:
                consecutive_clipped = 0
        return attempted, failed

    assert evaluate(("clip", "ok", "ok")) == (2, False)
    assert evaluate(("ok", "clip", "ok")) == (2, False)
    assert evaluate(("ok", "clip", "clip")) == (2, True)
    print("PASS capture_guards: warmup discard and two-frame clip confirmation")


def check_adc12_clip_thresholds() -> None:
    normal = synthesize(
        100_000.0,
        (1, 2, 3),
        (100.0, 20.0, 20.0),
        (0.0, 35.0, -70.0),
    )
    normal_codes = np.rint(normal * ADC_FULL_SCALE / VDDA_MV)
    normal_codes = np.clip(normal_codes, 0.0, ADC_FULL_SCALE)
    normal_clipped = int(np.count_nonzero(
        (normal_codes <= 2.0) | (normal_codes >= 4093.0)
    ))
    rail_codes = normal_codes.copy()
    rail_codes[:8] = 4095.0
    rail_clipped = int(np.count_nonzero(
        (rail_codes <= 2.0) | (rail_codes >= 4093.0)
    ))
    assert normal_clipped == 0
    assert rail_clipped >= 8
    print(
        "PASS adc12_clip: normal=0 samples, "
        f"forced_rail={rail_clipped} samples"
    )


def check_frequency_phase_sweep() -> None:
    rng = np.random.default_rng(20260730)
    cases = []
    maximum_frequency_error = 0.0
    maximum_amplitude_error = 0.0

    for frequency in np.linspace(10_200.0, 490_000.0, 31):
        cases.append((
            float(frequency),
            (1,),
            (float(rng.uniform(25.0, 125.0)),),
            (float(rng.uniform(-180.0, 180.0)),),
        ))
    for frequency in np.linspace(10_300.0, 165_000.0, 31):
        cases.append((
            float(frequency),
            (1, 2, 3),
            (
                float(rng.uniform(50.0, 125.0)),
                float(rng.uniform(1.2, 30.0)),
                float(rng.uniform(1.2, 30.0)),
            ),
            tuple(float(value) for value in rng.uniform(-180.0, 180.0, 3)),
        ))

    for frequency, orders, amplitudes, phases in cases:
        data = firmware_adc12(synthesize(
            frequency, orders, amplitudes, phases, noise_rms_mv=0.3
        ))
        measured_hz, measured_orders = discover_model(data)
        assert measured_orders == orders, (
            frequency, measured_orders, orders
        )
        coefficients, _ = firmware_fit_f32(
            data, measured_hz, measured_orders
        )
        measured_amplitudes = np.asarray([
            math.hypot(
                coefficients[1 + 2 * component],
                coefficients[2 + 2 * component],
            )
            for component in range(len(orders))
        ])
        frequency_error = abs(measured_hz - frequency)
        amplitude_error = float(np.max(
            np.abs(measured_amplitudes - np.asarray(amplitudes))
        ))
        maximum_frequency_error = max(
            maximum_frequency_error, frequency_error
        )
        maximum_amplitude_error = max(
            maximum_amplitude_error, amplitude_error
        )
        assert frequency_error <= 1_000.0, (frequency, frequency_error)
        assert amplitude_error <= 5.0, (frequency, amplitude_error)

    print(
        f"PASS frequency_phase_sweep: cases={len(cases)} "
        f"max_df={maximum_frequency_error:.4f}Hz "
        f"max_dA={maximum_amplitude_error:.4f}mV"
    )


def check_case(
    name: str,
    fundamental_hz: float,
    orders: tuple[int, ...],
    amplitudes_mv: tuple[float, ...],
    phases_deg: tuple[float, ...],
    seed_error_hz: float,
    noise_rms_mv: float = 0.0,
    spikes: bool = False,
) -> None:
    data = firmware_adc12(synthesize(
        fundamental_hz,
        orders,
        amplitudes_mv,
        phases_deg,
        noise_rms_mv,
        spikes,
    ))
    measured_hz, measured_orders = discover_model(data)
    assert measured_orders == orders, (name, measured_orders, orders)
    coefficients, residual = firmware_fit_f32(
        data, measured_hz, measured_orders
    )
    measured_amplitudes = []
    measured_phases = []
    for component in range(len(orders)):
        cosine = coefficients[1 + 2 * component]
        sine = coefficients[2 + 2 * component]
        measured_amplitudes.append(float(math.hypot(cosine, sine)))
        measured_phases.append(float(math.degrees(math.atan2(-sine, cosine))))

    locked_data = firmware_adc12(synthesize(
        fundamental_hz,
        orders,
        amplitudes_mv,
        phases_deg,
        noise_rms_mv,
        spikes,
        common_phase_deg=73.0,
    ))
    locked_coefficients, locked_residual = fit_at_frequency(
        locked_data, measured_hz, measured_orders, False
    )
    locked_amplitudes = []
    for component in range(len(orders)):
        cosine = locked_coefficients[1 + 2 * component]
        sine = locked_coefficients[2 + 2 * component]
        locked_amplitudes.append(float(math.hypot(cosine, sine)))

    frequency_error = abs(measured_hz - fundamental_hz)
    amplitude_errors = np.abs(np.asarray(measured_amplitudes) - amplitudes_mv)
    locked_errors = np.abs(np.asarray(locked_amplitudes) - amplitudes_mv)
    measured_rms = math.sqrt(sum(value * value for value in measured_amplitudes) / 2.0)
    expected_rms = math.sqrt(sum(value * value for value in amplitudes_mv) / 2.0)

    def reconstructed_vpp(amplitudes: tuple[float, ...] | list[float],
                          phases: tuple[float, ...] | list[float],
                          points: int) -> float:
        theta = 2.0 * np.pi * np.arange(points, dtype=np.float64) / points
        relative = [
            phase - order * phases[0]
            for order, phase in zip(orders, phases)
        ]
        wave = sum(
            amplitude * np.cos(order * theta + math.radians(phase))
            for order, amplitude, phase in zip(orders, amplitudes, relative)
        )
        return float(np.ptp(wave))

    measured_vpp = reconstructed_vpp(
        measured_amplitudes, measured_phases, 4096
    )
    expected_vpp = reconstructed_vpp(amplitudes_mv, phases_deg, 65536)
    assert frequency_error <= 1_000.0, (name, frequency_error)
    assert float(np.max(amplitude_errors)) <= 5.0, (name, amplitude_errors)
    assert float(np.max(locked_errors)) <= 5.0, (name, locked_errors)
    assert abs(measured_rms - expected_rms) <= 5.0, (
        name, measured_rms, expected_rms
    )
    assert abs(measured_vpp - expected_vpp) <= 5.0, (
        name, measured_vpp, expected_vpp
    )
    print(
        f"PASS {name}: df={frequency_error:.4f}Hz "
        f"max_dA={float(np.max(amplitude_errors)):.4f}mV "
        f"locked_dA={float(np.max(locked_errors)):.4f}mV "
        f"dRMS={abs(measured_rms - expected_rms):.4f}mV "
        f"dVpp={abs(measured_vpp - expected_vpp):.4f}mV "
        f"orders={measured_orders} res={residual:.4f}/"
        f"{locked_residual:.4f}mV"
    )


def main() -> None:
    check_preprocess()
    check_stability_flow()
    check_single_precision_fit()
    check_capture_guards()
    check_adc12_clip_thresholds()
    check_frequency_phase_sweep()
    check_case("pure_30k", 30_000.0, (1,), (50.0,), (37.0,), 180.0, 0.15)
    check_case("pure_100k", 100_000.0, (1,), (50.0,), (12.0,), -120.0, 0.15)
    check_case(
        "off_grid_h1_h2_h4",
        10_200.0,
        (1, 2, 4),
        (90.0, 30.0, 15.0),
        (25.0, -70.0, 130.0),
        35.0,
        0.20,
    )
    check_case(
        "high_band_h1_h2",
        247_350.0,
        (1, 2),
        (70.0, 18.0),
        (-15.0, 95.0),
        -80.0,
        0.20,
    )
    check_case(
        "robust_spikes",
        37_125.0,
        (1, 3, 7),
        (62.0, 21.0, 9.0),
        (10.0, 80.0, -120.0),
        20.0,
        0.30,
        True,
    )
    check_case(
        "ua_h1_h2_h3",
        30_000.0,
        (1, 2, 3),
        (75.0, 15.0, 10.0),
        (0.0, 0.0, 0.0),
        100.0,
        0.15,
    )
    check_case(
        "ub_h1_h2_h3",
        100_000.0,
        (1, 2, 3),
        (60.0, 20.0, 10.0),
        (0.0, 0.0, 0.0),
        -100.0,
        0.15,
    )
    check_case(
        "ub_component_at_500k",
        250_000.0,
        (1, 2),
        (50.0, 10.0),
        (20.0, -75.0),
        100.0,
        0.15,
    )
    check_case(
        "actual_100k_200mVpp_h2_h3_40mVpp",
        100_000.0,
        (1, 2, 3),
        (100.0, 20.0, 20.0),
        (0.0, 35.0, -70.0),
        100.0,
        0.15,
    )
    check_case(
        "small_h2_h3",
        80_000.0,
        (1, 2, 3),
        (100.0, 2.0, 1.5),
        (5.0, 70.0, -110.0),
        50.0,
        0.10,
    )


if __name__ == "__main__":
    main()
