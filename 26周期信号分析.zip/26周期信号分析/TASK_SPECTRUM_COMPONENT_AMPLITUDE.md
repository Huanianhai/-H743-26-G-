# Task

将电压频谱各分量由峰峰值显示改为正弦幅值（峰值），总峰峰值和有效值保持不变。

# Scope

- `User/g_view.c`: 频谱纵轴和H1/H3/H5参数行改为`mVpk`，取消乘2。
- `User/g_measure.c`: 串口分量输出改为`Amp`和`mVpk`，取消乘2。
- 不修改ADC、FFT、谐波拟合、抗干扰、Upp或Urms算法。

# Expected Display

当信号发生器设置H1=100mVpp、H3=30mVpp、H5=30mVpp时，理想频谱幅值显示约为H1=50mVpk、H3=15mVpk、H5=15mVpk。

# Verification

2026-07-30 使用 Keil ArmClang V6.21 全量编译，结果为 `0 Error(s), 0 Warning(s)`。业务源码搜索确认不存在分量`mVpp`标签或`amplitude_mv * 2`显示路径；`Upp(total)`按设计继续表示整体峰峰值。新 HEX 已生成。

Implementation perfectly matches the final plan.
