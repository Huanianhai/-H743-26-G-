../../output/g_calibration.o: ..\..\User\g_calibration.c \
  ..\..\User\g_calibration.h D:\keil5\ARM\ARMCLANG\include\stdint.h
