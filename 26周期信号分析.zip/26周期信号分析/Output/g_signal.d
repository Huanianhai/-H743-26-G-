../../output/g_signal.o: ..\..\User\g_signal.c ..\..\User\g_signal.h \
  D:\keil5\ARM\ARMCLANG\include\stdint.h \
  D:\keil5\ARM\ARMCLANG\include\math.h
