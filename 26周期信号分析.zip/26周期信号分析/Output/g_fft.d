../../output/g_fft.o: ..\..\User\g_fft.c ..\..\User\g_fft.h \
  D:\keil5\ARM\ARMCLANG\include\stdint.h \
  ..\..\Drivers\.\CMSIS\DSP\Include\arm_math.h \
  ..\..\Drivers\CMSIS\Include\cmsis_compiler.h \
  ..\..\Drivers\CMSIS\Include\cmsis_armclang.h \
  D:\keil5\ARM\ARMCLANG\include\arm_compat.h \
  D:\keil5\ARM\ARMCLANG\include\arm_acle.h \
  D:\keil5\ARM\ARMCLANG\include\string.h \
  D:\keil5\ARM\ARMCLANG\include\math.h \
  D:\keil5\ARM\ARMCLANG\include\float.h
